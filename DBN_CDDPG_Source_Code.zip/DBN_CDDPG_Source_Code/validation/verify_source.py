from __future__ import annotations

import hashlib
import json
import py_compile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROV = json.loads((ROOT / "SOURCE_PROVENANCE.json").read_text(encoding="utf-8"))

failed = False
print("Source integrity check")
for name, rec in PROV["source_files"].items():
    path = ROOT / name
    if not path.exists():
        print(f"[MISSING] {name}")
        failed = True
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    ok = digest == rec["sha256"]
    print(f"[{'OK' if ok else 'HASH MISMATCH'}] {name}  {digest}")
    failed |= not ok

print("\nPython compilation check")
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    for name in PROV["source_files"]:
        path = ROOT / name
        if not path.exists():
            continue
        try:
            py_compile.compile(str(path), cfile=str(tmp / (path.stem + '.pyc')), doraise=True)
            print(f"[OK] {name}")
        except Exception as exc:
            print(f"[FAILED] {name}: {exc}")
            failed = True

if failed:
    raise SystemExit(1)
print("\nAll packaged experiment source files passed integrity and compilation checks.")
