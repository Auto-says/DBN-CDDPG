from __future__ import annotations

import argparse
import copy
import json
import math
import platform
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from experiment_common import (
    FORMAL_BUDGETS, FORMAL_SEEDS, DDQNPolicy, PPOLagrangianPolicy,
    budget_diagnostics, build_joint_actions, checkpoint_key, deep_payload_with_params,
    encode_action_vector, force_formal_budgets, json_dump, load_solver, make_planner_class,
    make_stress_env_class, mean_sd, parse_seeds, same_spec, set_all_seeds,
    sha256, spec_from_hierarchical_preferences, valid_joint_mask, write_csv,
)

try:
    from scipy.stats import wilcoxon
except Exception:  # pragma: no cover
    wilcoxon = None

RUNNER_VERSION = "table7-dynamicAHD-retyping-v1.0"


def _df_to_markdown(frame: pd.DataFrame) -> str:
    """Render a DataFrame as a Markdown table without the optional tabulate package."""
    if frame is None or frame.empty:
        return "_No rows._"

    def _cell(value: Any) -> str:
        try:
            if pd.isna(value):
                return ""
        except Exception:
            pass
        if isinstance(value, (float, np.floating)):
            text = f"{float(value):.6g}"
        else:
            text = str(value)
        return text.replace("|", "\\|").replace("\n", " ")

    columns = [str(c) for c in frame.columns]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(_cell(v) for v in row) + " |")
    return "\n".join(lines)

METHODS = [
    "joint_masked_ddqn",
    "dbn_joint_ddqn",
    "projected_ddpg",
    "lagrangian_ddpg",
    "ppo_lagrangian",
    "dbn_cddpg",
]
DISPLAY = {
    "joint_masked_ddqn": "Joint masked DDQN",
    "dbn_joint_ddqn": "DBN-guided DDQN",
    "projected_ddpg": "Projected DDPG",
    "lagrangian_ddpg": "Lagrangian DDPG",
    "ppo_lagrangian": "PPO-Lagrangian",
    "dbn_cddpg": "DBN-CDDPG",
}

SCENARIOS: Dict[str, List[Dict[str, float]]] = {
    "HE-1_AHD": [
        {"completed_tasks": 7, "ahd_multiplier": 1.35, "risk_multiplier": 1.10},
    ],
    "HE-2_fatigue": [
        {"completed_tasks": 7, "fatigue_shock": 0.70},
        {"completed_tasks": 14, "fatigue_shock": 0.50},
    ],
    "HE-3_robot_delay": [
        {"completed_tasks": 7, "robot_delay": 20.0},
        {"completed_tasks": 14, "robot_delay": 15.0},
    ],
    "HE-4_combined": [
        {"completed_tasks": 7, "ahd_multiplier": 1.45, "risk_multiplier": 1.25, "fatigue_shock": 0.80, "robot_delay": 20.0},
        {"completed_tasks": 14, "ahd_multiplier": 1.20, "risk_multiplier": 1.20, "fatigue_shock": 0.60, "robot_delay": 10.0},
    ],
}

BASE_PARAMS = {
    "gamma": 1.0,
    "batch_size": 64,
    "buffer_size": 50000,
    "warmup_steps": 128,
    "update_every": 4,
    "hidden_dim": 128,
    "actor_lr": 1e-4,
    "critic_lr": 3e-4,
    "target_tau": 0.01,
    "noise_start": 0.30,
    "noise_end": 0.05,
    "noise_decay_fraction": 0.80,
    "projection_temperature": 0.25,
    "actor_backward_temperature": 1.0,
    "actor_output_bound": 1.0,
    "dbn_guidance_strength": 0.35,
    "lambda_update_lr": 0.02,
    "lambda_max": 20.0,
    "use_dynamic_ahd": 1,
    "use_event_retyping": 1,
}

METHOD_PARAMS = {
    "joint_masked_ddqn": {
        "use_dbn_state": 0, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0,
        "dbn_guidance_strength": 0.0, "adaptive_lagrange": 0,
    },
    "dbn_joint_ddqn": {
        "use_dbn_state": 1, "use_dbn_mode_bias": 1, "use_posterior_mapping": 1,
        "dbn_guidance_strength": 0.35, "adaptive_lagrange": 0,
    },
    "projected_ddpg": {
        "use_dbn_state": 0, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0,
        "dbn_guidance_strength": 0.0, "adaptive_lagrange": 0,
        "lambda_energy": 0.0, "lambda_risk": 0.0, "lambda_fatigue": 0.0,
    },
    "lagrangian_ddpg": {
        "use_dbn_state": 0, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0,
        "dbn_guidance_strength": 0.0, "adaptive_lagrange": 0,
    },
    "ppo_lagrangian": {
        "use_dbn_state": 0, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0,
        "dbn_guidance_strength": 0.0,
    },
    "dbn_cddpg": {
        "use_dbn_state": 1, "use_dbn_mode_bias": 1, "use_posterior_mapping": 1,
        "dbn_guidance_strength": 0.35, "adaptive_lagrange": 1,
    },
}


def method_uses_dual_update(method: str) -> bool:
    return method in {"lagrangian_ddpg", "ppo_lagrangian", "dbn_cddpg"}


def make_planner(solver, base_data, method: str, *, stress_events=None):
    overrides = dict(BASE_PARAMS)
    overrides.update(METHOD_PARAMS[method])
    payload = force_formal_budgets(deep_payload_with_params(base_data, overrides))
    if stress_events is None:
        env_cls = solver.DBNCDDPGEnv
    else:
        env_cls = make_stress_env_class(solver, stress_events)
    Planner = make_planner_class(solver, env_cls, allow_dual_update=method_uses_dual_update(method))
    planner = Planner(payload)
    # expose total training steps to the uploaded DDPG noise schedule
    return planner


def _ddpg_snapshot(agent):
    return {k: v.detach().cpu().clone() for k, v in agent.actor.state_dict().items()}


def _ddpg_restore(agent, snap):
    agent.actor.load_state_dict(snap)
    agent.actor_target.load_state_dict(snap)


def evaluate_policy(solver, planner, method: str, policy, actions, *, stress=False):
    env = planner.make_env()
    state = env.reset()
    done = False
    decision_seconds = 0.0
    decisions = 0
    raw_unsafe = 0
    raw_total = 0
    smsr_success = 0
    smsr_total = 0
    scmr_success = 0
    scmr_total = 0
    while not done:
        full_mask = valid_joint_mask(env, actions, structural_only=False)
        structural_mask = valid_joint_mask(env, actions, structural_only=True)
        if method in {"joint_masked_ddqn", "dbn_joint_ddqn"}:
            t0 = time.perf_counter()
            scores = policy.scores(state, env)
            valid = np.flatnonzero(full_mask > 0.5)
            idx = int(valid[np.argmax(scores[valid])])
            decision_seconds += time.perf_counter() - t0
            actual_spec = actions[idx]
            structural = np.flatnonzero(structural_mask > 0.5)
            raw_idx = int(structural[np.argmax(scores[structural])])
            raw_spec = actions[raw_idx]
            action_vec = encode_action_vector(env, actual_spec)
        elif method == "ppo_lagrangian":
            t0 = time.perf_counter()
            scores = policy.scores(state, env)
            valid = np.flatnonzero(full_mask > 0.5)
            idx = int(valid[np.argmax(scores[valid])])
            decision_seconds += time.perf_counter() - t0
            actual_spec = actions[idx]
            structural = np.flatnonzero(structural_mask > 0.5)
            raw_idx = int(structural[np.argmax(scores[structural])])
            raw_spec = actions[raw_idx]
            action_vec = encode_action_vector(env, actual_spec)
        else:
            t0 = time.perf_counter()
            prefs = policy.act(state, explore=False)
            decision_seconds += time.perf_counter() - t0
            raw_spec = spec_from_hierarchical_preferences(env, prefs, structural_only=True)
            actual_spec, _ = env.decode_action(prefs, context=env.projection_context())
            actual_spec = type(raw_spec)(
                int(actual_spec.task_id), str(actual_spec.mode), int(actual_spec.binding_index),
                getattr(actual_spec, "human_id", None), getattr(actual_spec, "robot_id", None),
            )
            action_vec = prefs

        if stress:
            raw_total += 1
            # raw proposal is unsafe if it is structurally selectable but no longer
            # belongs to the full post-shock feasible domain.
            current_full = set()
            for i, a in enumerate(actions):
                if full_mask[i] > 0.5:
                    current_full.add((a.task_id, a.mode, a.binding_index))
            raw_unsafe += int((raw_spec.task_id, raw_spec.mode, raw_spec.binding_index) not in current_full)

            tid = raw_spec.task_id
            ttype = env.current_task_types.get(tid, env.p.initial_task_types[tid])
            ahd_t = float(env.dynamic_ahd_scores.get(tid, env.p.ahd_scores.get(tid, 0.0)))
            struct_modes = env.p._legal_modes_for_task(env.p.tasks[tid], task_type=ttype)
            if ttype == "III" and ahd_t >= float(env.params.get("theta_dynamic_ahd_h_block", 120.0)) and "H" in struct_modes:
                smsr_total += 1
                smsr_success += int(raw_spec.mode != "H")
                scmr_total += 1
                scmr_success += int(actual_spec.mode != "H")

        ctx = env.projection_context()
        state, _, done, _ = env.step(action_vec, projection_context=ctx)
        decisions += 1

    m = dict(env.metrics())
    diag = budget_diagnostics(m)
    m.update(diag)
    post_event_risk = float("nan")
    if stress and getattr(env, "_first_stress_schedule_index", None) is not None:
        k = int(env._first_stress_schedule_index)
        post_event_risk = float(sum(x.delta_risk for x in env.schedule[k:]))
    safety = {
        "uapr_unsafe": raw_unsafe,
        "uapr_total": raw_total,
        "smsr_success": smsr_success,
        "smsr_total": smsr_total,
        "scmr_success": scmr_success,
        "scmr_total": scmr_total,
        "post_event_risk": post_event_risk,
        "decision_time_ms": 1000.0 * decision_seconds / max(decisions, 1),
        "completion_rate": 1.0 if len(env.schedule) == env.n_tasks else len(env.schedule) / max(env.n_tasks, 1),
    }
    return m, safety, env


def train_one(solver, base_data, method: str, seed: int, episodes: int, device: str, eval_interval: int, save_details: bool, detail_dir: Path):
    set_all_seeds(seed)
    planner = make_planner(solver, base_data, method)
    planner.params["_total_training_steps"] = int(episodes * len(planner.topo_order))
    probe = planner.make_env()
    state_dim = probe.state_dim
    actions = build_joint_actions(planner, tuple(solver.MODES))
    action_dim_hier = len(planner.topo_order) + len(solver.MODES) + planner.binding_dim

    if method in {"joint_masked_ddqn", "dbn_joint_ddqn"}:
        policy = DDQNPolicy(
            state_dim, actions, device=device, gamma=1.0,
            epsilon_decay_steps=max(1, int(episodes * len(planner.topo_order) * 0.8)),
            dbn_guidance_strength=0.35 if method == "dbn_joint_ddqn" else 0.0,
        )
    elif method == "ppo_lagrangian":
        policy = PPOLagrangianPolicy(state_dim, actions, device=device, gamma=1.0)
    else:
        policy = solver.DDPGAgent(state_dim, action_dim_hier, planner, device=device)

    best_key = (9, math.inf, math.inf)
    best_snapshot = None
    best_episode = 0
    history: List[Dict[str, Any]] = []

    for ep in range(1, episodes + 1):
        env = planner.make_env()
        state = env.reset()
        done = False
        losses: Dict[str, float] = {}
        while not done:
            ctx = env.projection_context()
            if method in {"joint_masked_ddqn", "dbn_joint_ddqn"}:
                mask = valid_joint_mask(env, actions)
                idx = policy.choose(state, mask, env, explore=True)
                vec = encode_action_vector(env, actions[idx])
                ns, reward, done, info = env.step(vec, projection_context=ctx)
                next_mask = valid_joint_mask(env, actions) if not done else np.zeros(len(actions), np.float32)
                loss = policy.observe(state, idx, reward, ns, done, next_mask)
                losses = {"loss": loss}
            elif method == "ppo_lagrangian":
                mask = valid_joint_mask(env, actions)
                idx, logp, value = policy.choose(state, mask, env, explore=True)
                vec = encode_action_vector(env, actions[idx])
                ns, reward, done, info = env.step(vec, projection_context=ctx)
                policy.observe(state, mask, idx, reward, done, logp, value)
            else:
                prefs = policy.act(state, explore=True)
                ns, reward, done, info = env.step(prefs, projection_context=ctx)
                next_ctx = env.projection_context()
                policy.replay.push(
                    state, info["executed_action_vector"], reward, ns, done,
                    ctx, next_ctx, transition_deltas=info["transition_deltas"],
                )
                losses = policy.update()
            state = ns

        if method == "ppo_lagrangian":
            losses = {"loss": policy.finish_episode()}
        train_metrics = env.metrics()
        if method_uses_dual_update(method):
            planner.update_constraint_lambdas(train_metrics)

        if ep % max(1, eval_interval) == 0 or ep == episodes:
            metrics, _, _ = evaluate_policy(solver, planner, method, policy, actions, stress=False)
            key = checkpoint_key(metrics)
            history.append({
                "episode": ep, "makespan": metrics["makespan"], "energy": metrics["energy"],
                "risk": metrics["risk"], "fatigue": metrics["fatigue"], "nvs": metrics["nvs"],
                "budget_feasible": metrics["budget_feasible"],
                "lambda_energy": float(planner.params.get("lambda_energy", 0.0)),
                "lambda_risk": float(planner.params.get("lambda_risk", 0.0)),
                "lambda_fatigue": float(planner.params.get("lambda_fatigue", 0.0)),
                **{k: float(v) for k, v in losses.items() if isinstance(v, (int, float)) and np.isfinite(v)},
            })
            if key < best_key:
                best_key = key
                best_episode = ep
                best_snapshot = policy.snapshot() if hasattr(policy, "snapshot") else _ddpg_snapshot(policy)

    if best_snapshot is None:
        raise RuntimeError(f"No checkpoint for {method} seed {seed}")
    if hasattr(policy, "restore"):
        policy.restore(best_snapshot)
    else:
        _ddpg_restore(policy, best_snapshot)

    metrics, safety, env = evaluate_policy(solver, planner, method, policy, actions, stress=False)
    if save_details:
        d = detail_dir / method / f"seed_{seed}"
        d.mkdir(parents=True, exist_ok=True)
        write_csv(d / "training_history.csv", history)
        write_csv(d / "nominal_schedule.csv", [vars(x) for x in env.schedule])
        if getattr(env, "dbn_trace", None): write_csv(d / "nominal_dbn_trace.csv", env.dbn_trace)
        if getattr(env, "task_type_trace", None): write_csv(d / "nominal_task_type_trace.csv", env.task_type_trace)
        if getattr(env, "dynamic_ahd_trace", None): write_csv(d / "nominal_dynamic_ahd_trace.csv", env.dynamic_ahd_trace)
    return planner, policy, actions, metrics, safety, best_episode


def dynamic_eval(solver, base_data, method, policy, actions, seed, nominal_makespan, event_repeats):
    rows = []
    # Recreate planners with identical method flags and copy the learned actor/Q/PPO policy.
    for scenario, events in SCENARIOS.items():
        for rep in range(event_repeats):
            planner = make_planner(solver, base_data, method, stress_events=events)
            probe = planner.make_env()
            if method in {"joint_masked_ddqn", "dbn_joint_ddqn"}:
                clone = DDQNPolicy(probe.state_dim, actions, device=str(policy.device), dbn_guidance_strength=policy.dbn_guidance_strength)
                clone.restore(policy.snapshot())
            elif method == "ppo_lagrangian":
                clone = PPOLagrangianPolicy(probe.state_dim, actions, device=str(policy.device))
                clone.restore(policy.snapshot())
            else:
                clone = solver.DDPGAgent(probe.state_dim, len(planner.topo_order)+3+planner.binding_dim, planner, device=str(policy.device))
                _ddpg_restore(clone, _ddpg_snapshot(policy))
            metrics, safety, _ = evaluate_policy(solver, planner, method, clone, actions, stress=True)
            rows.append({
                "algorithm": method, "display_name": DISPLAY[method], "seed": seed, "scenario": scenario, "repeat": rep,
                "completion_rate": safety["completion_rate"],
                "uapr_unsafe": safety["uapr_unsafe"], "uapr_total": safety["uapr_total"],
                "smsr_success": safety["smsr_success"], "smsr_total": safety["smsr_total"],
                "scmr_success": safety["scmr_success"], "scmr_total": safety["scmr_total"],
                "post_event_risk": safety["post_event_risk"],
                "makespan": metrics["makespan"], "energy": metrics["energy"], "risk": metrics["risk"], "fatigue": metrics["fatigue"],
                "delta_makespan_pct": 100.0 * (float(metrics["makespan"]) - float(nominal_makespan)) / max(float(nominal_makespan), 1e-12),
                "budget_feasible": metrics["budget_feasible"], "nvs": metrics["nvs"],
            })
    return rows


def _entropy_weights(frame: pd.DataFrame, metrics: Sequence[Tuple[str, str]]) -> Dict[str, float]:
    if frame.empty: return {m: 1/len(metrics) for m,_ in metrics}
    X=[]
    for m,direction in metrics:
        x=pd.to_numeric(frame[m],errors="coerce").astype(float).to_numpy()
        lo=np.nanmin(x); hi=np.nanmax(x)
        if not np.isfinite(lo) or not np.isfinite(hi) or hi-lo<1e-12:
            z=np.full_like(x,0.5,dtype=float)
        elif direction=="cost": z=(hi-x)/(hi-lo)
        else: z=(x-lo)/(hi-lo)
        X.append(np.clip(z,1e-12,None))
    Z=np.column_stack(X); n=max(2,Z.shape[0]); div=[]
    for j in range(Z.shape[1]):
        p=Z[:,j]/max(Z[:,j].sum(),1e-12); e=-(p*np.log(p)).sum()/math.log(n); div.append(max(1-e,1e-12))
    div=np.asarray(div); w=div/div.sum()
    return {metrics[i][0]:float(w[i]) for i in range(len(metrics))}


def analyze(output_dir: Path):
    nominal=pd.read_csv(output_dir/"nominal_runs.csv")
    dynamic=pd.read_csv(output_dir/"dynamic_runs.csv")
    # Table 7a
    rows=[]
    for method in METHODS:
        g=nominal[nominal.algorithm==method]
        if g.empty: continue
        rec={"algorithm":method,"Algorithm":DISPLAY[method],"n":len(g)}
        for col,label in [("makespan","Cmax_s"),("risk","AHD"),("fatigue","Fatigue"),("energy","Energy"),("decision_time_ms","Decision_time_ms"),("nvs","NVS")]:
            m,sd,n=mean_sd(g[col]); rec[label+"_mean"]=m;rec[label+"_sd"]=sd
        rec["ABFR_pct"]=100*float(g.budget_feasible.mean())
        rows.append(rec)
    pd.DataFrame(rows).to_csv(output_dir/"table7a_nominal.csv",index=False,encoding="utf-8-sig")

    # Dynamic by algorithm and scenario; pooled ratios use sum numerator/sum denominator.
    dyn_rows=[]; scen_rows=[]
    for method in METHODS:
        g=dynamic[dynamic.algorithm==method]
        if g.empty: continue
        def ratio(num,den):
            D=float(pd.to_numeric(g[den],errors="coerce").fillna(0).sum()); N=float(pd.to_numeric(g[num],errors="coerce").fillna(0).sum()); return 100*N/D if D>0 else math.nan
        dyn_rows.append({
            "algorithm":method,"Algorithm":DISPLAY[method],
            "Completion_pct":100*float(g.completion_rate.mean()),
            "UAPR_pct":ratio("uapr_unsafe","uapr_total"),
            "SMSR_pct":ratio("smsr_success","smsr_total"),
            "SCMR_pct":ratio("scmr_success","scmr_total"),
            "Post_event_AHD_mean":float(pd.to_numeric(g.post_event_risk,errors="coerce").mean()),
            "Delta_Cmax_pct_mean":float(pd.to_numeric(g.delta_makespan_pct,errors="coerce").mean()),
            "Dynamic_ABFR_pct":100*float(g.budget_feasible.mean()),
        })
        for scenario in SCENARIOS:
            h=g[g.scenario==scenario]
            if h.empty: continue
            def rr(num,den):
                D=float(h[den].sum()); return 100*float(h[num].sum())/D if D>0 else math.nan
            scen_rows.append({"algorithm":method,"Algorithm":DISPLAY[method],"scenario":scenario,
                "Completion_pct":100*float(h.completion_rate.mean()),"UAPR_pct":rr("uapr_unsafe","uapr_total"),
                "SMSR_pct":rr("smsr_success","smsr_total"),"SCMR_pct":rr("scmr_success","scmr_total"),
                "Post_event_AHD_mean":float(h.post_event_risk.mean()),"Delta_Cmax_pct_mean":float(h.delta_makespan_pct.mean())})
    pd.DataFrame(dyn_rows).to_csv(output_dir/"table7b_dynamic.csv",index=False,encoding="utf-8-sig")
    pd.DataFrame(scen_rows).to_csv(output_dir/"table7b_dynamic_by_scenario.csv",index=False,encoding="utf-8-sig")

    # seed-level dynamic aggregation for scores/statistics
    seed_dyn=[]
    for (method,seed),g in dynamic.groupby(["algorithm","seed"]):
        def ratio01(num,den):
            d=float(g[den].sum()); return float(g[num].sum())/d if d>0 else math.nan
        seed_dyn.append({"algorithm":method,"seed":seed,"uapr":ratio01("uapr_unsafe","uapr_total"),
                         "smsr":ratio01("smsr_success","smsr_total"),"scmr":ratio01("scmr_success","scmr_total"),
                         "post_event_risk":float(g.post_event_risk.mean()),"delta_makespan_pct":float(g.delta_makespan_pct.mean())})
    sd=pd.DataFrame(seed_dyn)
    merged=nominal.merge(sd,on=["algorithm","seed"],how="left")
    # completion gate: only complete policies enter composite; all nominal schedules produced by this runner should complete.
    noes_metrics=[("makespan","cost"),("energy","cost"),("decision_time_ms","cost")]
    dsas_metrics=[("uapr","cost"),("smsr","benefit"),("scmr","benefit"),("post_event_risk","cost")]
    w_noes=_entropy_weights(merged,noes_metrics); w_dsas=_entropy_weights(merged,dsas_metrics)
    json_dump(output_dir/"table7_score_weights.json",{"NOES":w_noes,"DSAS":w_dsas,"BPS_lambda":0.5})
    def normalized_score(frame, metrics, weights):
        out=np.zeros(len(frame),float)
        for m,direction in metrics:
            x=pd.to_numeric(frame[m],errors="coerce").astype(float).to_numpy(); lo=np.nanmin(x);hi=np.nanmax(x)
            z=np.ones_like(x)*0.5 if hi-lo<1e-12 else ((hi-x)/(hi-lo) if direction=="cost" else (x-lo)/(hi-lo))
            out+=weights[m]*z
        return out
    merged["NOES"]=normalized_score(merged,noes_metrics,w_noes); merged["DSAS"]=normalized_score(merged,dsas_metrics,w_dsas); merged["BPS"]=0.5*merged.NOES+0.5*merged.DSAS
    merged.to_csv(output_dir/"table7_score_by_seed.csv",index=False,encoding="utf-8-sig")
    score_summary=merged.groupby("algorithm").agg(NOES_mean=("NOES","mean"),DSAS_mean=("DSAS","mean"),BPS_mean=("BPS","mean"),BPS_sd=("BPS","std")).reset_index()
    score_summary["Algorithm"]=score_summary.algorithm.map(DISPLAY); score_summary["BPS_rank"]=score_summary.BPS_mean.rank(ascending=False,method="min").astype(int)
    score_summary.sort_values("BPS_rank").to_csv(output_dir/"table7_score_summary.csv",index=False,encoding="utf-8-sig")

    # Paired tests vs Full DBN-CDDPG (matched seed only).
    tests=[]
    metrics=[("makespan","lower"),("risk","lower"),("energy","lower"),("fatigue","lower"),("nvs","lower"),("BPS","higher")]
    full=merged[merged.algorithm=="dbn_cddpg"].set_index("seed")
    for method in METHODS:
        if method=="dbn_cddpg": continue
        other=merged[merged.algorithm==method].set_index("seed")
        common=full.index.intersection(other.index)
        for metric,direction in metrics:
            x=other.loc[common,metric].astype(float).to_numpy(); y=full.loc[common,metric].astype(float).to_numpy()
            p=math.nan; stat=math.nan
            if wilcoxon is not None and len(common)>=2 and not np.allclose(x,y):
                try: stat,p=wilcoxon(x,y,alternative="two-sided")
                except Exception: pass
            tests.append({"algorithm":method,"Algorithm":DISPLAY[method],"metric":metric,"n_pairs":len(common),
                          "other_mean":float(np.mean(x)) if len(x) else math.nan,"full_mean":float(np.mean(y)) if len(y) else math.nan,
                          "wilcoxon_stat":stat,"p_value":p,"direction":direction})
    pd.DataFrame(tests).to_csv(output_dir/"table7_pairwise_statistics.csv",index=False,encoding="utf-8-sig")

    ready=["# Table 7 ready-to-copy summary","", "## Table 7(a): nominal scheduling"]
    ready.append(_df_to_markdown(pd.DataFrame(rows)))
    ready += ["", "## Table 7(b): dynamic stress response", _df_to_markdown(pd.DataFrame(dyn_rows)), "", "## Secondary composite score", _df_to_markdown(score_summary.sort_values("BPS_rank"))]
    (output_dir/"table7_ready_to_copy.md").write_text("\n".join(ready),encoding="utf-8")


def main():
    ap=argparse.ArgumentParser(description="Formal Table 7 rerun using the revised dynamic-AHD + event-retyping main solver")
    ap.add_argument("--workbook",default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    ap.add_argument("--solver_module",default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--methods",default="all")
    ap.add_argument("--seeds",default=",".join(map(str,FORMAL_SEEDS)))
    ap.add_argument("--episodes",type=int,default=2000)
    ap.add_argument("--device",default="cuda")
    ap.add_argument("--eval_interval",type=int,default=20)
    ap.add_argument("--event_repeats",type=int,default=5)
    ap.add_argument("--output_dir",default="outputs_table7_dynamicAHD_retyping")
    ap.add_argument("--save_run_details",action="store_true")
    ap.add_argument("--resume",action="store_true")
    ap.add_argument("--smoke",action="store_true")
    ap.add_argument("--dry_run",action="store_true")
    args=ap.parse_args()
    root=Path(__file__).resolve().parent
    workbook=(root/args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    solver_path=(root/args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module)
    out=(root/args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    methods=METHODS if args.methods.strip().lower()=="all" else [x.strip() for x in args.methods.split(",") if x.strip()]
    bad=[x for x in methods if x not in METHODS]
    if bad: raise ValueError(f"Unknown methods: {bad}")
    seeds=parse_seeds(args.seeds)
    episodes=args.episodes
    if args.smoke:
        seeds=[seeds[0]]; episodes=2; args.eval_interval=1; args.event_repeats=1
    manifest={"runner_version":RUNNER_VERSION,"solver":str(solver_path),"solver_sha256":sha256(solver_path),"workbook":str(workbook),
              "methods":methods,"seeds":seeds,"episodes":episodes,"device":args.device,"eval_interval":args.eval_interval,"event_repeats":args.event_repeats,
              "budgets":FORMAL_BUDGETS,"scenarios":SCENARIOS,
              "protocol":"All methods share the uploaded main environment, event timing, dynamic AHD/retyping, task data, budgets and hard engineering feasible domain. Learned policies are retrained from scratch for every matched seed."}
    if args.dry_run:
        if not workbook.exists(): raise FileNotFoundError(workbook)
        if not solver_path.exists(): raise FileNotFoundError(solver_path)
        print(json.dumps(manifest,ensure_ascii=False,indent=2)); return
    solver=load_solver(solver_path)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but torch.cuda.is_available() is False. Use --device cpu for smoke tests.")
    base=solver.load_input_payload(workbook,scenario_id=None)
    base=force_formal_budgets(base)
    out.mkdir(parents=True,exist_ok=True); json_dump(out/"experiment_manifest.json",manifest)
    nominal_rows=[]; dynamic_rows=[]
    ckpt_dir=out/"completed_seed_checkpoints"; ckpt_dir.mkdir(exist_ok=True)
    for method in methods:
        for seed in seeds:
            ck=ckpt_dir/f"{method}_seed{seed}_ep{episodes}.json"
            if args.resume and ck.exists():
                obj=json.loads(ck.read_text(encoding="utf-8")); nominal_rows.append(obj["nominal"]); dynamic_rows.extend(obj["dynamic"]); print(f"[resume] {method} seed={seed}",flush=True); continue
            print(f"[Table7] {method} seed={seed} episodes={episodes}",flush=True)
            t0=time.perf_counter()
            planner,policy,actions,metrics,safety,best_ep=train_one(solver,base,method,seed,episodes,args.device,args.eval_interval,args.save_run_details,out/"run_details")
            runtime=time.perf_counter()-t0
            nominal={"runner_version":RUNNER_VERSION,"algorithm":method,"display_name":DISPLAY[method],"seed":seed,"episodes":episodes,"best_checkpoint_episode":best_ep,
                     "makespan":metrics["makespan"],"risk":metrics["risk"],"fatigue":metrics["fatigue"],"energy":metrics["energy"],"prep_time":metrics.get("prep_time",math.nan),
                     "budget_feasible":metrics["budget_feasible"],"nvs":metrics["nvs"],"decision_time_ms":safety["decision_time_ms"],"runtime_s":runtime}
            dyn=dynamic_eval(solver,base,method,policy,actions,seed,float(metrics["makespan"]),args.event_repeats)
            nominal_rows.append(nominal); dynamic_rows.extend(dyn); json_dump(ck,{"nominal":nominal,"dynamic":dyn})
            write_csv(out/"nominal_runs.csv",nominal_rows); write_csv(out/"dynamic_runs.csv",dynamic_rows)
    analyze(out)
    print(f"\nTable 7 completed. Outputs: {out}")

if __name__=="__main__": main()
