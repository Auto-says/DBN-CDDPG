from __future__ import annotations
"""Dedicated 2,000-episode P0/P1 projection-integrity diagnosis runner.

This runner intentionally separates the projection diagnosis from the
10,000-episode nominal benchmark and mechanism-ablation suites.
"""

import subprocess
import sys


if __name__ == "__main__":
    cmd = [
        sys.executable,
        "run_table8_formal.py",
        "--suite",
        "projection",
        "--episodes",
        "2000",
        "--eval_interval",
        "20",
    ]
    raise SystemExit(subprocess.call(cmd))
