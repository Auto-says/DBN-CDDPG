@echo off
python run_projection_diagnosis_2000.py
