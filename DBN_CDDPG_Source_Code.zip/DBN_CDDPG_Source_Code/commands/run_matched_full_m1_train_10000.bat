@echo off
cd /d "%~dp0\.."
python -u train_full_m1.py --variants full,m1_no_dbn --seeds 42,52,62,72,82,92,102,112,122,132 --episodes 10000 --eval-interval 50 --save-every 500 --device cuda --threads 1 --deterministic 0 --output-dir outputs_full_m1_10000 --resume
