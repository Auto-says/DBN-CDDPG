@echo off
cd /d "%~dp0\.."
python -u evaluate_full_m1.py --train-dir outputs_full_m1_10000 --output-dir outputs_full_m1_HE1_HE4 --variants full,m1_no_dbn --seeds 42,52,62,72,82,92,102,112,122,132 --scenarios nominal,HE-1,HE-4 --device cuda --threads 1 --deterministic 0
