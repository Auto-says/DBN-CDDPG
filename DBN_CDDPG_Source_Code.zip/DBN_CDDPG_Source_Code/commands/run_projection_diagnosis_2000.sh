#!/usr/bin/env bash
set -euo pipefail
python run_projection_diagnosis_2000.py
