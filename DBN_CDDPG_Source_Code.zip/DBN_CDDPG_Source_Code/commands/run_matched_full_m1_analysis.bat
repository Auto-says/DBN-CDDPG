@echo off
cd /d "%~dp0\.."
python -u analyze_full_m1.py --eval-dir outputs_full_m1_HE1_HE4
