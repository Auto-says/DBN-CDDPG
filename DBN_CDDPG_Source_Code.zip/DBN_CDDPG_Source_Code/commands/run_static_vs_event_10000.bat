@echo off
python run_static_vs_event_HE1_HE4.py --workbook data/case2_22tasks_dynamicAHD_retyping.xlsx --solver_module dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py --seeds 2,3,4,5,6,7,8,9,10,11 --episodes 10000 --device cuda --eval_interval 50 --output_dir outputs_static_vs_event_10000 --save_run_details --resume
