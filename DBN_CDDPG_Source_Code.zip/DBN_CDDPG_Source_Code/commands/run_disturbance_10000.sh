#!/usr/bin/env bash
set -euo pipefail
python run_table7_formal.py --workbook data/case2_22tasks_dynamicAHD_retyping.xlsx --solver_module dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py --methods dbn_cddpg --seeds 42,52,62,72,82,92,102,112,122,132 --episodes 10000 --device cuda --eval_interval 50 --event_repeats 1 --output_dir outputs_disturbance_10000 --save_run_details --resume
