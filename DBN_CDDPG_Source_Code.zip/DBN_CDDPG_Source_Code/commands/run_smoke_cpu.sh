#!/usr/bin/env bash
set -euo pipefail
python run_fourpanel_performance_10000.py --workbook data/case2_22tasks_dynamicAHD_retyping.xlsx --solver_module dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py --methods dbn_cddpg --seeds 42 --device cpu --smoke --output_dir outputs_smoke_cpu
