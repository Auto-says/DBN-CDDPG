@echo off
python run_table8_formal.py --workbook data/case2_22tasks_dynamicAHD_retyping.xlsx --solver_module dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py --suite all --variants all --seeds 42,52,62,72,82,92,102,112,122,132 --episodes 10000 --device cuda --eval_interval 50 --output_dir outputs_ablation_10000 --save_run_details --resume
