from __future__ import annotations

import argparse
import copy
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from experiment_common import (
    FORMAL_BUDGETS, FORMAL_SEEDS, StressEnvMixin, budget_diagnostics, checkpoint_key,
    deep_payload_with_params, force_formal_budgets, json_dump, load_solver, mean_sd,
    parse_seeds, set_all_seeds, sha256, write_csv,
)

try:
    from scipy.stats import wilcoxon
except Exception:  # pragma: no cover
    wilcoxon = None

RUNNER_VERSION = "table8-dynamicAHD-retyping-v2.0-nominal-aligned"


def _df_to_markdown(frame: pd.DataFrame) -> str:
    """Render a DataFrame as a Markdown table without the optional tabulate package."""
    if frame is None or frame.empty:
        return "_No rows._"

    def _cell(value: Any) -> str:
        try:
            if pd.isna(value):
                return ""
        except Exception:
            pass
        if isinstance(value, (float, np.floating)):
            text = f"{float(value):.6g}"
        else:
            text = str(value)
        return text.replace("|", "\\|").replace("\n", " ")

    columns = [str(c) for c in frame.columns]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(_cell(v) for v in row) + " |")
    return "\n".join(lines)


DYNAMIC_STRESS_EVENTS = [
    {"completed_tasks": 7, "ahd_multiplier": 1.9, "risk_multiplier": 1.4, "fatigue_shock": 0.9},
    {"completed_tasks": 14, "ahd_multiplier": 1.3, "risk_multiplier": 1.7, "fatigue_shock": 0.9},
]

VARIANTS: Dict[str, Dict[str, Any]] = {
    "m1_no_dbn": {
        "configuration": "M1 No DBN inference",
        "description": "Removes DBN posterior state and DBN mode guidance while retaining dynamic AHD, event retyping, four stationary critics, adaptive constraints, and hard projection.",
        "params": {"use_dbn_state": 0, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0, "dbn_guidance_strength": 0.0},
    },
    "m2_no_dbn_guidance": {
        "configuration": "M2 No DBN guidance",
        "description": "Keeps DBN posterior in the state but removes posterior guidance from mode decoding; all other Full mechanisms are retained.",
        "params": {"use_dbn_state": 1, "use_dbn_mode_bias": 0, "use_posterior_mapping": 0, "dbn_guidance_strength": 0.0},
    },
    "m3_no_dynamic_ahd": {
        "configuration": "M3 No dynamic AHD",
        "description": "Uses frozen baseline AHD instead of event-wise dynamic AHD. Fatigue/resource evidence and the common engineering feasible domain remain available.",
        "params": {"use_dynamic_ahd": 0},
    },
    "m4_fixed_penalty": {
        "configuration": "M4 Fixed penalty",
        "description": "Freezes the initial energy/AHD/fatigue penalty weights and disables adaptive dual updating; DBN, dynamic AHD, event retyping and hard projection are retained.",
        "params": {"adaptive_lagrange": 0},
    },
    "m5_reward_mixing": {
        "configuration": "M5 Reward mixing",
        "description": "Replaces the four stationary cost critics and parameter-space common-descent actor update with a single scalar reward critic; the environment, DBN and hard projection are unchanged.",
        "params": {"adaptive_lagrange": 1},
        "agent": "reward_mixing",
    },
    "full": {
        "configuration": "Full DBN-CDDPG",
        "description": "Exact revised main protocol: dynamic AHD + event I/III/IV retyping + DBN guidance + hard projection + four stationary critics + parameter-space violation-aware common descent.",
        "params": {"adaptive_lagrange": 1},
    },
    "p1_penalty_only_no_projection": {
        "configuration": "P1 Penalty-only, no projection",
        "description": "Projection diagnosis only. Raw actor proposals are executed only when already valid; invalid proposals are rejected and penalized, and repeated invalid proposals terminate the episode as incomplete.",
        "params": {"adaptive_lagrange": 1, "invalid_action_penalty": 25.0, "max_invalid_streak": 5, "max_decision_multiplier": 5},
        "agent": "no_projection",
        "projection_mode": "penalty_only",
    },
}
MAIN_ORDER = ["m1_no_dbn", "m2_no_dbn_guidance", "m3_no_dynamic_ahd", "m4_fixed_penalty", "m5_reward_mixing", "full"]
PROJECTION_ORDER = ["full", "p1_penalty_only_no_projection"]

BASE_PARAMS = {
    "gamma": 1.0, "batch_size": 64, "buffer_size": 50000, "warmup_steps": 128, "update_every": 4,
    "hidden_dim": 128, "actor_lr": 1e-4, "critic_lr": 3e-4, "target_tau": 0.01,
    "noise_start": 0.30, "noise_end": 0.05, "noise_decay_fraction": 0.80,
    "projection_temperature": 0.25, "actor_backward_temperature": 1.0, "actor_output_bound": 1.0,
    "dbn_guidance_strength": 0.35, "lambda_update_lr": 0.02, "lambda_max": 20.0,
    "use_dbn_state": 1, "use_dbn_mode_bias": 1, "use_posterior_mapping": 1,
    "use_ahd_reward": 1, "use_dynamic_ahd": 1, "use_event_retyping": 1,
    "dynamic_stress_ahd_cap": 625.0,
}


def raw_proposal(env, action_vector: np.ndarray):
    arr=np.asarray(action_vector,dtype=np.float32).reshape(-1)
    n=env.n_tasks; nm=3
    task_pos=int(np.argmax(arr[:n])); tid=env.p.topo_order[task_pos]
    mode_scores=arr[n:n+nm].copy()
    if int(env.params.get("use_dbn_mode_bias",1))!=0 and int(env.params.get("use_posterior_mapping",1))!=0:
        beta=env.beta_map.get(tid,np.zeros(3,np.float32)); mode_scores += float(env.params.get("dbn_guidance_strength",0.35))*beta
    mi=int(np.argmax(mode_scores)); mode=("H","R","HRC")[mi]
    bind_scores=arr[n+nm:].copy()
    # availability is a preference bonus, not a validity mask
    candidates=env.candidate_bindings(tid,mode)
    valid_bind={int(c.binding_index):c for c in candidates}
    for bi,c in valid_bind.items(): bind_scores[bi]+=float(env._candidate_binding_availability_bonus(c))
    bi=int(np.argmax(bind_scores)); c=valid_bind.get(bi)
    reason="valid"; valid=True
    if env.completed[task_pos]>0.5 or tid not in set(env.ready_tasks()): valid=False; reason="task"
    elif mode not in env.feasible_modes(tid): valid=False; reason="mode"
    elif c is None: valid=False; reason="binding"
    if c is None:
        human_id=robot_id=None
    else:
        human_id=getattr(c,"human_id",None); robot_id=getattr(c,"robot_id",None)
    return {"valid":valid,"reason":reason,"task_id":tid,"task_pos":task_pos,"mode":mode,"mode_index":mi,"binding_index":bi,
            "human_id":human_id,"robot_id":robot_id}


def raw_to_onehot(env, raw):
    vec=np.zeros(env.n_tasks+3+env.binding_dim,dtype=np.float32)
    vec[int(raw["task_pos"])]=1.0; vec[env.n_tasks+int(raw["mode_index"])]=1.0; vec[env.n_tasks+3+int(raw["binding_index"])]=1.0
    return vec


def make_diagnostic_env(solver, *, penalty_only: bool):
    """Nominal diagnostic environment aligned with Table 7 training.

    IMPORTANT: no external stress is injected during Table 8 training or
    checkpoint evaluation.  The extra logic below is observational only: it
    counts raw invalid proposals / projection interventions, but executes the
    same uploaded ``DBNCDDPGEnv.step`` semantics as Table 7.
    """
    class Env(solver.DBNCDDPGEnv):
        def reset(self):
            self.proposal_count=0; self.invalid_proposals=0; self.projection_interventions=0
            self.invalid_task_proposals=0; self.invalid_mode_proposals=0; self.invalid_binding_proposals=0
            self.invalid_streak=0; self.decision_count=0; self.termination_reason="running"
            return super().reset()
        def metrics(self):
            m=dict(super().metrics()); completed=int(np.count_nonzero(self.completed>0.5)); total=int(self.n_tasks)
            m.update({"completed_tasks":completed,"total_tasks":total,"completion_ratio":completed/max(total,1),"is_complete":int(completed==total),
                      "proposal_count":int(getattr(self,"proposal_count",0)),"invalid_proposals":int(getattr(self,"invalid_proposals",0)),
                      "invalid_proposal_rate":float(getattr(self,"invalid_proposals",0))/max(int(getattr(self,"proposal_count",0)),1),
                      "invalid_task_proposals":int(getattr(self,"invalid_task_proposals",0)),"invalid_mode_proposals":int(getattr(self,"invalid_mode_proposals",0)),
                      "invalid_binding_proposals":int(getattr(self,"invalid_binding_proposals",0)),"projection_interventions":int(getattr(self,"projection_interventions",0)),
                      "projection_intervention_rate":float(getattr(self,"projection_interventions",0))/max(int(getattr(self,"proposal_count",0)),1),
                      "decision_count":int(getattr(self,"decision_count",0)),"termination_reason":str(getattr(self,"termination_reason","running"))})
            m["deadlock"]=int(m["is_complete"]==0 and m["termination_reason"] not in {"running","completed"})
            return m
        def _mark_invalid(self,reason):
            self.invalid_proposals+=1
            if reason=="task": self.invalid_task_proposals+=1
            elif reason=="mode": self.invalid_mode_proposals+=1
            elif reason=="binding": self.invalid_binding_proposals+=1
        def step(self,action_vector,projection_context=None):
            self.proposal_count+=1; self.decision_count+=1
            raw=raw_proposal(self,action_vector)
            if not raw["valid"]: self._mark_invalid(raw["reason"])
            if penalty_only and not raw["valid"]:
                self.invalid_streak+=1
                max_streak=int(self.params.get("max_invalid_streak",5)); max_dec=int(self.params.get("max_decision_multiplier",5))*self.n_tasks
                done=self.invalid_streak>=max_streak or self.decision_count>=max_dec
                if done: self.termination_reason="invalid_action_deadlock" if self.invalid_streak>=max_streak else "decision_limit"
                info=self.metrics(); info["executed_action_vector"]=np.asarray(action_vector,dtype=np.float32).copy(); info["transition_deltas"]=np.zeros(4,np.float32); info["invalid_reason"]=raw["reason"]
                return self.get_state(),-abs(float(self.params.get("invalid_action_penalty",25.0))),bool(done),info
            # Valid P1 proposals are converted to exact hard one-hot actions.
            # Full/ablation variants pass the unchanged preference vector to
            # the uploaded environment, exactly as Table 7 does.
            to_execute=raw_to_onehot(self,raw) if penalty_only else action_vector
            if not penalty_only:
                projected,_=solver.DBNCDDPGEnv.decode_action(self,action_vector,context=projection_context)
                sig=(int(projected.task_id),str(projected.mode),int(projected.binding_index))
                rawsig=(int(raw["task_id"]),str(raw["mode"]),int(raw["binding_index"])) if raw["valid"] else None
                if (not raw["valid"]) or rawsig!=sig: self.projection_interventions+=1
            state,reward,done,info=super().step(to_execute,projection_context=projection_context)
            self.invalid_streak=0
            if done: self.termination_reason="completed"
            merged=self.metrics(); merged["executed_action_vector"]=info["executed_action_vector"]; merged["transition_deltas"]=info["transition_deltas"]
            return state,float(reward),bool(done),merged
    return Env

def make_planner(solver, base_data, variant: str):
    overrides=dict(BASE_PARAMS); overrides.update(VARIANTS[variant].get("params",{})); overrides["table8_variant"]=variant
    data=force_formal_budgets(deep_payload_with_params(base_data,overrides))
    penalty=variant=="p1_penalty_only_no_projection"
    Env=make_diagnostic_env(solver,penalty_only=penalty)
    allow_dual=variant not in {"m4_fixed_penalty"}
    class Planner(solver.DBNCDDPGPlanner):
        def make_env(self): return Env(self)
        def update_constraint_lambdas(self,metrics):
            if not allow_dual: return
            return super().update_constraint_lambdas(metrics)
    return Planner(data)


def make_reward_mixing_agent(solver):
    class RewardMixingAgent(solver.DDPGAgent):
        """Single scalar reward critic, preserving the uploaded actor/projection implementation."""
        def update(self):
            self.update_calls+=1
            if self.update_calls%self.update_every!=0 or len(self.replay)<max(self.batch_size,self.warmup_steps):
                return {"critic_loss":0.0,"actor_loss":0.0,"noise":self._noise()}
            state,action,reward,deltas,next_state,done,context,next_context=self.replay.sample(self.batch_size)
            s=torch.as_tensor(state,dtype=torch.float32,device=self.device); a=torch.as_tensor(action,dtype=torch.float32,device=self.device)
            r=torch.as_tensor(reward,dtype=torch.float32,device=self.device); ns=torch.as_tensor(next_state,dtype=torch.float32,device=self.device); d=torch.as_tensor(done,dtype=torch.float32,device=self.device)
            critic=self.critics["performance"]; target=self.critic_targets["performance"]; opt=self.critic_opts["performance"]
            with torch.no_grad():
                na=self.project_action(self.actor_target(ns),next_context,straight_through=False); y=r+(1.0-d)*self.gamma*target(ns,na)
            q=critic(s,a); cl=torch.nn.functional.mse_loss(q,y); opt.zero_grad(); cl.backward(); torch.nn.utils.clip_grad_norm_(critic.parameters(),5.0); opt.step()
            for p in critic.parameters(): p.requires_grad_(False)
            aa=self.project_action(self.actor(s),context,straight_through=True); al=-critic(s,aa).mean(); self.actor_opt.zero_grad(); al.backward(); torch.nn.utils.clip_grad_norm_(self.actor.parameters(),5.0); self.actor_opt.step()
            for p in critic.parameters(): p.requires_grad_(True)
            self._soft_update(self.actor,self.actor_target); self._soft_update(critic,target); self.learn_steps+=1
            return {"critic_loss":float(cl.item()),"actor_loss":float(al.item()),"noise":self._noise(),"reward_mixing":1.0}
    return RewardMixingAgent


def make_no_projection_agent(solver):
    class NoProjectionAgent(solver.DDPGAgent):
        def project_action(self,raw_action,context,straight_through):
            # P1 intentionally removes the hard feasible-domain projection from learning.
            return raw_action
    return NoProjectionAgent


def snapshot(agent): return {k:v.detach().cpu().clone() for k,v in agent.actor.state_dict().items()}
def restore(agent,snap): agent.actor.load_state_dict(snap); agent.actor_target.load_state_dict(snap)


def eval_agent(planner,agent,*,penalty_only=False):
    env=planner.make_env(); state=env.reset(); done=False; decision_seconds=0.0; decisions=0
    while not done:
        ctx=env.projection_context(); t0=time.perf_counter(); action=agent.act(state,explore=False); decision_seconds+=time.perf_counter()-t0
        state,_,done,_=env.step(action,projection_context=ctx); decisions+=1
    m=env.metrics(); m.update(budget_diagnostics(m)); m["decision_time_ms"]=1000*decision_seconds/max(decisions,1)
    return m,env


def selection_key(metrics):
    complete=int(metrics.get("is_complete",0))==1; d=budget_diagnostics(metrics); c=int(metrics.get("completed_tasks",0)); ms=float(metrics.get("makespan",math.inf))
    if complete and d["budget_feasible"]>0.5: return (0,ms,d["nvs"])
    if complete: return (1,d["nvs"],ms)
    return (2,-c,ms)


def train_variant(solver,base_data,variant,seed,episodes,device,eval_interval,save_details,detail_dir):
    set_all_seeds(seed); planner=make_planner(solver,base_data,variant); planner.params["_total_training_steps"]=int(episodes*len(planner.topo_order))
    probe=planner.make_env(); state_dim=probe.state_dim; action_dim=len(planner.topo_order)+3+planner.binding_dim
    if variant=="m5_reward_mixing": Agent=make_reward_mixing_agent(solver)
    elif variant=="p1_penalty_only_no_projection": Agent=make_no_projection_agent(solver)
    else: Agent=solver.DDPGAgent
    agent=Agent(state_dim,action_dim,planner,device=device); best=None; best_key=(9,math.inf,math.inf); best_ep=0; history=[]
    for ep in range(1,episodes+1):
        env=planner.make_env(); state=env.reset(); done=False; last={"critic_loss":0.0,"actor_loss":0.0}
        while not done:
            ctx=env.projection_context(); action=agent.act(state,explore=True); ns,reward,done,info=env.step(action,projection_context=ctx); nctx=env.projection_context()
            agent.replay.push(state,info["executed_action_vector"],reward,ns,done,ctx,nctx,transition_deltas=info.get("transition_deltas",np.zeros(4,np.float32)))
            last=agent.update(); state=ns
        tm=env.metrics()
        if variant!="m4_fixed_penalty" and int(tm.get("is_complete",0))==1: planner.update_constraint_lambdas(tm)
        if ep%max(1,eval_interval)==0 or ep==episodes:
            em,_=eval_agent(planner,agent,penalty_only=variant=="p1_penalty_only_no_projection"); key=selection_key(em)
            history.append({"episode":ep,"is_complete":em["is_complete"],"completed_tasks":em["completed_tasks"],"makespan":em["makespan"],"risk":em["risk"],"energy":em["energy"],"fatigue":em["fatigue"],"nvs":em["nvs"],"budget_feasible":em["budget_feasible"],
                            "invalid_proposal_rate":em["invalid_proposal_rate"],"projection_intervention_rate":em["projection_intervention_rate"],
                            "lambda_energy":float(planner.params.get("lambda_energy",0)),"lambda_risk":float(planner.params.get("lambda_risk",0)),"lambda_fatigue":float(planner.params.get("lambda_fatigue",0)),
                            "critic_loss":float(last.get("critic_loss",0)),"actor_loss":float(last.get("actor_loss",0))})
            if key<best_key: best_key=key; best=snapshot(agent); best_ep=ep
    if best is None: raise RuntimeError("No checkpoint")
    restore(agent,best); metrics,env=eval_agent(planner,agent,penalty_only=variant=="p1_penalty_only_no_projection")
    if save_details:
        d=detail_dir/variant/f"seed_{seed}"; d.mkdir(parents=True,exist_ok=True); write_csv(d/"training_history.csv",history); write_csv(d/"schedule.csv",[vars(x) for x in env.schedule])
        if getattr(env,"dbn_trace",None): write_csv(d/"dbn_trace.csv",env.dbn_trace)
        if getattr(env,"task_type_trace",None): write_csv(d/"task_type_trace.csv",env.task_type_trace)
        if getattr(env,"dynamic_ahd_trace",None): write_csv(d/"dynamic_ahd_trace.csv",env.dynamic_ahd_trace)
    return metrics,best_ep


def row_from_metrics(variant,seed,episodes,best_ep,runtime,metrics):
    complete=int(metrics.get("is_complete",0))==1
    return {"runner_version":RUNNER_VERSION,"variant":variant,"configuration":VARIANTS[variant]["configuration"],"description":VARIANTS[variant]["description"],"seed":seed,"episodes":episodes,"best_checkpoint_episode":best_ep,
            "is_complete":int(complete),"completed_tasks":int(metrics.get("completed_tasks",0)),"total_tasks":int(metrics.get("total_tasks",0)),"completion_ratio":float(metrics.get("completion_ratio",0)),
            "makespan":float(metrics["makespan"]) if complete else math.nan,"ahd":float(metrics["risk"]) if complete else math.nan,"energy":float(metrics["energy"]) if complete else math.nan,"fatigue":float(metrics["fatigue"]) if complete else math.nan,
            "partial_makespan":float(metrics.get("makespan",0)),"partial_ahd":float(metrics.get("risk",0)),"partial_energy":float(metrics.get("energy",0)),"partial_fatigue":float(metrics.get("fatigue",0)),
            "budget_feasible":int(complete and metrics.get("budget_feasible",0)>0.5),"nvs":float(metrics.get("nvs",math.nan)) if complete else math.nan,
            "proposal_count":int(metrics.get("proposal_count",0)),"invalid_proposals":int(metrics.get("invalid_proposals",0)),"invalid_proposal_rate":float(metrics.get("invalid_proposal_rate",0)),
            "invalid_task_proposals":int(metrics.get("invalid_task_proposals",0)),"invalid_mode_proposals":int(metrics.get("invalid_mode_proposals",0)),"invalid_binding_proposals":int(metrics.get("invalid_binding_proposals",0)),
            "projection_interventions":int(metrics.get("projection_interventions",0)),"projection_intervention_rate":float(metrics.get("projection_intervention_rate",0)),"deadlock":int(metrics.get("deadlock",0)),"termination_reason":str(metrics.get("termination_reason","unknown")),
            "decision_time_ms":float(metrics.get("decision_time_ms",math.nan)),"runtime_s":runtime}


def summarize(runs: pd.DataFrame, order: Sequence[str]):
    rows=[]
    for v in order:
        g=runs[runs.variant==v]
        if g.empty: continue
        rec={"variant":v,"configuration":VARIANTS[v]["configuration"],"n_runs":len(g),"n_complete":int(g.is_complete.sum()),"completion_rate_pct":100*float(g.is_complete.mean()),"ABFR_pct":100*float(g.budget_feasible.mean()),
             "completed_tasks_mean":float(g.completed_tasks.mean()),"invalid_proposal_rate_pct":100*float(g.invalid_proposal_rate.mean()),"projection_intervention_rate_pct":100*float(g.projection_intervention_rate.mean()),"deadlock_rate_pct":100*float(g.deadlock.mean()),"runtime_s_mean":float(g.runtime_s.mean())}
        for col in ["makespan","ahd","energy","fatigue","nvs","decision_time_ms"]:
            m,sd,n=mean_sd(g[col]); rec[col+"_mean"]=m;rec[col+"_sd"]=sd;rec[col+"_n"]=n
        rows.append(rec)
    return pd.DataFrame(rows)


def _holm_adjust(p_values):
    """Holm step-down family-wise error correction; NaNs remain NaN."""
    arr=np.asarray(p_values,dtype=float)
    out=np.full(arr.shape,np.nan,dtype=float)
    valid=np.flatnonzero(np.isfinite(arr))
    if len(valid)==0: return out
    order=valid[np.argsort(arr[valid])]
    m=len(order); running=0.0
    for rank,idx in enumerate(order):
        adj=min(1.0,(m-rank)*float(arr[idx]))
        running=max(running,adj)
        out[idx]=running
    return out


def paired_tests(runs:pd.DataFrame):
    out=[]; full=runs[runs.variant=="full"].set_index("seed")
    for v in MAIN_ORDER:
        if v=="full": continue
        o=runs[runs.variant==v].set_index("seed"); common=full.index.intersection(o.index)
        for metric in ["makespan","ahd","energy","fatigue","nvs"]:
            x=pd.to_numeric(o.loc[common,metric],errors="coerce"); y=pd.to_numeric(full.loc[common,metric],errors="coerce"); valid=x.notna()&y.notna(); xv=x[valid].to_numpy();yv=y[valid].to_numpy();p=math.nan;stat=math.nan
            if wilcoxon is not None and len(xv)>=2 and not np.allclose(xv,yv):
                try: stat,p=wilcoxon(xv,yv)
                except Exception: pass
            out.append({"variant":v,"configuration":VARIANTS[v]["configuration"],"metric":metric,"n_pairs":len(xv),"variant_mean":float(np.mean(xv)) if len(xv) else math.nan,"full_mean":float(np.mean(yv)) if len(yv) else math.nan,"wilcoxon_stat":stat,"p_value":p})
    frame=pd.DataFrame(out)
    if not frame.empty:
        frame["p_holm"]=np.nan
        # Correct the five metric tests within each ablation-vs-Full family.
        for v,idx in frame.groupby("variant").groups.items():
            idx=list(idx); frame.loc[idx,"p_holm"]=_holm_adjust(frame.loc[idx,"p_value"].to_numpy())
        frame["significant_holm_0_05"]=(frame["p_holm"]<0.05).fillna(False).astype(int)
        # Manuscript sensitivity analysis: experiment-wide family of 20 ablation tests
        # (5 ablations x 4 engineering metrics: Cmax, AHD, fatigue, energy).
        eng = frame[frame["variant"].isin([v for v in MAIN_ORDER if v != "full"])].copy()
        eng = eng[eng["metric"].isin(["makespan", "ahd", "fatigue", "energy"])]
        frame["p_holm_20"] = np.nan
        if not eng.empty:
            adjusted = _holm_adjust(eng["p_value"].to_numpy())
            frame.loc[eng.index, "p_holm_20"] = adjusted
        frame["significant_holm_20_0_05"] = (frame["p_holm_20"] < 0.05).fillna(False).astype(int)
    return frame

def write_outputs(out:Path,main_rows,proj_rows):
    main=pd.DataFrame(main_rows); proj=pd.DataFrame(proj_rows)
    main.to_csv(out/"table8_main_runs.csv",index=False,encoding="utf-8-sig"); sm=summarize(main,MAIN_ORDER); sm.to_csv(out/"table8_main_summary.csv",index=False,encoding="utf-8-sig")
    sm.to_csv(out/"table8a_paper_ready.csv",index=False,encoding="utf-8-sig"); paired_tests(main).to_csv(out/"table8_paired_tests_vs_full.csv",index=False,encoding="utf-8-sig")
    proj.to_csv(out/"table8_projection_runs.csv",index=False,encoding="utf-8-sig"); sp=summarize(proj,PROJECTION_ORDER); sp.to_csv(out/"table8_projection_summary.csv",index=False,encoding="utf-8-sig"); sp.to_csv(out/"table8b_projection_diagnosis.csv",index=False,encoding="utf-8-sig")
    trace=[]
    for v in MAIN_ORDER+PROJECTION_ORDER:
        if any(x["variant"]==v for x in trace): continue
        trace.append({"variant":v,"configuration":VARIANTS[v]["configuration"],"changed_mechanism":VARIANTS[v]["description"],"same_uploaded_environment":1,"nominal_training_aligned_with_table7":1,"external_stress_during_training":0,"same_budgets":1,"same_hard_projection":0 if v=="p1_penalty_only_no_projection" else 1})
    pd.DataFrame(trace).to_csv(out/"table8c_traceability.csv",index=False,encoding="utf-8-sig")
    md=["# Table 8 ready-to-copy summary","","## Table 8(a) component ablation",_df_to_markdown(sm),"","## Table 8(b) projection diagnosis",_df_to_markdown(sp)]
    (out/"table8_ready_to_copy.md").write_text("\n".join(md),encoding="utf-8")


def main():
    ap=argparse.ArgumentParser(description="Formal Table 8 nominal ablation rerun aligned with Table 7 using the revised dynamic-AHD + event-retyping main solver")
    ap.add_argument("--workbook",default="data/case2_22tasks_dynamicAHD_retyping.xlsx"); ap.add_argument("--solver_module",default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--suite",choices=["main","projection","all"],default="main"); ap.add_argument("--variants",default="all"); ap.add_argument("--seeds",default=",".join(map(str,FORMAL_SEEDS)))
    ap.add_argument("--episodes",type=int,default=10000); ap.add_argument("--device",default="cuda"); ap.add_argument("--eval_interval",type=int,default=50); ap.add_argument("--output_dir",default="outputs_table8_dynamicAHD_retyping")
    ap.add_argument("--save_run_details",action="store_true"); ap.add_argument("--resume",action="store_true"); ap.add_argument("--smoke",action="store_true"); ap.add_argument("--dry_run",action="store_true")
    args=ap.parse_args(); root=Path(__file__).resolve().parent
    workbook=(root/args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook); solver_path=(root/args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module); out=(root/args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    seeds=parse_seeds(args.seeds); episodes=args.episodes
    requested=MAIN_ORDER if args.variants.lower()=="all" else [x.strip() for x in args.variants.split(",") if x.strip()]
    bad=[x for x in requested if x not in MAIN_ORDER];
    if bad: raise ValueError(f"Unknown variants: {bad}")
    if args.smoke: seeds=[seeds[0]]; episodes=2; args.eval_interval=1
    manifest={"runner_version":RUNNER_VERSION,"projection_training_consistent":True,"full_solver_protocol":"uploaded revised main: dynamic AHD + event I/III/IV retyping + DBN + four stationary critics + parameter-space common descent",
              "checkpoint_protocol":"feasibility-first lexicographic; incomplete schedules never enter paper-facing Cmax/AHD/E/F statistics","workbook":str(workbook),"solver_module":str(solver_path),"solver_sha256":sha256(solver_path),
              "suite":args.suite,"seeds":seeds,"episodes":episodes,"device":args.device,"budgets":FORMAL_BUDGETS,"main_variants":requested,"projection_variants":PROJECTION_ORDER,"training_environment":"nominal; aligned with Table 7 DBN-CDDPG","dynamic_stress":{"enabled_during_training":0,"events_retained_for_optional_external_analysis_only":DYNAMIC_STRESS_EVENTS},
              "critical_rule":"Paper-facing Cmax/AHD/E/F are calculated only from complete schedules. Partial totals remain diagnostic fields and are never treated as performance results."}
    if args.dry_run:
        if not workbook.exists(): raise FileNotFoundError(workbook)
        if not solver_path.exists(): raise FileNotFoundError(solver_path)
        print(json.dumps(manifest,ensure_ascii=False,indent=2)); return
    solver=load_solver(solver_path)
    if args.device.startswith("cuda") and not torch.cuda.is_available(): raise RuntimeError("CUDA requested but unavailable")
    base=force_formal_budgets(solver.load_input_payload(workbook,scenario_id=None)); out.mkdir(parents=True,exist_ok=True); json_dump(out/"table8_manifest.json",manifest)
    main_rows=[];proj_rows=[]; ck=out/"completed_seed_checkpoints";ck.mkdir(exist_ok=True)
    jobs=[]
    if args.suite in {"main","all"}: jobs += [(v,"main") for v in requested]
    # In suite=all, Full is trained exactly once in the main suite.  The same
    # Full run is then reused as the reference row in Table 8(b), avoiding a
    # second stochastic training run of the identical algorithm.
    if args.suite=="projection": jobs += [(v,"projection") for v in PROJECTION_ORDER]
    elif args.suite=="all": jobs += [("p1_penalty_only_no_projection","projection")]
    for variant,kind in jobs:
        for seed in seeds:
            cp=ck/f"{kind}_{variant}_seed{seed}_ep{episodes}.json"
            if args.resume and cp.exists(): row=json.loads(cp.read_text(encoding="utf-8")); (main_rows if kind=="main" else proj_rows).append(row); print(f"[resume] {kind} {variant} seed={seed}",flush=True); continue
            print(f"[Table8] {kind} {variant} seed={seed} episodes={episodes}",flush=True); t0=time.perf_counter(); metrics,best_ep=train_variant(solver,base,variant,seed,episodes,args.device,args.eval_interval,args.save_run_details,out/"run_details"); runtime=time.perf_counter()-t0; row=row_from_metrics(variant,seed,episodes,best_ep,runtime,metrics); (main_rows if kind=="main" else proj_rows).append(row); json_dump(cp,row)
            if main_rows: write_csv(out/"table8_main_runs.csv",main_rows)
            if proj_rows: write_csv(out/"table8_projection_runs.csv",proj_rows)
    if args.suite=="all":
        # Reuse the already-trained nominal Full checkpoints in projection
        # diagnosis.  This guarantees Table 8(a) Full and Table 8(b) Full are
        # literally the same runs rather than two retrainings.
        existing={(int(r.get("seed",-1)),str(r.get("variant",""))) for r in proj_rows}
        for r in main_rows:
            if str(r.get("variant"))=="full" and (int(r.get("seed",-1)),"full") not in existing:
                q=dict(r); q["projection_reference_reused_from_main"]=1; proj_rows.append(q)
    if not main_rows and (out/"table8_main_runs.csv").exists(): main_rows=pd.read_csv(out/"table8_main_runs.csv").to_dict("records")
    if not proj_rows and (out/"table8_projection_runs.csv").exists(): proj_rows=pd.read_csv(out/"table8_projection_runs.csv").to_dict("records")
    if main_rows and proj_rows: write_outputs(out,main_rows,proj_rows)
    elif main_rows:
        main=pd.DataFrame(main_rows); main.to_csv(out/"table8_main_runs.csv",index=False,encoding="utf-8-sig"); summarize(main,MAIN_ORDER).to_csv(out/"table8_main_summary.csv",index=False,encoding="utf-8-sig"); summarize(main,MAIN_ORDER).to_csv(out/"table8a_paper_ready.csv",index=False,encoding="utf-8-sig"); paired_tests(main).to_csv(out/"table8_paired_tests_vs_full.csv",index=False,encoding="utf-8-sig")
    elif proj_rows:
        proj=pd.DataFrame(proj_rows); proj.to_csv(out/"table8_projection_runs.csv",index=False,encoding="utf-8-sig"); summarize(proj,PROJECTION_ORDER).to_csv(out/"table8_projection_summary.csv",index=False,encoding="utf-8-sig"); summarize(proj,PROJECTION_ORDER).to_csv(out/"table8b_projection_diagnosis.csv",index=False,encoding="utf-8-sig")
    print(f"\nTable 8 completed. Outputs: {out}")

if __name__=="__main__": main()
