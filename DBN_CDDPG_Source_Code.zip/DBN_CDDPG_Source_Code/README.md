# DBN-CDDPG Source Code

This archive contains the source code used for the revised manuscript **Dynamic Bayesian Inference-Driven Safe Human-Robot Collaborative Disassembly Planning for Retired Power Batteries**.

## Main experiment runners

- `run_fourpanel_performance_10000.py`: six-method nominal benchmark and paired statistics (Tables 8-9; Fig. 8).
- `run_table7_formal.py`: original four-scenario DBN-CDDPG disturbance evaluation (Table 10).
- `run_static_vs_event_HE1_HE4.py`: static-versus-event-driven nominal and HE-1/HE-4 evaluation (Tables 11-12).
- `run_table8_formal.py`: Full/M1-M5 mechanism ablation (Table 14; Fig. 10(a)-(b)).
- `run_projection_diagnosis_2000.py`: separate P0/P1 projection-integrity diagnosis (Fig. 10(c)).

The `commands/` directory provides Windows `.bat` and Linux/macOS `.sh` wrappers for these experiment families.

## Matched Full/M1 extension (Section 5.6)

The final revision additionally includes a saved-actor matched evaluation of Full and M1 under nominal, HE-1, and HE-4 conditions.

- `train_full_m1.py`: trains Full and M1 on the nominal environment only, preserves reloadable selected actors, and supports episode-boundary resume.
- `evaluate_full_m1.py`: reloads the selected actors and evaluates nominal, HE-1, and HE-4 **without learning, parameter tuning, or checkpoint reselection**. It also records same-state explicit-guidance on/off decoding.
- `analyze_full_m1.py`: recomputes the eight paired Full-M1 engineering tests used in Appendix Table C6 and extracts the explicit-guidance changes reported in Table 17.
- `full_m1_support.py`: checkpoint, provenance, runtime, and reload helpers.
- `RECORDED_EVALUATION_ENVIRONMENT.json`: software/hardware manifest recorded for the saved-actor evaluation.
- `MATCHED_FULL_M1_PROVENANCE.json`: scope and provenance of this extension.

Convenience commands:

```text
commands/run_matched_full_m1_train_10000.*
commands/run_matched_full_m1_HE1_HE4_eval.*
commands/run_matched_full_m1_analysis.*
```

The matched evaluation output archive is released separately as `matched_full_m1_HE1_HE4_evaluation.zip`. The evaluation runner expects the corresponding reloadable `best_actor.pt` files under `outputs_full_m1_10000/runs/<variant>/seed_<seed>/` when reproducing trajectories from saved actors.

### Appendix Table C6 convention

For the Full-M1 comparison, differences are `Full - M1`. Engineering outcomes are rounded to four decimal places before ranking; zero differences are removed; tied absolute differences receive average ranks; two-sided exact Wilcoxon signed-rank probabilities are obtained by enumerating all sign assignments of the nonzero pairs; and Holm correction is applied once across the complete eight-test family (two disturbances x four outcomes). The 95% Student's t intervals describe paired mean differences using all ten matched pairs and are not simultaneous intervals.

## Environments

`requirements.txt` documents the pinned peer-review rerun environment for the core source package. The later matched Full/M1 saved-actor evaluation used a separately recorded environment; see `RECORDED_EVALUATION_ENVIRONMENT.json` and `requirements-matched-evaluation.txt`.

The original training runs were seed-controlled but did not enforce fully deterministic CUDA execution. Exact bitwise identity across independent GPU executions is not claimed.

## Integrity checks

Run:

```bash
python validation/verify_source.py
python check_environment.py --device cpu
```

Use `--device cuda` for the second command when validating a CUDA installation. `UPSTREAM_SHA256.json`, `SOURCE_PROVENANCE.json`, and `CHECKSUMS.sha256` provide source and package integrity metadata.

## Input data

The Case-2 workbook used by the packaged runners is:

```text
data/case2_22tasks_dynamicAHD_retyping.xlsx
```

The base H/R/HRC processing-time inputs are literature-derived simulation inputs as described in the manuscript; they are not independently measured timing-validation data.
