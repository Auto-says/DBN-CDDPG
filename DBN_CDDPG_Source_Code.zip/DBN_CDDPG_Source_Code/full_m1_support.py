"""Checkpoint and provenance helpers; the uploaded scientific solver is not modified."""
from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import random
import sys
from typing import Any

# Must be set before CUDA initialization; only enforced when --deterministic=1.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import experiment_common as common
import run_table8_formal as ablation

VERSION = "full-m1-reloadable-v1.0"
SOLVER_PATH = ROOT / "dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py"
DEFAULT_WORKBOOK = ROOT / "data" / "case2_22tasks_dynamicAHD_retyping.xlsx"
VARIANTS = ("full", "m1_no_dbn")
ENGINEERING_KEYS = ("makespan", "risk", "energy", "fatigue", "nvs", "is_complete", "completed_tasks")


def plain(x: Any) -> Any:
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, dict):
        return {k: plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    if isinstance(x, Path):
        return str(x)
    return x


def digest(x: Any) -> str:
    return hashlib.sha256(json.dumps(plain(x), sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode("utf-8")).hexdigest()


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(plain(obj), f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def atomic_torch(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("wb") as f:
        torch.save(obj, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def load_checkpoint(path: Path) -> dict:
    # Never pickle entire model classes or enable unrestricted pickle loading.
    result = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(result, dict) or result.get("format_version") != VERSION:
        raise ValueError(f"Unsupported checkpoint format: {path}")
    return result


def cpu_tree(x: Any) -> Any:
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().clone()
    if isinstance(x, dict):
        return {k: cpu_tree(v) for k, v in x.items()}
    if isinstance(x, tuple):
        return tuple(cpu_tree(v) for v in x)
    if isinstance(x, list):
        return [cpu_tree(v) for v in x]
    if isinstance(x, np.generic):
        return x.item()
    return copy.deepcopy(x)


def source_hashes() -> dict:
    # Preserve the historical ``upstream/...`` metadata keys used by the saved Full/M1
    # checkpoints while hashing the identical source files stored at the package root.
    mapping = {
        "upstream/dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py": SOLVER_PATH,
        "upstream/experiment_common.py": ROOT / "experiment_common.py",
        "upstream/run_table8_formal.py": ROOT / "run_table8_formal.py",
        "upstream/run_table7_formal.py": ROOT / "run_table7_formal.py",
        "full_m1_support.py": ROOT / "full_m1_support.py",
        "train_full_m1.py": ROOT / "train_full_m1.py",
    }
    return {name: common.sha256(path) for name, path in mapping.items()}


def configure_runtime(device: str, threads: int, deterministic: bool) -> dict:
    if device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Check your GPU PyTorch installation, "
                           "or explicitly use --device cpu. No automatic CPU fallback is used.")
    if threads > 0:
        torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(deterministic)
    if deterministic:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    versions = {name: importlib.metadata.version(name)
                for name in ("torch", "numpy", "pandas", "scipy", "openpyxl")}
    return {
        "python": platform.python_version(), "platform": platform.platform(),
        "machine": platform.machine(), "device": device,
        "device_name": torch.cuda.get_device_name(torch.device(device)) if device.startswith("cuda") else platform.processor(),
        "versions": versions, "torch_cuda_build": torch.version.cuda,
        "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "cudnn_deterministic": bool(torch.backends.cudnn.deterministic),
        "cudnn_benchmark": bool(torch.backends.cudnn.benchmark),
        "cuda_matmul_allow_tf32": bool(torch.backends.cuda.matmul.allow_tf32),
        "cudnn_allow_tf32": bool(torch.backends.cudnn.allow_tf32),
        "CUBLAS_WORKSPACE_CONFIG": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
    }


def rng_state() -> dict:
    n = np.random.get_state()
    return {
        "python": random.getstate(),
        "numpy": (n[0], torch.from_numpy(n[1].astype(np.int64)), int(n[2]), int(n[3]), float(n[4])),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
    }


def restore_rng(state: dict) -> None:
    random.setstate(state["python"])
    n = state["numpy"]
    np.random.set_state((n[0], n[1].numpy().astype(np.uint32), n[2], n[3], n[4]))
    torch.set_rng_state(state["torch_cpu"])
    if state["torch_cuda"]:
        if not torch.cuda.is_available():
            raise RuntimeError("Cannot resume a CUDA training checkpoint on CPU. Evaluation on CPU is supported.")
        torch.cuda.set_rng_state_all(state["torch_cuda"])


def pack_replay(replay) -> dict:
    """Columnar tensors avoid pickling NumPy objects and thousands of small tensors."""
    rows = list(replay.buffer)
    result = {"capacity": replay.capacity, "length": len(rows)}
    if not rows:
        return result
    result["columns"] = [torch.from_numpy(np.stack([r[i] for r in rows])) for i in range(6)]
    result["contexts"] = [
        {key: torch.from_numpy(np.stack([r[i][key] for r in rows])) for key in rows[0][i]}
        for i in (6, 7)
    ]
    return result


def unpack_replay(replay, saved: dict) -> None:
    if replay.capacity != saved["capacity"]:
        raise ValueError("Replay capacity mismatch")
    replay.buffer.clear()
    if saved["length"] == 0:
        return
    columns = [x.numpy() for x in saved["columns"]]
    contexts = [{k: v.numpy() for k, v in x.items()} for x in saved["contexts"]]
    for i in range(saved["length"]):
        replay.buffer.append((columns[0][i].copy(), columns[1][i].copy(), float(columns[2][i]),
                              columns[3][i].copy(), columns[4][i].copy(), float(columns[5][i]),
                              {k: v[i].copy() for k, v in contexts[0].items()},
                              {k: v[i].copy() for k, v in contexts[1].items()}))


def pack_training_state(agent, planner) -> dict:
    return {
        "actor": cpu_tree(agent.actor.state_dict()),
        "actor_target": cpu_tree(agent.actor_target.state_dict()),
        "actor_opt": cpu_tree(agent.actor_opt.state_dict()),
        "critics": {k: cpu_tree(v.state_dict()) for k, v in agent.critics.items()},
        "critic_targets": {k: cpu_tree(v.state_dict()) for k, v in agent.critic_targets.items()},
        "critic_opts": {k: cpu_tree(v.state_dict()) for k, v in agent.critic_opts.items()},
        "replay": pack_replay(agent.replay), "update_calls": agent.update_calls,
        "learn_steps": agent.learn_steps, "planner_params": plain(planner.params),
        "last_constraint_violations": plain(planner.last_constraint_violations), "rng": rng_state(),
    }


def restore_training_state(agent, planner, saved: dict) -> None:
    planner.params.update(saved["planner_params"])
    planner.last_constraint_violations = dict(saved["last_constraint_violations"])
    agent.actor.load_state_dict(saved["actor"])
    agent.actor_target.load_state_dict(saved["actor_target"])
    agent.actor_opt.load_state_dict(saved["actor_opt"])
    for k in agent.CRITIC_KEYS:
        agent.critics[k].load_state_dict(saved["critics"][k])
        agent.critic_targets[k].load_state_dict(saved["critic_targets"][k])
        agent.critic_opts[k].load_state_dict(saved["critic_opts"][k])
    agent.update_calls = int(saved["update_calls"])
    agent.learn_steps = int(saved["learn_steps"])
    unpack_replay(agent.replay, saved["replay"])
    restore_rng(saved["rng"])  # Last: constructing fresh networks consumes RNG.


def make_actor_checkpoint(agent, planner, protocol: dict, variant: str, seed: int,
                          selected_episode: int, metrics: dict) -> dict:
    return {
        "format_version": VERSION, "kind": "selected_actor_for_evaluation",
        "protocol_id": protocol["protocol_id"], "source_hashes": protocol["source_hashes"],
        "workbook_sha256": protocol["workbook_sha256"], "base_payload_sha256": protocol["base_payload_sha256"],
        "variant": variant, "seed": seed, "planned_episodes": protocol["episodes"],
        "selected_episode": selected_episode, "selection_key": list(ablation.selection_key(metrics)),
        "selection_metrics": plain(metrics), "resolved_params_at_selection": plain(planner.params),
        "state_dim": agent.state_dim, "action_dim": agent.action_dim,
        "binding_dim": planner.binding_dim, "topo_order": list(planner.topo_order),
        "actor_state_dict": ablation.snapshot(agent),
    }


class ActorPolicy:
    """Evaluation-only adapter: no replay, critic, optimizer, or exploration."""
    def __init__(self, actor, device: str):
        self.actor = actor.to(device).eval()
        self.device = torch.device(device)

    @torch.no_grad()
    def act(self, state, explore: bool = False):
        if explore:
            raise ValueError("ActorPolicy is evaluation-only")
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        return self.actor(s).squeeze(0).cpu().numpy()


def restore_actor(solver, base: dict, saved: dict, device: str):
    if saved["kind"] != "selected_actor_for_evaluation" or saved["variant"] not in VARIANTS:
        raise ValueError("Not a Full/M1 actor checkpoint")
    if saved["base_payload_sha256"] != digest(base):
        raise ValueError("Checkpoint does not match the resolved task inputs")
    for name, value in saved["source_hashes"].items():
        # Saved checkpoints created by the original Full/M1 wrapper use ``upstream/...``
        # metadata keys. In this consolidated release those byte-identical files live at
        # the package root, so resolve both layouts without changing checkpoint content.
        rel = name[len("upstream/"):] if name.startswith("upstream/") else name
        path = ROOT / rel
        if path.exists() and common.sha256(path) != value:
            raise ValueError(f"Source hash mismatch: {name}")
    planner = ablation.make_planner(solver, base, saved["variant"])
    # Keep the EXACT M1 flags. Do not call run_table7.dynamic_eval('dbn_cddpg', ...).
    planner.params.update(saved["resolved_params_at_selection"])
    env = planner.make_env()
    if (env.state_dim != saved["state_dim"] or list(planner.topo_order) != saved["topo_order"]
            or planner.binding_dim != saved["binding_dim"]):
        raise ValueError("Checkpoint architecture/task ordering mismatch")
    actor = solver.HierarchicalActor(env.state_dim, len(planner.topo_order), planner.binding_dim,
                                    hidden=int(planner.params["hidden_dim"]),
                                    output_bound=float(planner.params["actor_output_bound"]))
    actor.load_state_dict(saved["actor_state_dict"], strict=True)
    return planner, ActorPolicy(actor, device)


def save_traces(directory: Path, env) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    common.write_csv(directory / "schedule.csv", [vars(x) for x in env.schedule])
    for name in ("dbn_trace", "dynamic_ahd_trace", "task_type_trace"):
        common.write_csv(directory / f"{name}.csv", getattr(env, name, []))


def parse_variants(text: str) -> list[str]:
    values = [x.strip() for x in text.split(",") if x.strip()]
    if not values or len(set(values)) != len(values) or any(v not in VARIANTS for v in values):
        raise ValueError("--variants must be full, m1_no_dbn, or full,m1_no_dbn")
    return values
