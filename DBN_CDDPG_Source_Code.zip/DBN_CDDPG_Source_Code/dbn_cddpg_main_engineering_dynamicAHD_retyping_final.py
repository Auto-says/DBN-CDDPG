from __future__ import annotations

import argparse
import json
import math
import random
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence, Set, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "本程序需要 PyTorch。请先执行: pip install torch"
    ) from exc

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except Exception:  # pragma: no cover
    Workbook = None
    load_workbook = None
    Alignment = Border = Font = PatternFill = Side = None
    get_column_letter = None


MODES = ("H", "R", "HRC")
TYPE_TO_FIXED_MODE = {"I": "H", "II": "R", "IV": "HRC"}


@dataclass
class Task:
    id: int
    name: str
    preds: List[int]
    Hi: float
    Oi: float
    Ai: float
    Ti: float
    Pi: float
    t_h: float
    t_r: float
    t_hrc: float
    base_energy: float
    hazard: int
    severity: int
    detectability: int
    occurrence: int
    necessity_dims: List[float]
    collaboration_dims: List[float]
    tool: str
    direction: str
    robot_load: float = 0.5
    weight_support: float = 0.5
    precision_need: float = 0.5
    judgement_need: float = 0.5
    allow_modes: Optional[List[str]] = None
    ahd_override: Optional[float] = None
    stage1_auto_score_override: Optional[float] = None
    stage1_result_override: Optional[str] = None
    task_type_override: Optional[str] = None
    human_risk_score_override: Optional[float] = None
    human_need_score_override: Optional[float] = None
    collab_need_score_override: Optional[float] = None


@dataclass
class Human:
    id: str
    skill: float
    fatigue_rate: float = 0.02


@dataclass
class Robot:
    id: str
    speed_factor: float
    energy_factor: float = 1.0


@dataclass
class Action:
    task_id: int
    mode: str
    human_id: Optional[str] = None
    robot_id: Optional[str] = None

    def binding_str(self) -> str:
        if self.mode == "H":
            return self.human_id or "-"
        if self.mode == "R":
            return self.robot_id or "-"
        return f"{self.human_id}+{self.robot_id}"


@dataclass
class ScheduledItem:
    task_id: int
    task_name: str
    task_type: str
    mode: str
    binding: str
    start: float
    end: float
    delta_time: float
    delta_energy: float
    delta_risk: float
    delta_fatigue: float


@dataclass
class PipelineResult:
    task_types: Dict[int, str]
    type3_modes: Dict[int, str]
    final_modes: Dict[int, str]


DEFAULT_PARAMS = {
    # 阶段一：综合复杂度权重
    "complexity_weights": {"H": 0.20, "O": 0.28, "A": 0.28, "T": 0.14, "P": 0.10},

    # 阶段一：机器人优先阈值（综合复杂度原始加权值）
    # Hi/Oi/Ai/Ti/Pi 均为 1~5 评分，故 C_raw 也落在 1~5
    "theta_complexity_robot_raw": 2.40,

    # 阶段二：AHD/HN/CN 规则
    "theta_necessity": 0.60,
    "theta_collaboration_iv": 0.70,
    "theta_ahd_low": 100,
    "theta_ahd_high": 120,
    "theta_manual_hazard_max": 2,

    # 事件级动态 AHD + 在线任务重分类。
    # Stage I 仅冻结 Type II（机器人优先边界）；其余 I/III/IV 为动态候选类型。
    # 每个事件时刻先刷新 AHD/疲劳/资源状态，再在 I/III/IV 之间重判；
    # 只有当前为 Type III 的任务进入 DBN H/R/HRC 模式信念更新。
    "use_dynamic_ahd": 1.0,
    "use_event_retyping": 1.0,
    "dynamic_ahd_w_fatigue": 0.12,
    "dynamic_ahd_w_progress": 0.06,
    "dynamic_ahd_w_local_exposure": 0.08,
    "dynamic_ahd_w_recent_hazard": 0.04,
    "dynamic_ahd_min_factor": 0.85,
    "dynamic_ahd_max_factor": 1.35,
    # 为避免阈值附近事件抖动，在线重分类采用滞回区间。
    "retype_low_margin": 10.0,
    "retype_high_margin": 30.0,
    "retype_fatigue_max_type_i": 2.5,
    "retype_resource_min": 0.15,
    "theta_dynamic_ahd_h_block": 120.0,

    # 兼容旧版参数（保留，默认不再作为主判定链）
    "theta_stage1_auto": 0.63,
    "theta_complexity": 0.42,
    "theta_human_risk_safe": 0.08,
    "theta_type4_complexity": 0.40,
    "theta_ahd_iv": 100.0,
    "theta_manual_time_advantage": 0.10,
    "theta_ahd": 40.0,
    "theta_collaboration": 0.68,
    "theta_ahd_iv_soft": 70.0,
    "theta_hazard_iv_soft": 3.0,

    # 协作需求计算
    "collab_w_speed": 0.28,
    "collab_speed_norm": 0.25,
    "collab_w_pd": 0.22,
    "collab_w_difficulty": 0.25,
    "collab_w_hazard": 0.25,

    # 人工失误率
    "human_error_alpha0": -3.2,
    "human_error_alpha1": 3.5,
    "human_error_alpha2": 2.2,

    # 调度与成本项
    "risk_discount_hrc": 0.60,
    "fatigue_discount_hrc": 0.70,
    "human_risk_weight_hazard": 0.30,
    "human_risk_weight_ahd": 0.70,
    "human_risk_scale": 5.0,
    "fatigue_risk_amplifier": 0.40,
    "min_hrc_exposure": 0.35,
    "hrc_exposure_collab_bonus": 0.25,
    "switch_time_tool": 1.0,
    "switch_time_direction": 0.5,
    "switch_energy_tool": 0.8,
    "switch_energy_direction": 0.4,
    "use_robot_speed_factor": 0.0,
    "lambda_energy": 0.25,
    "lambda_risk": 0.12,
    "lambda_fatigue": 0.20,
    "type3_robot_risk_bonus": 1.15,
    "type3_robot_complexity_bonus": 0.75,
    "type3_hrc_fixed_cost": 0.55,
    "type3_hrc_risk_discount": 0.05,
    "type3_hrc_collab_min": 0.75,
    "type3_hrc_speed_min": 0.12,
    "formal_mode_logic": "paper-two-stage-v1",
}


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)



def _norm_header(x: object) -> str:
    s = str(x or "").strip().lower()
    return "".join(ch for ch in s if ch.isalnum() or ch == "_")


def _try_float(x: object, default: float = 0.0) -> float:
    if x is None:
        return float(default)
    if isinstance(x, bool):
        return float(int(x))
    try:
        return float(x)
    except Exception:
        s = str(x).strip().replace(",", "")
        if s == "":
            return float(default)
        try:
            return float(s)
        except Exception:
            return float(default)


def _try_int(x: object, default: int = 0) -> int:
    return int(round(_try_float(x, default)))


def _try_bool(x: object, default: Optional[bool] = None) -> Optional[bool]:
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    if s in {"1", "true", "yes", "y", "on", "允许", "是"}:
        return True
    if s in {"0", "false", "no", "n", "off", "不允许", "否"}:
        return False
    return default


def _unit_clip(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _scale01_general(x: object) -> float:
    v = _try_float(x, 0.0)
    if v <= 0:
        return 0.0
    if v <= 1.0:
        return _unit_clip(v)
    if v <= 5.0:
        return _unit_clip((v - 1.0) / 4.0)
    if v <= 100.0:
        return _unit_clip(v / 100.0)
    return 1.0


def _scale01_skill(x: object) -> float:
    v = _try_float(x, 0.85)
    if v <= 1.0:
        return _unit_clip(v)
    if v <= 5.0:
        return _unit_clip(v / 5.0)
    if v <= 100.0:
        return _unit_clip(v / 100.0)
    return 0.85


def _scale01_hazard(x: object) -> float:
    v = _try_float(x, 0.0)
    if v <= 0:
        return 0.0
    if v <= 1.0:
        return _unit_clip(v)
    if v <= 3.0:
        return _unit_clip(v / 3.0)
    if v <= 5.0:
        return _unit_clip(v / 5.0)
    return 1.0


def _to_five_scale(x01: float) -> float:
    return 1.0 + 4.0 * _unit_clip(x01)


def _sheet_rows(wb, sheet_name: str) -> List[Dict[str, object]]:
    if sheet_name not in wb.sheetnames:
        return []
    ws = wb[sheet_name]
    values = list(ws.iter_rows(values_only=True))
    if not values:
        return []
    header = [_norm_header(x) for x in values[0]]
    rows = []
    for row in values[1:]:
        if not any(cell is not None and str(cell).strip() != "" for cell in row):
            continue
        rows.append({header[i]: row[i] for i in range(min(len(header), len(row))) if header[i]})
    return rows


def _find_sheet_name(wb, *candidates: str) -> Optional[str]:
    normalized = {_norm_header(name): name for name in wb.sheetnames}
    for c in candidates:
        key = _norm_header(c)
        if key in normalized:
            return normalized[key]
    return None


def _pick(row: Dict[str, object], *keys: str, default=None):
    for key in keys:
        k = _norm_header(key)
        if k in row and row[k] not in (None, ""):
            return row[k]
    return default


def _collect_four_dims(row: Dict[str, object], prefixes: Tuple[str, ...], fallbacks: Tuple[float, float, float, float]) -> List[float]:
    vals: List[float] = []
    for idx in range(1, 5):
        found = None
        for p in prefixes:
            key = _norm_header(f"{p}{idx}")
            if key in row and row[key] not in (None, ""):
                found = row[key]
                break
        vals.append(_scale01_general(found) if found is not None else fallbacks[idx - 1])
    return vals


def _extract_param_overrides(param_rows: List[Dict[str, object]]) -> Dict[str, object]:
    if not param_rows:
        return {}
    out: Dict[str, object] = {}
    headers = set(param_rows[0].keys())
    # Support both the original ``key/value`` layout and the workbook's
    # long-form ``parameter/value`` layout.  The previous loader only
    # recognized ``key/value`` and therefore silently ignored almost all rows
    # in ``control_params`` (it treated the first data row as a wide table).
    # This made the runtime solver use DEFAULT_PARAMS instead of the calibrated
    # paper parameters.
    if "value" in headers and any(name in headers for name in ("key", "parameter", "param", "name")):
        name_col = next(name for name in ("key", "parameter", "param", "name") if name in headers)
        iterator = ((str(r.get(name_col, "")), r.get("value")) for r in param_rows)
    else:
        iterator = param_rows[0].items()
    weight_map = {
        "complexityweighth": ("complexity_weights", "H"),
        "complexityweighto": ("complexity_weights", "O"),
        "complexityweighta": ("complexity_weights", "A"),
        "complexityweightt": ("complexity_weights", "T"),
        "complexityweightp": ("complexity_weights", "P"),
        # workbook v2 的阶段一权重命名
        "stage1_whdc": ("complexity_weights", "H"),
        "stage1_wds": ("complexity_weights", "O"),
        "stage1_wdoc": ("complexity_weights", "A"),
        "stage1_wpd": ("complexity_weights", "T"),
        "stage1_wdpc": ("complexity_weights", "P"),
    }
    alias_map = {
        # 兼容旧版 A/H/N/C 的短写法（带下划线 / 不带下划线）
        "thetaa": "theta_stage1_auto",
        "theta_a": "theta_stage1_auto",
        "thetah": "theta_human_risk_safe",
        "theta_h": "theta_human_risk_safe",
        "thetan": "theta_necessity",
        "theta_n": "theta_necessity",
        "thetac": "theta_collaboration_iv",
        "theta_c": "theta_collaboration_iv",

        # 论文主线参数
        "theta_r": "theta_complexity_robot_raw",
        "theta_complexity_robot_raw": "theta_complexity_robot_raw",
        "theta_ahd_low": "theta_ahd_low",
        "theta_ahd_high": "theta_ahd_high",

        # IV 判定相关兼容
        "theta_iv_complexity": "theta_type4_complexity",
        "theta_iv_ahd": "theta_ahd_iv",

        # 手工门控 / 兼容
        "theta_manual_hazard_max": "theta_manual_hazard_max",
        "theta_manual_time_adv": "theta_manual_time_advantage",
        "theta_manual_time_advantage": "theta_manual_time_advantage",

        # 协作需求
        "collab_w_speed": "collab_w_speed",
        "collab_speed_norm": "collab_speed_norm",
        "collab_w_pd": "collab_w_pd",
        "collab_w_difficulty": "collab_w_difficulty",
        "collab_w_hazard": "collab_w_hazard",
        "theta_type3_hrc_collab_min": "type3_hrc_collab_min",
        "theta_type3_hrc_speed_min": "type3_hrc_speed_min",
        "formal_mode_logic": "formal_mode_logic",
    }
    direct_keys = set(DEFAULT_PARAMS.keys()) - {"complexity_weights"}
    for raw_key, raw_val in iterator:
        nk = _norm_header(raw_key)
        if nk in weight_map:
            parent, child = weight_map[nk]
            out.setdefault(parent, {})
            out[parent][child] = _try_float(raw_val, DEFAULT_PARAMS[parent][child])
            continue
        if nk in alias_map:
            dk = alias_map[nk]
            if isinstance(DEFAULT_PARAMS.get(dk), str):
                out[dk] = str(raw_val)
            else:
                out[dk] = _try_float(raw_val, DEFAULT_PARAMS[dk])
            continue
        for dk in direct_keys:
            if nk == _norm_header(dk):
                if isinstance(DEFAULT_PARAMS.get(dk), str):
                    out[dk] = str(raw_val)
                else:
                    out[dk] = _try_float(raw_val, DEFAULT_PARAMS[dk])
                break
    return out


def _normalize_task_type(value: object) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip().upper()
    if not text:
        return None
    mapping = {
        "I": "I", "1": "I", "Ⅰ": "I", "TYPEI": "I", "TYPE I": "I",
        "II": "II", "2": "II", "Ⅱ": "II", "TYPEII": "II", "TYPE II": "II",
        "III": "III", "3": "III", "Ⅲ": "III", "TYPEIII": "III", "TYPE III": "III",
        "IV": "IV", "4": "IV", "Ⅳ": "IV", "TYPEIV": "IV", "TYPE IV": "IV",
    }
    compact = text.replace("-", "").replace("_", "").replace(" ", "")
    return mapping.get(text) or mapping.get(compact)


def excel_to_data(path: Path, scenario_id: Optional[str] = None) -> dict:
    if load_workbook is None:
        raise RuntimeError("读取 Excel 需要 openpyxl。请先执行: pip install openpyxl")
    wb = load_workbook(path, data_only=True)

    tasks_sheet = _find_sheet_name(wb, "tasks_master", "tasks", "tasksmaster")
    if tasks_sheet is None:
        raise ValueError("Excel 中未找到 tasks_master 工作表。")
    precedence_sheet = _find_sheet_name(wb, "precedence_relations", "precedence", "precedencerelations")
    human_sheet = _find_sheet_name(wb, "human_resources", "humans", "humanresources")
    robot_sheet = _find_sheet_name(wb, "robot_resources", "robots", "robotresources")
    mode_sheet = _find_sheet_name(wb, "mode_eligibility", "modeeligibility")
    scenario_sheet = _find_sheet_name(wb, "scenario_params", "scenarioparams")
    params_sheet = _find_sheet_name(wb, "params", "control_params", "controls")
    risk_sheet = _find_sheet_name(wb, "risk_task", "risktask")
    type_sheet = _find_sheet_name(wb, "task_type_results", "tasktyperesults")

    task_rows = _sheet_rows(wb, tasks_sheet)
    precedence_rows = _sheet_rows(wb, precedence_sheet) if precedence_sheet else []
    human_rows = _sheet_rows(wb, human_sheet) if human_sheet else []
    robot_rows = _sheet_rows(wb, robot_sheet) if robot_sheet else []
    mode_rows = _sheet_rows(wb, mode_sheet) if mode_sheet else []
    scenario_rows = _sheet_rows(wb, scenario_sheet) if scenario_sheet else []
    param_rows = _sheet_rows(wb, params_sheet) if params_sheet else []
    risk_rows = _sheet_rows(wb, risk_sheet) if risk_sheet else []
    type_rows = _sheet_rows(wb, type_sheet) if type_sheet else []

    scenario_row = None
    if scenario_rows:
        if scenario_id is not None:
            for row in scenario_rows:
                sid = str(_pick(row, "scenario_id", "scenario", "id", default="")).strip()
                if sid == str(scenario_id):
                    scenario_row = row
                    break
        if scenario_row is None:
            scenario_row = scenario_rows[0]

    params = dict(DEFAULT_PARAMS)
    params["complexity_weights"] = dict(DEFAULT_PARAMS["complexity_weights"])
    for src in (_extract_param_overrides(param_rows), _extract_param_overrides([scenario_row] if scenario_row else [])):
        for k, v in src.items():
            if k == "complexity_weights":
                params[k].update(v)
            else:
                params[k] = v

    print("\n[DEBUG] 实际生效的两阶段阈值：")
    print({
        "theta_complexity_robot_raw": params["theta_complexity_robot_raw"],
        "theta_necessity": params["theta_necessity"],
        "theta_collaboration_iv": params["theta_collaboration_iv"],
        "theta_ahd_low": params["theta_ahd_low"],
        "theta_ahd_high": params["theta_ahd_high"],
        "theta_manual_hazard_max": params["theta_manual_hazard_max"],
        "formal_mode_logic": params["formal_mode_logic"],
    })

    mode_map: Dict[int, Dict[str, Optional[bool]]] = {}
    for row in mode_rows:
        tid = _try_int(_pick(row, "task_id", "id"), 0)
        if tid <= 0:
            continue
        mode_map[tid] = {
            "H": _try_bool(_pick(row, "allow_h", "h", "allowhuman")),
            "R": _try_bool(_pick(row, "allow_r", "r", "allowrobot")),
            "HRC": _try_bool(_pick(row, "allow_hrc", "hrc", "allowcollab", "allow_c")),
        }

    risk_map: Dict[int, Dict[str, object]] = {}
    for row in risk_rows:
        tid = _try_int(_pick(row, "task_id", "id"), 0)
        if tid > 0:
            risk_map[tid] = row

    type_map: Dict[int, Dict[str, object]] = {}
    for row in type_rows:
        tid = _try_int(_pick(row, "task_id", "id"), 0)
        if tid > 0:
            type_map[tid] = row

    preds_map: Dict[int, List[int]] = {}
    succ_map: Dict[int, List[int]] = {}
    for row in precedence_rows:
        pred = _try_int(_pick(row, "pred_task", "pred", "predecessor", "fromtask", "from"), 0)
        succ = _try_int(_pick(row, "succ_task", "succ", "successor", "totask", "to"), 0)
        if pred <= 0 or succ <= 0:
            continue
        preds_map.setdefault(succ, []).append(pred)
        succ_map.setdefault(pred, []).append(succ)

    task_records = []
    for idx, row in enumerate(task_rows, start=1):
        tid = _try_int(_pick(row, "task_id", "id", "task"), idx)
        difficulty01 = _scale01_general(_pick(row, "difficulty", "complexity", "gi", default=0.5))
        hazard_raw = _pick(row, "hazard_level", "hazard", "hi", default=1)
        hazard01 = _scale01_hazard(hazard_raw)
        hazard_int = max(1, min(5, _try_int(hazard_raw, 1)))
        risk_row = risk_map.get(tid, {})
        type_row = type_map.get(tid, {})

        t_h = _try_float(_pick(row, "t_h", "th", "time_human", "human_time", default=_try_float(_pick(row, "duration", "time"), 10.0)), 10.0)
        t_r = _try_float(_pick(row, "t_r", "tr", "time_robot", "robot_time", default=max(1.0, 0.8 * t_h)), max(1.0, 0.8 * t_h))
        t_hrc = _try_float(_pick(row, "t_hrc", "thrc", "time_hrc", "hrc_time", default=max(1.0, 0.65 * min(t_h, t_r))), max(1.0, 0.65 * min(t_h, t_r)))
        base_energy = _try_float(_pick(row, "unit_energy", "base_energy", "energy", "ei", default=3.0 + 4.0 * difficulty01), 3.0 + 4.0 * difficulty01)

        allow_h = _try_bool(_pick(row, "allow_h", "h", "allowhuman"), None)
        allow_r = _try_bool(_pick(row, "allow_r", "r", "allowrobot"), None)
        allow_hrc = _try_bool(_pick(row, "allow_hrc", "hrc", "allowcollab", "allow_c"), None)
        if tid in mode_map:
            allow_h = mode_map[tid].get("H", allow_h)
            allow_r = mode_map[tid].get("R", allow_r)
            allow_hrc = mode_map[tid].get("HRC", allow_hrc)
        allow_modes = [m for m, flag in [("H", allow_h), ("R", allow_r), ("HRC", allow_hrc)] if flag is not False]
        if not allow_modes:
            allow_modes = ["H", "R", "HRC"]

        manual_need = _scale01_general(_pick(row, "manual_need", "manualdependency", "manual_dependency", default=0.35 + 0.35 * difficulty01 + 0.15 * hazard01))
        precision_need = _scale01_general(_pick(row, "precision_need", "precisionneed", default=0.30 + 0.45 * difficulty01))
        judgement_need = _scale01_general(_pick(row, "judgement_need", "judgementneed", "decisionneed", default=0.25 + 0.45 * hazard01 + 0.20 * difficulty01))
        dexterity_need = _scale01_general(_pick(row, "dexterity_need", "dexterityneed", "nonstandard_adapt", default=0.25 + 0.35 * difficulty01))
        collaboration_need = _scale01_general(_pick(row, "collaboration_need", "collaborationneed", default=0.20 + 0.50 * difficulty01))
        weight_support = _scale01_general(_pick(row, "weight_support", "weightsupport", default=0.20 + 0.50 * difficulty01))
        posture_coupling = _scale01_general(_pick(row, "posture_coupling", "posturecoupling", default=0.15 + 0.35 * difficulty01))
        sync_need = _scale01_general(_pick(row, "sync_need", "syncneed", default=0.10 + 0.35 * difficulty01))

        human_need_override = _pick(type_row, "human_need_score", default=None)
        collab_need_override = _pick(type_row, "collab_need_score", default=None)
        if human_need_override not in (None, ""):
            need01 = _scale01_general(human_need_override)
            necessity_dims = [need01, need01, need01, need01]
        else:
            necessity_dims = _collect_four_dims(row, ("necessity", "manualneed", "manual", "need"), (manual_need, precision_need, judgement_need, dexterity_need))
        if collab_need_override not in (None, ""):
            collab01 = _scale01_general(collab_need_override)
            collaboration_dims = [collab01, collab01, collab01, collab01]
        else:
            collaboration_dims = _collect_four_dims(row, ("collaboration", "collab", "cneed"), (weight_support, posture_coupling, sync_need, collaboration_need))

        record = {
            "id": tid,
            "name": str(_pick(row, "task_name", "name", "component_name", default=f"Task {tid}")),
            "preds": sorted(set(preds_map.get(tid, []))),
            "t_h": t_h,
            "t_r": t_r,
            "t_hrc": t_hrc,
            "base_energy": base_energy,
            "hazard": hazard_int,
            "severity": max(1, min(5, _try_int(_pick(risk_row, "severity", "s", default=_pick(row, "severity", "s", default=max(1, hazard_int))), max(1, hazard_int)))),
            "detectability": max(1, min(5, _try_int(_pick(risk_row, "detectability", "d", default=_pick(row, "detectability", "d", default=3 if hazard_int >= 3 else 2)), 3 if hazard_int >= 3 else 2))),
            "occurrence": max(1, min(5, _try_int(_pick(risk_row, "occurrence", "o", default=_pick(row, "occurrence", "o", default=max(1, min(5, int(round(1 + 4 * difficulty01)))))), max(1, min(5, int(round(1 + 4 * difficulty01))))))),
            "necessity_dims": necessity_dims,
            "collaboration_dims": collaboration_dims,
            "tool": str(_pick(row, "tool_id", "tool", "toolid", default="tool")),
            "direction": str(_pick(row, "direction_id", "direction", "dir", default="+Z")),
            "robot_load": _scale01_general(_pick(row, "robot_load", "robotload", default=0.30 + 0.40 * difficulty01)),
            "weight_support": weight_support,
            "precision_need": precision_need,
            "judgement_need": judgement_need,
            "allow_modes": allow_modes,
            # 优先读取 risk_task.AHD 作为冻结的基准 AHD；动态 AHD 在事件循环中围绕该基准更新。
            "ahd_override": (_try_float(_pick(risk_row, "ahd", default=None), 0.0)
                             if _pick(risk_row, "ahd", default=None) not in (None, "") else None),
            "stage1_auto_score_override": (_try_float(_pick(type_row, "stage1_auto_score", default=None), 0.0)
                                           if _pick(type_row, "stage1_auto_score", default=None) not in (None, "") else None),
            "stage1_result_override": (str(_pick(type_row, "stage1_result", default="")).strip() or None),
            "task_type_override": _normalize_task_type(_pick(type_row, "final_type", default=None)),
            "human_risk_score_override": (_try_float(_pick(type_row, "human_risk_score", default=None), 0.0)
                                          if _pick(type_row, "human_risk_score", default=None) not in (None, "") else None),
            "human_need_score_override": _scale01_general(human_need_override) if human_need_override not in (None, "") else None,
            "collab_need_score_override": _scale01_general(collab_need_override) if collab_need_override not in (None, "") else None,
            "_difficulty01": difficulty01,
            "_hazard01": hazard01,
            "_row": row,
        }
        task_records.append(record)

    max_degree = max((len(rec["preds"]) + len(succ_map.get(rec["id"], [])) for rec in task_records), default=1)
    for rec in task_records:
        row = rec.pop("_row")
        degree = len(rec["preds"]) + len(succ_map.get(rec["id"], []))
        h01 = _scale01_general(_pick(row, "hi", "hdc", "hierarchy_complexity", default=degree / max(1, max_degree)))
        o01 = _scale01_general(_pick(row, "oi", "ds", "operation_complexity", "disassemblyscale", default=rec.pop("_difficulty01")))
        a01 = _scale01_general(_pick(row, "ai", "doc", "attribute_complexity", "componentcharacteristics", default=0.6 * o01 + 0.4 * rec["_hazard01"]))
        t01 = _scale01_general(_pick(row, "ti", "switch_complexity", "toolswitchcomplexity", default=0.35 if str(rec["tool"]).strip() else 0.20))
        p01 = _scale01_general(_pick(row, "pi", "parallel_complexity", "collaboration_complexity", default=float(np.mean(rec["collaboration_dims"]))))
        rec["Hi"] = _to_five_scale(h01)
        rec["Oi"] = _to_five_scale(o01)
        rec["Ai"] = _to_five_scale(a01)
        rec["Ti"] = _to_five_scale(t01)
        rec["Pi"] = _to_five_scale(p01)
        rec.pop("_hazard01", None)

    def _scenario_match(row: Dict[str, object]) -> bool:
        if scenario_id is None:
            return True
        sid = str(_pick(row, "scenario_id", "scenario", default="")).strip()
        return sid in {"", str(scenario_id)}

    humans = []
    for idx, row in enumerate(human_rows, start=1):
        if not _scenario_match(row):
            continue
        humans.append({
            "id": str(_pick(row, "human_id", "id", "resource_id", default=f"H{idx}")),
            "skill": _scale01_skill(_pick(row, "skill", "skill_level", default=0.85)),
            "fatigue_rate": max(0.001, _try_float(_pick(row, "fatigue_rate", default=0.02), 0.02)),
        })
    if not humans:
        num_h = max(1, _try_int(_pick(scenario_row or {}, "num_humans", default=2), 2))
        base_skill = _scale01_skill(_pick(scenario_row or {}, "skill_level", default=0.85))
        humans = [{"id": f"H{i+1}", "skill": base_skill, "fatigue_rate": 0.02 + 0.003 * i} for i in range(num_h)]

    robots = []
    for idx, row in enumerate(robot_rows, start=1):
        if not _scenario_match(row):
            continue
        robots.append({
            "id": str(_pick(row, "robot_id", "id", "resource_id", default=f"R{idx}")),
            "speed_factor": max(0.4, _try_float(_pick(row, "speed_factor", "speed", default=1.0), 1.0)),
            "energy_factor": max(0.1, _try_float(_pick(row, "energy_factor", default=1.0), 1.0)),
        })
    if not robots:
        num_r = max(1, _try_int(_pick(scenario_row or {}, "num_robots", default=2), 2))
        robots = [{"id": f"R{i+1}", "speed_factor": 1.0 - 0.05 * i, "energy_factor": 1.0} for i in range(num_r)]

    return {
        "params": params,
        "resources": {"humans": humans, "robots": robots},
        "tasks": task_records,
    }



def load_input_payload(path: Path, scenario_id: Optional[str] = None) -> dict:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
        if not path.exists():
            raise FileNotFoundError(f"未找到 Excel 文件: {path}")
        return excel_to_data(path, scenario_id=scenario_id)
    if suffix == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    raise ValueError("仅支持 JSON 或 Excel（.xlsx/.xlsm）输入。")


MODE_INDEX = {m: i for i, m in enumerate(MODES)}
FIXED_TYPE_MODE = {"I": "H", "II": "R", "IV": "HRC"}


@dataclass
class JointDecodedAction:
    task_id: int
    mode: str
    human_id: Optional[str] = None
    robot_id: Optional[str] = None
    binding_index: int = 0

    def binding_str(self) -> str:
        if self.mode == "H":
            return self.human_id or "-"
        if self.mode == "R":
            return self.robot_id or "-"
        return f"{self.human_id}+{self.robot_id}"


PROJECTION_CONTEXT_KEYS = (
    "task_mask",
    "beta_by_task",
    "mode_mask_by_task",
    "binding_mask_by_mode",
    "binding_bonus_by_mode",
)


def _copy_projection_context(context: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
    """Copy the state-dependent feasible-set description stored in replay."""
    missing = [key for key in PROJECTION_CONTEXT_KEYS if key not in context]
    if missing:
        raise KeyError(f"投影上下文缺少字段: {missing}")
    return {
        key: np.asarray(context[key], dtype=np.float32).copy()
        for key in PROJECTION_CONTEXT_KEYS
    }


class ReplayBuffer:
    def __init__(self, capacity: int = 50000) -> None:
        self.capacity = int(capacity)
        self.buffer: deque = deque(maxlen=self.capacity)

    def push(
        self,
        state,
        action_vec,
        reward,
        next_state,
        done,
        projection_context,
        next_projection_context,
        transition_deltas=None,
    ):
        if transition_deltas is None:
            # Compatibility fallback for external callers.  Formal Table-8/V16
            # training always supplies the four stationary components.
            transition_deltas = np.zeros(4, dtype=np.float32)
        deltas = np.asarray(transition_deltas, dtype=np.float32).reshape(-1)
        if deltas.size != 4:
            raise ValueError(f"transition_deltas must contain [time, energy, risk, fatigue], got {deltas.shape}")
        self.buffer.append((
            np.asarray(state, dtype=np.float32),
            np.asarray(action_vec, dtype=np.float32),
            float(reward),
            deltas.copy(),
            np.asarray(next_state, dtype=np.float32),
            float(done),
            _copy_projection_context(projection_context),
            _copy_projection_context(next_projection_context),
        ))

    def sample(self, batch_size: int):
        idx = np.random.choice(len(self.buffer), size=batch_size, replace=False)
        s, a, r, deltas, ns, d, context, next_context = zip(*(self.buffer[i] for i in idx))

        def stack_context(items):
            return {
                key: np.stack([item[key] for item in items]).astype(np.float32)
                for key in PROJECTION_CONTEXT_KEYS
            }

        return (
            np.stack(s).astype(np.float32),
            np.stack(a).astype(np.float32),
            np.asarray(r, dtype=np.float32).reshape(-1, 1),
            np.stack(deltas).astype(np.float32),
            np.stack(ns).astype(np.float32),
            np.asarray(d, dtype=np.float32).reshape(-1, 1),
            stack_context(context),
            stack_context(next_context),
        )

    def __len__(self) -> int:
        return len(self.buffer)


class MLP(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, hidden_dims: Tuple[int, int] = (256, 256), out_act: Optional[str] = None):
        super().__init__()
        h1, h2 = hidden_dims
        self.net = nn.Sequential(
            nn.Linear(in_dim, h1), nn.ReLU(),
            nn.Linear(h1, h2), nn.ReLU(),
            nn.Linear(h2, out_dim),
        )
        self.out_act = out_act

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.net(x)
        if self.out_act == "tanh":
            return torch.tanh(y)
        return y


class HierarchicalActor(nn.Module):
    def __init__(self, state_dim: int, n_tasks: int, binding_dim: int, hidden: int = 128, output_bound: float = 1.0):
        super().__init__()
        self.output_bound = float(output_bound)
        self.shared = nn.Sequential(
            nn.Linear(state_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
        )
        self.task_head = nn.Linear(hidden, n_tasks)
        self.mode_head = nn.Linear(hidden, len(MODES))
        self.binding_head = nn.Linear(hidden, binding_dim)

    def raw_logits(self, state: torch.Tensor) -> torch.Tensor:
        h = self.shared(state)
        return torch.cat([self.task_head(h), self.mode_head(h), self.binding_head(h)], dim=-1)

    def bound_logits(self, raw_logits: torch.Tensor) -> torch.Tensor:
        return self.output_bound * torch.tanh(raw_logits)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return self.bound_logits(self.raw_logits(state))


class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([state, action], dim=-1))


class TypeIIIDBN:
    """约束 DBN：对每个任务III维护 beta(i,t) = P(z(i,t)|o(i,t))。"""

    def __init__(self, planner: "DBNCDDPGPlanner") -> None:
        self.p = planner
        self.transition = np.array([
            [0.74, 0.10, 0.16],
            [0.08, 0.78, 0.14],
            [0.18, 0.16, 0.66],
        ], dtype=np.float32)
        self.prior = {tid: np.array([1 / 3, 1 / 3, 1 / 3], dtype=np.float32) for tid in self.p.type3_task_ids}

    @staticmethod
    def _softmax(x: np.ndarray, temp: float = 1.0) -> np.ndarray:
        z = np.asarray(x, dtype=np.float32) / max(temp, 1e-6)
        z = z - np.max(z)
        e = np.exp(z)
        return e / np.clip(e.sum(), 1e-8, None)

    def reset(self) -> None:
        self.prior = {tid: np.array([1 / 3, 1 / 3, 1 / 3], dtype=np.float32) for tid in self.p.type3_task_ids}

    def _likelihood_from_observation(self, tid: int, obs: Dict[str, float]) -> np.ndarray:
        t = self.p.tasks[tid]
        necessity = self.p._human_need_score(tid)
        collab = self.p._collab_need_score(tid)
        complexity = self.p.complexity_scores[tid]
        ahd_value = float(obs.get("dynamic_ahd", self.p.ahd_scores.get(tid, 0.0)))
        ahd = min(1.0, max(0.0, ahd_value) / 625.0)
        human_fatigue = obs["human_fatigue"]
        human_avail = obs["human_avail"]
        robot_avail = obs["robot_avail"]
        tool_h = obs["tool_match_h"]
        tool_r = obs["tool_match_r"]
        dir_h = obs["dir_match_h"]
        dir_r = obs["dir_match_r"]
        hrc_speed = self.p._hrc_speed_advantage(tid)
        manual_adv = self.p._manual_time_advantage(tid)
        hazard = min(1.0, float(t.hazard) / 5.0)
        judgment = float(t.judgement_need)
        precision = float(t.precision_need)
        weight_support = float(t.weight_support)

        score_h = (
            1.30 * necessity
            + 0.55 * manual_adv
            + 0.35 * human_avail
            + 0.20 * tool_h
            + 0.15 * dir_h
            + 0.25 * judgment
            + 0.20 * precision
            - 1.20 * ahd
            - 0.95 * hazard
            - 1.05 * human_fatigue
            - 0.20 * complexity
        )
        score_r = (
            0.75 * (1.0 - necessity)
            + 1.20 * ahd
            + 1.10 * hazard
            + 0.55 * robot_avail
            + 0.25 * tool_r
            + 0.20 * dir_r
            + 0.35 * complexity
            + 0.30 * max(0.0, (t.t_h - t.t_r) / max(t.t_h, 1e-6))
            - 0.15 * precision
        )
        score_hrc = (
            1.30 * collab
            + 0.90 * hrc_speed
            + 0.50 * human_avail
            + 0.45 * robot_avail
            + 0.35 * weight_support
            + 0.20 * tool_h
            + 0.20 * tool_r
            + 0.15 * dir_h
            + 0.15 * dir_r
            + 0.20 * ahd
            - 0.40 * human_fatigue
        )
        return self._softmax(np.array([score_h, score_r, score_hrc], dtype=np.float32), temp=0.75)

    def update(self, tid: int, obs: Dict[str, float], legal_modes: List[str]) -> np.ndarray:
        pred = self.prior.get(tid, np.array([1 / 3, 1 / 3, 1 / 3], dtype=np.float32)) @ self.transition
        like = self._likelihood_from_observation(tid, obs)
        post = pred * like
        if legal_modes:
            mask = np.zeros(3, dtype=np.float32)
            for m in legal_modes:
                mask[MODE_INDEX[m]] = 1.0
            post = post * mask
        if post.sum() <= 1e-8:
            if legal_modes:
                post = np.zeros(3, dtype=np.float32)
                for m in legal_modes:
                    post[MODE_INDEX[m]] = 1.0
            else:
                post = np.ones(3, dtype=np.float32)
        post = post / post.sum()
        self.prior[tid] = post.astype(np.float32)
        return self.prior[tid]


class DBNCDDPGPlanner:
    def __init__(self, data: dict) -> None:
        self.params = {**DEFAULT_PARAMS, **data.get("params", {})}
        # V16 learning protocol.  Engineering/task parameters still come from the workbook.
        self.params.setdefault("lambda_prep", 0.0)  # diagnostic only; not part of V16 actor objective
        self.params.setdefault("belief_gate", 0.18)
        self.params.setdefault("target_tau", 0.01)
        self.params.setdefault("gamma", 1.0)
        self.params.setdefault("batch_size", 64)
        self.params.setdefault("buffer_size", 50000)
        self.params.setdefault("warmup_steps", 128)
        self.params.setdefault("actor_lr", 1e-4)
        self.params.setdefault("critic_lr", 3e-4)
        self.params.setdefault("noise_start", 0.30)
        self.params.setdefault("noise_end", 0.05)
        self.params.setdefault("noise_decay_fraction", 0.80)
        self.params.setdefault("projection_temperature", 0.25)
        self.params.setdefault("actor_backward_temperature", 1.0)
        self.params.setdefault("actor_output_bound", 1.0)
        self.params.setdefault("dbn_guidance_strength", 0.35)
        self.params.setdefault("update_every", 4)
        self.params.setdefault("lambda_update_lr", 0.02)
        self.params.setdefault("lambda_max", 20.0)
        self.params.setdefault("vcd_severity_power", 1.5)
        self.params.setdefault("vcd_min_relative_strength", 0.10)
        self.params.setdefault("vcd_performance_secondary_ratio", 0.20)
        self.params.setdefault("vcd_severe_violation_threshold", 0.25)
        self.params.setdefault("budget_energy", None)
        self.params.setdefault("budget_risk", None)
        self.params.setdefault("budget_fatigue", None)
        self.params.setdefault("budget_prep", None)
        self.tasks: Dict[int, Task] = {t["id"]: Task(**t) for t in data["tasks"]}
        self.humans: List[Human] = [Human(**x) for x in data["resources"]["humans"]]
        self.robots: List[Robot] = [Robot(**x) for x in data["resources"]["robots"]]
        self.human_idx = {h.id: i for i, h in enumerate(self.humans)}
        self.robot_idx = {r.id: i for i, r in enumerate(self.robots)}
        self.topo_order = self._topological_sort()
        self.complexity_scores = self._compute_complexities()
        # ``task_types`` is the Stage-I / workbook initial typing.  Only Type II
        # is immutable online.  I/III/IV are re-evaluated at event epochs inside
        # the environment from dynamic AHD, fatigue and executor state.
        self.task_types, self.ahd_scores = self._classify_tasks()
        self.initial_task_types = dict(self.task_types)
        self.type2_task_ids = [tid for tid in self.topo_order if self.initial_task_types[tid] == "II"]
        self.dynamic_candidate_task_ids = [tid for tid in self.topo_order if self.initial_task_types[tid] != "II"]
        self.type3_task_ids = [tid for tid in self.dynamic_candidate_task_ids]
        self.tid_to_pos = {tid: i for i, tid in enumerate(self.topo_order)}
        self.binding_dim = max(len(self.humans), len(self.robots), len(self.humans) * len(self.robots))
        self.dbn = TypeIIIDBN(self)
        self._init_budgets()
        self.last_constraint_violations = {"energy": 0.0, "risk": 0.0, "fatigue": 0.0}

    def _init_budgets(self) -> None:
        total_energy = float(sum(t.base_energy for t in self.tasks.values()))
        total_fatigue = float(sum(t.t_h * 0.015 for t in self.tasks.values()))
        total_prep = float(len(self.tasks) * (self.params.get("switch_time_tool", 1.0) + self.params.get("switch_time_direction", 0.5)) * 0.35)
        total_risk = float(sum((self.ahd_scores.get(tid, 0) / 625.0) * self.tasks[tid].t_h * 2.0 for tid in self.topo_order))
        self.params["budget_energy"] = total_energy * 1.05 if self.params["budget_energy"] is None else float(self.params["budget_energy"])
        self.params["budget_risk"] = total_risk * 0.80 if self.params["budget_risk"] is None else float(self.params["budget_risk"])
        self.params["budget_fatigue"] = total_fatigue * 0.90 if self.params["budget_fatigue"] is None else float(self.params["budget_fatigue"])
        self.params["budget_prep"] = total_prep * 1.10 if self.params["budget_prep"] is None else float(self.params["budget_prep"])

    def update_constraint_lambdas(self, metrics: dict) -> None:
        """V16-style normalized dual update for the three long-horizon budgets."""
        lr = float(self.params.get("lambda_update_lr", 0.02))
        lambda_max = float(self.params.get("lambda_max", 20.0))
        for name, metric_key, budget_key in [
            ("lambda_energy", "energy", "budget_energy"),
            ("lambda_risk", "risk", "budget_risk"),
            ("lambda_fatigue", "fatigue", "budget_fatigue"),
        ]:
            budget = max(1e-6, float(self.params[budget_key]))
            violation = (float(metrics.get(metric_key, 0.0)) - budget) / budget
            self.last_constraint_violations[metric_key] = float(violation)
            self.params[name] = float(np.clip(
                float(self.params.get(name, 0.0)) + lr * violation,
                0.0, lambda_max,
            ))


    def _topological_sort(self) -> List[int]:
        indeg = {tid: len(task.preds) for tid, task in self.tasks.items()}
        succ = {tid: [] for tid in self.tasks}
        for tid, task in self.tasks.items():
            for p in task.preds:
                succ[p].append(tid)
        q = [tid for tid, d in indeg.items() if d == 0]
        order = []
        while q:
            q.sort()
            cur = q.pop(0)
            order.append(cur)
            for v in succ[cur]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
        if len(order) != len(self.tasks):
            raise ValueError("任务前序关系存在环，无法拓扑排序。")
        return order

    @staticmethod
    def _norm_5scale(x: float) -> float:
        return max(0.0, min(1.0, (x - 1.0) / 4.0))

    @staticmethod
    def _round_half_up(x: float) -> int:
        return int(math.floor(float(x) + 0.5))

    @staticmethod
    def _clip_level_1_5(x: int) -> int:
        return max(1, min(5, int(x)))

    def _compute_complexities(self) -> Dict[int, float]:
        w = self.params["complexity_weights"]
        out = {}
        for tid, t in self.tasks.items():
            c = (
                w["H"] * self._norm_5scale(t.Hi)
                + w["O"] * self._norm_5scale(t.Oi)
                + w["A"] * self._norm_5scale(t.Ai)
                + w["T"] * self._norm_5scale(t.Ti)
                + w["P"] * self._norm_5scale(t.Pi)
            )
            out[tid] = float(c)
        return out

    def _stage1_complexity_raw(self, tid: int) -> float:
        t = self.tasks[tid]
        w = self.params.get("complexity_weights", {"H": 0.20, "O": 0.28, "A": 0.28, "T": 0.14, "P": 0.10})
        return (
            float(w["H"]) * float(t.Hi)
            + float(w["O"]) * float(t.Oi)
            + float(w["A"]) * float(t.Ai)
            + float(w["T"]) * float(t.Ti)
            + float(w["P"]) * float(t.Pi)
        )

    def _stage1_complexity_level(self, tid: int) -> int:
        return self._clip_level_1_5(self._round_half_up(self._stage1_complexity_raw(tid)))

    def _human_error_rate(self, t: Task) -> float:
        a0 = self.params["human_error_alpha0"]
        a1 = self.params["human_error_alpha1"]
        a2 = self.params["human_error_alpha2"]
        duration_norm = min(1.0, t.t_h / 20.0)
        avg_skill = float(np.mean([h.skill for h in self.humans]))
        skill_norm = min(1.0, avg_skill)
        z = a0 + a1 * duration_norm - a2 * skill_norm
        return 1.0 / (1.0 + math.exp(-z))

    def _human_need_score(self, tid: int) -> float:
        t = self.tasks[tid]
        if t.human_need_score_override is not None:
            return max(0.0, min(1.0, float(t.human_need_score_override)))
        return float(np.mean(t.necessity_dims))

    def _collab_need_score(self, tid: int) -> float:
        t = self.tasks[tid]
        if t.collab_need_score_override is not None:
            return max(0.0, min(1.0, float(t.collab_need_score_override)))
        speed_adv = max(0.0, (min(t.t_h, t.t_r) - t.t_hrc) / max(1.0, min(t.t_h, t.t_r)))
        speed_term = min(1.0, speed_adv / max(1e-6, float(self.params.get("collab_speed_norm", 0.25))))
        pd_proxy = float(np.mean(t.collaboration_dims))
        difficulty01 = self._norm_5scale(t.Oi)
        hazard01 = min(1.0, t.hazard / 3.0)
        score = (
            float(self.params.get("collab_w_speed", 0.28)) * speed_term
            + float(self.params.get("collab_w_pd", 0.22)) * pd_proxy
            + float(self.params.get("collab_w_difficulty", 0.25)) * difficulty01
            + float(self.params.get("collab_w_hazard", 0.25)) * hazard01
        )
        return max(0.0, min(1.0, score))

    def _manual_time_advantage(self, tid: int) -> float:
        t = self.tasks[tid]
        return max(0.0, (t.t_r - t.t_h) / max(1.0, t.t_r))

    def _hrc_speed_advantage(self, tid: int) -> float:
        t = self.tasks[tid]
        return max(0.0, (min(t.t_h, t.t_r) - t.t_hrc) / max(1.0, min(t.t_h, t.t_r)))

    def _complexity_induced_probability(self, tid: int) -> float:
        c_level = self._stage1_complexity_level(tid)
        table = {1: 0.02, 2: 0.05, 3: 0.10, 4: 0.18, 5: 0.30}
        return table[c_level]

    @staticmethod
    def _prob_to_level(p: float) -> int:
        if p < 0.0005:
            return 1
        if p < 0.002:
            return 2
        if p < 0.005:
            return 3
        if p < 0.02:
            return 4
        return 5

    def _compute_ahd(self, tid: int) -> int:
        t = self.tasks[tid]
        if t.ahd_override is not None:
            return int(round(t.ahd_override))
        p_ic = self._complexity_induced_probability(tid)
        p_he = self._human_error_rate(t)
        p_pf = p_ic * p_he
        L = self._prob_to_level(p_pf)
        S = self._clip_level_1_5(int(round(t.severity)))
        D = self._clip_level_1_5(int(round(t.detectability)))
        O = self._clip_level_1_5(int(round(t.occurrence)))
        return int(L * S * D * O)

    def _classify_tasks(self) -> Tuple[Dict[int, str], Dict[int, int]]:
        theta_r = float(self.params.get("theta_complexity_robot_raw", 2.40))
        theta_n = float(self.params.get("theta_necessity", 0.60))
        theta_c = float(self.params.get("theta_collaboration_iv", 0.70))
        theta_ahd_low = int(round(self.params.get("theta_ahd_low", 100)))
        theta_ahd_high = int(round(self.params.get("theta_ahd_high", 120)))
        theta_manual_hazard_max = int(round(self.params.get("theta_manual_hazard_max", 2)))
        task_types: Dict[int, str] = {}
        ahd_map: Dict[int, int] = {}
        for tid in self.topo_order:
            t = self.tasks[tid]
            # 工作簿 ``final_type`` 作为事件循环的初始任务类型。Type II
            # 后续保持冻结；I/III/IV 可在任务解锁后由事件证据重新判型。
            if t.task_type_override in {"I", "II", "III", "IV"}:
                task_types[tid] = str(t.task_type_override)
                ahd_map[tid] = int(round(self._compute_ahd(tid)))
                continue
            c_raw = self._stage1_complexity_raw(tid)
            if c_raw <= theta_r:
                task_types[tid] = "II"
                ahd_map[tid] = int(round(self._compute_ahd(tid))) if t.ahd_override is not None else 0
                continue
            ahd = self._compute_ahd(tid)
            ahd_map[tid] = ahd
            necessity = self._human_need_score(tid)
            collab = self._collab_need_score(tid)
            if ahd <= theta_ahd_low and necessity >= theta_n and t.hazard <= theta_manual_hazard_max:
                task_types[tid] = "I"
            elif ahd >= theta_ahd_high and collab >= theta_c:
                task_types[tid] = "IV"
            else:
                task_types[tid] = "III"
        return task_types, ahd_map

    def _legal_modes_for_task(self, t: Task, task_type: Optional[str] = None) -> List[str]:
        raw_legal = set(t.allow_modes) if t.allow_modes else set(MODES)
        ttype = task_type if task_type is not None else self.task_types.get(t.id)
        if ttype == "III":
            legal = set(MODES) if len(raw_legal) <= 1 else set(raw_legal)
        elif ttype in FIXED_TYPE_MODE:
            legal = {FIXED_TYPE_MODE[ttype]}
        else:
            legal = set(raw_legal)
        if t.hazard >= 2:
            legal.discard("H")
        if t.hazard >= 3:
            legal.discard("HRC")
        if not legal:
            legal.add("R")
        return [m for m in ("H", "R", "HRC") if m in legal]

    def task_diagnostics(self) -> Dict[int, Dict[str, object]]:
        out: Dict[int, Dict[str, object]] = {}
        for tid in self.topo_order:
            t = self.tasks[tid]
            out[tid] = {
                "task_name": t.name,
                "c_raw": round(float(self._stage1_complexity_raw(tid)), 4),
                "c_level": int(self._stage1_complexity_level(tid)),
                "ahd_base": int(self.ahd_scores.get(tid, 0)),
                "task_type_override": t.task_type_override,
                "human_need_score": round(self._human_need_score(tid), 4),
                "collab_need_score": round(self._collab_need_score(tid), 4),
                "final_type": self.task_types[tid],
                "mode_boundary": "/".join(self._legal_modes_for_task(t)),
                "hazard": int(t.hazard),
            }
        return out

    def make_env(self) -> "DBNCDDPGEnv":
        return DBNCDDPGEnv(self)


class DBNCDDPGEnv:
    def __init__(self, planner: DBNCDDPGPlanner) -> None:
        self.p = planner
        self.params = planner.params
        self.n_tasks = len(self.p.topo_order)
        self.mode_dim = len(MODES)
        self.binding_dim = self.p.binding_dim
        self.state_dim = self.n_tasks * 5 + len(self.p.humans) * 2 + len(self.p.robots) + 4
        self.reset()

    def reset(self) -> np.ndarray:
        self.completed = np.zeros(self.n_tasks, dtype=np.float32)
        self.task_end: Dict[int, float] = {tid: 0.0 for tid in self.p.tasks}
        self.human_available = {h.id: 0.0 for h in self.p.humans}
        self.robot_available = {r.id: 0.0 for r in self.p.robots}
        self.human_fatigue = {h.id: 0.0 for h in self.p.humans}
        self.human_last_tool = {h.id: None for h in self.p.humans}
        self.human_last_dir = {h.id: None for h in self.p.humans}
        self.robot_last_tool = {r.id: None for r in self.p.robots}
        self.robot_last_dir = {r.id: None for r in self.p.robots}
        self.total_energy = 0.0
        self.total_risk = 0.0
        self.total_fatigue = 0.0
        self.total_prep = 0.0
        self.makespan = 0.0
        self.schedule: List[ScheduledItem] = []
        self.dbn_trace: List[Dict[str, object]] = []
        self.dynamic_ahd_trace: List[Dict[str, object]] = []
        self.task_type_trace: List[Dict[str, object]] = []
        self.current_task_types: Dict[int, str] = dict(self.p.initial_task_types)
        self.dynamic_ahd_scores: Dict[int, float] = {
            tid: float(self.p.ahd_scores.get(tid, 0.0)) for tid in self.p.topo_order
        }
        self.p.dbn.reset()
        self._refresh_dynamic_ahd()
        self._refresh_task_types()
        self._refresh_beliefs()
        return self.get_state()

    def ready_tasks(self) -> List[int]:
        completed_set = {self.p.topo_order[i] for i, x in enumerate(self.completed) if x > 0.5}
        ready = []
        for tid in self.p.topo_order:
            if tid in completed_set:
                continue
            preds = self.p.tasks[tid].preds
            if all(p in completed_set for p in preds):
                ready.append(tid)
        return ready

    def _resource_availability_score(self, times: List[float]) -> float:
        if not times:
            return 0.0
        return max(0.0, 1.0 - min(times) / max(50.0, self.makespan + 20.0))

    def _tool_dir_match_best(self, task: Task, resource_kind: str) -> Tuple[float, float]:
        if resource_kind == "H":
            tool_dict = self.human_last_tool
            dir_dict = self.human_last_dir
        else:
            tool_dict = self.robot_last_tool
            dir_dict = self.robot_last_dir
        tool_scores = []
        dir_scores = []
        for rid in tool_dict:
            tool_scores.append(1.0 if tool_dict[rid] is None or tool_dict[rid] == task.tool else 0.0)
            dir_scores.append(1.0 if dir_dict[rid] is None or dir_dict[rid] == task.direction else 0.0)
        return (max(tool_scores) if tool_scores else 0.0, max(dir_scores) if dir_scores else 0.0)

    def _ancestor_set(self, tid: int) -> Set[int]:
        ancestors: Set[int] = set()
        stack = list(self.p.tasks[tid].preds)
        while stack:
            cur = stack.pop()
            if cur in ancestors:
                continue
            ancestors.add(cur)
            stack.extend(self.p.tasks[cur].preds)
        return ancestors

    def _refresh_dynamic_ahd(self) -> None:
        """Update event-wise AHD for every non-Type-II unfinished task.

        Type II is the Stage-I hard robot-priority boundary and is not retyped.
        I/III/IV tasks share the same event-wise AHD evidence so that a task can
        change *type first* and only then change its execution-mode rule.
        """
        use_dynamic = int(self.params.get("use_dynamic_ahd", 1)) != 0
        completed_ids = {
            self.p.topo_order[i] for i, value in enumerate(self.completed) if value > 0.5
        }
        progress = len(completed_ids) / max(1, self.n_tasks)
        fatigue_mean = float(np.mean(list(self.human_fatigue.values()))) if self.human_fatigue else 0.0
        fatigue_level = max(0.0, min(1.0, fatigue_mean))
        if completed_ids:
            recent_ids = [item.task_id for item in self.schedule[-3:]]
            recent_hazard = float(np.mean([self.p.tasks[x].hazard for x in recent_ids])) / 5.0 if recent_ids else 0.0
        else:
            recent_hazard = 0.0

        for tid in self.p.topo_order:
            base = float(self.p.ahd_scores.get(tid, 0.0))
            if (not use_dynamic) or tid in self.p.type2_task_ids or self.completed[self.p.tid_to_pos[tid]] > 0.5:
                self.dynamic_ahd_scores[tid] = base
                continue
            ancestors = self._ancestor_set(tid)
            if ancestors:
                local_exposure = sum(1 for x in ancestors if x in completed_ids) / len(ancestors)
            else:
                local_exposure = progress
            factor = (
                1.0
                + float(self.params.get("dynamic_ahd_w_fatigue", 0.12)) * fatigue_level
                + float(self.params.get("dynamic_ahd_w_progress", 0.06)) * progress
                + float(self.params.get("dynamic_ahd_w_local_exposure", 0.08)) * local_exposure
                + float(self.params.get("dynamic_ahd_w_recent_hazard", 0.04)) * max(0.0, min(1.0, recent_hazard))
            )
            factor = float(np.clip(
                factor,
                float(self.params.get("dynamic_ahd_min_factor", 0.85)),
                float(self.params.get("dynamic_ahd_max_factor", 1.35)),
            ))
            dynamic_value = max(0.0, base * factor)
            self.dynamic_ahd_scores[tid] = dynamic_value
            self.dynamic_ahd_trace.append({
                "step": len(self.schedule),
                "task_id": tid,
                "current_type": self.current_task_types.get(tid, self.p.initial_task_types.get(tid, "III")),
                "base_ahd": round(base, 5),
                "dynamic_ahd": round(dynamic_value, 5),
                "factor": round(factor, 6),
                "fatigue_level": round(fatigue_level, 6),
                "progress": round(progress, 6),
                "local_exposure": round(local_exposure, 6),
                "recent_hazard": round(recent_hazard, 6),
            })

    def _current_resource_state(self) -> Tuple[float, float, float]:
        fatigue = float(np.mean(list(self.human_fatigue.values()))) if self.human_fatigue else 0.0
        h_avail = self._resource_availability_score(list(self.human_available.values()))
        r_avail = self._resource_availability_score(list(self.robot_available.values()))
        return fatigue, h_avail, r_avail

    def _hard_mode_eligible_for_type(self, tid: int, task_type: str) -> bool:
        """Check whether the defining mode of I/IV is physically admissible.

        This is deliberately used *before* mode selection: if H (Type I) or HRC
        (Type IV) becomes inadmissible, the task is first moved to Type III.
        The scheduler never silently changes the mode while leaving the task type
        unchanged.
        """
        t = self.p.tasks[tid]
        raw = set(t.allow_modes) if t.allow_modes else set(MODES)
        if task_type == "I":
            return "H" in raw and t.hazard < 2
        if task_type == "IV":
            return "HRC" in raw and t.hazard < 3
        return True

    def _retype_one_task(self, tid: int, old_type: str) -> Tuple[str, str]:
        if tid in self.p.type2_task_ids:
            return "II", "Stage-I robot-priority boundary"
        if int(self.params.get("use_event_retyping", 1)) == 0:
            return old_type, "event retyping disabled"

        t = self.p.tasks[tid]
        ahd = float(self.dynamic_ahd_scores.get(tid, self.p.ahd_scores.get(tid, 0.0)))
        theta_low = float(self.params.get("theta_ahd_low", 100.0))
        theta_high = float(self.params.get("theta_ahd_high", 120.0))
        low_margin = float(self.params.get("retype_low_margin", 10.0))
        high_margin = float(self.params.get("retype_high_margin", 30.0))
        theta_n = float(self.params.get("theta_necessity", 0.60))
        theta_c = float(self.params.get("theta_collaboration_iv", 0.70))
        fatigue, h_avail, r_avail = self._current_resource_state()
        fatigue_ok = fatigue <= float(self.params.get("retype_fatigue_max_type_i", 2.5))
        # Task type describes execution suitability; temporary resource
        # occupation belongs to the hard feasible domain and must not by itself
        # relabel a task.  Human fatigue is retained because it changes human
        # suitability rather than merely delaying a binding.
        human_fit = (
            self._hard_mode_eligible_for_type(tid, "I")
            and self.p._human_need_score(tid) >= theta_n
            and fatigue_ok
        )
        hrc_fit = (
            self._hard_mode_eligible_for_type(tid, "IV")
            and self.p._collab_need_score(tid) >= theta_c
        )

        # Hysteretic transitions preserve a genuine Type-III band rather than
        # collapsing all threshold-edge tasks into I or IV at every event.
        if old_type == "I":
            if human_fit and ahd <= theta_low + low_margin:
                return "I", "manual conditions remain suitable"
            if hrc_fit and ahd >= theta_high + high_margin:
                return "IV", "hazard/collaboration evidence favors HRC"
            return "III", "manual boundary lost; return to flexible reassessment"

        if old_type == "IV":
            if not self._hard_mode_eligible_for_type(tid, "IV"):
                return "III", "HRC defining mode became hard-ineligible"
            if human_fit and ahd <= theta_low - low_margin:
                return "I", "risk fell into human-suitable region"
            if hrc_fit and ahd >= theta_high - low_margin:
                return "IV", "HRC conditions remain suitable"
            return "III", "HRC boundary lost; return to flexible reassessment"

        # Type III: require stronger evidence to leave the flexible class.
        if human_fit and ahd <= theta_low - low_margin:
            return "I", "low AHD and human suitability support Type I"
        if hrc_fit and ahd >= theta_high + high_margin:
            return "IV", "high AHD and collaboration demand support Type IV"
        return "III", "remain DBN-flexible"

    def _refresh_task_types(self) -> None:
        """Retype only currently unlocked non-Type-II tasks at event epochs."""
        ready = set(self.ready_tasks())
        fatigue, h_avail, r_avail = self._current_resource_state()
        for tid in self.p.topo_order:
            if tid in self.p.type2_task_ids:
                self.current_task_types[tid] = "II"
                continue
            if self.completed[self.p.tid_to_pos[tid]] > 0.5 or tid not in ready:
                continue
            old = self.current_task_types.get(tid, self.p.initial_task_types.get(tid, "III"))
            new, reason = self._retype_one_task(tid, old)
            if new != old:
                self.current_task_types[tid] = new
                self.task_type_trace.append({
                    "step": len(self.schedule),
                    "task_id": tid,
                    "task_name": self.p.tasks[tid].name,
                    "old_type": old,
                    "new_type": new,
                    "dynamic_ahd": round(float(self.dynamic_ahd_scores.get(tid, 0.0)), 5),
                    "fatigue": round(fatigue, 6),
                    "human_availability": round(h_avail, 6),
                    "robot_availability": round(r_avail, 6),
                    "reason": reason,
                })

    def _build_dbn_observation(self, tid: int) -> Dict[str, float]:
        task = self.p.tasks[tid]
        human_times = list(self.human_available.values())
        robot_times = list(self.robot_available.values())
        tool_h, dir_h = self._tool_dir_match_best(task, "H")
        tool_r, dir_r = self._tool_dir_match_best(task, "R")
        return {
            "dynamic_ahd": float(self.dynamic_ahd_scores.get(tid, self.p.ahd_scores.get(tid, 0.0))),
            "human_fatigue": float(np.mean(list(self.human_fatigue.values()))) if self.human_fatigue else 0.0,
            "human_avail": self._resource_availability_score(human_times),
            "robot_avail": self._resource_availability_score(robot_times),
            "tool_match_h": tool_h,
            "tool_match_r": tool_r,
            "dir_match_h": dir_h,
            "dir_match_r": dir_r,
        }

    def _refresh_beliefs(self) -> None:
        self.beta_map: Dict[int, np.ndarray] = {}
        for tid in self.p.topo_order:
            ttype = self.current_task_types.get(tid, self.p.initial_task_types[tid])
            if self.completed[self.p.tid_to_pos[tid]] > 0.5:
                continue
            if ttype == "III":
                legal = self.feasible_modes(tid)
                obs = self._build_dbn_observation(tid)
                beta = self.p.dbn.update(tid, obs, legal)
                self.beta_map[tid] = beta
                self.dbn_trace.append({
                    "step": len(self.schedule),
                    "task_id": tid,
                    "task_type": ttype,
                    "base_ahd": round(float(self.p.ahd_scores.get(tid, 0.0)), 5),
                    "dynamic_ahd": round(float(self.dynamic_ahd_scores.get(tid, self.p.ahd_scores.get(tid, 0.0))), 5),
                    "legal_modes": "/".join(legal),
                    "p_h": round(float(beta[0]), 5),
                    "p_r": round(float(beta[1]), 5),
                    "p_hrc": round(float(beta[2]), 5),
                })
            else:
                fixed = FIXED_TYPE_MODE[ttype]
                beta = np.zeros(3, dtype=np.float32)
                beta[MODE_INDEX[fixed]] = 1.0
                self.beta_map[tid] = beta

    def get_state(self) -> np.ndarray:
        ready = np.zeros(self.n_tasks, dtype=np.float32)
        for tid in self.ready_tasks():
            ready[self.p.tid_to_pos[tid]] = 1.0
        beta_flat = np.zeros((self.n_tasks, 3), dtype=np.float32)
        if int(self.params.get("use_dbn_state", 1)) != 0:
            for tid in self.p.topo_order:
                pos = self.p.tid_to_pos[tid]
                beta_flat[pos] = self.beta_map.get(tid, np.zeros(3, dtype=np.float32))
        h_avail = np.array([self.human_available[h.id] for h in self.p.humans], dtype=np.float32) / 100.0
        h_fat = np.array([self.human_fatigue[h.id] for h in self.p.humans], dtype=np.float32)
        r_avail = np.array([self.robot_available[r.id] for r in self.p.robots], dtype=np.float32) / 100.0
        global_part = np.array([
            self.makespan / 100.0,
            self.total_energy / 100.0,
            self.total_risk / 100.0,
            self.total_fatigue / 100.0,
        ], dtype=np.float32)
        return np.concatenate([self.completed, ready, beta_flat.reshape(-1), h_avail, h_fat, r_avail, global_part]).astype(np.float32)

    def legal_task_mask(self) -> np.ndarray:
        mask = np.zeros(self.n_tasks, dtype=np.float32)
        for tid in self.ready_tasks():
            mask[self.p.tid_to_pos[tid]] = 1.0
        return mask

    def feasible_modes(self, tid: int) -> List[str]:
        """Return modes from the *current task type*, then apply hard safety.

        Type I means H, Type II means R, Type IV means HRC.  A mode change for
        I/IV is therefore preceded by event-wise task retyping; only Type III
        exposes H/R/HRC to DBN-guided scheduling.
        """
        current_type = self.current_task_types.get(tid, self.p.initial_task_types[tid])
        modes = list(self.p._legal_modes_for_task(self.p.tasks[tid], task_type=current_type))
        if current_type == "III" and int(self.params.get("use_dynamic_ahd", 1)) != 0:
            ahd_t = float(self.dynamic_ahd_scores.get(tid, self.p.ahd_scores.get(tid, 0.0)))
            if ahd_t >= float(self.params.get("theta_dynamic_ahd_h_block", 120.0)):
                modes = [m for m in modes if m != "H"]
        if not modes:
            # An I/IV defining mode should normally have been removed by
            # ``_refresh_task_types`` first.  Keep a safe fallback for malformed
            # external inputs so the environment never emits an illegal action.
            modes = ["R"]
        return modes


    def candidate_bindings(self, tid: int, mode: str) -> List[JointDecodedAction]:
        if mode == "H":
            return [JointDecodedAction(task_id=tid, mode=mode, human_id=h.id, binding_index=i) for i, h in enumerate(self.p.humans)]
        if mode == "R":
            return [JointDecodedAction(task_id=tid, mode=mode, robot_id=r.id, binding_index=i) for i, r in enumerate(self.p.robots)]
        actions = []
        idx = 0
        for h in self.p.humans:
            for r in self.p.robots:
                actions.append(JointDecodedAction(task_id=tid, mode=mode, human_id=h.id, robot_id=r.id, binding_index=idx))
                idx += 1
        return actions

    def _switch_penalty_human(self, human_id: str, task: Task) -> Tuple[float, float]:
        dt = 0.0
        de = 0.0
        if self.human_last_tool[human_id] is not None and self.human_last_tool[human_id] != task.tool:
            dt += self.params["switch_time_tool"]
            de += self.params["switch_energy_tool"]
        if self.human_last_dir[human_id] is not None and self.human_last_dir[human_id] != task.direction:
            dt += self.params["switch_time_direction"]
            de += self.params["switch_energy_direction"]
        return dt, de

    def _switch_penalty_robot(self, robot_id: str, task: Task) -> Tuple[float, float]:
        dt = 0.0
        de = 0.0
        if self.robot_last_tool[robot_id] is not None and self.robot_last_tool[robot_id] != task.tool:
            dt += self.params["switch_time_tool"]
            de += self.params["switch_energy_tool"]
        if self.robot_last_dir[robot_id] is not None and self.robot_last_dir[robot_id] != task.direction:
            dt += self.params["switch_time_direction"]
            de += self.params["switch_energy_direction"]
        return dt, de

    def _effective_duration(self, task: Task, action: JointDecodedAction) -> Tuple[float, float, float]:
        if action.mode == "H":
            h = self.p.humans[self.p.human_idx[action.human_id]]
            duration = task.t_h / max(0.4, h.skill)
            fatigue = duration * h.fatigue_rate
            exposure = 1.0
            return duration, fatigue, exposure
        if action.mode == "R":
            r = self.p.robots[self.p.robot_idx[action.robot_id]]
            use_robot_speed_factor = bool(int(self.params.get("use_robot_speed_factor", 0)))
            duration = task.t_r / max(0.4, r.speed_factor) if use_robot_speed_factor else task.t_r
            return duration, 0.0, 0.0
        h = self.p.humans[self.p.human_idx[action.human_id]]
        r = self.p.robots[self.p.robot_idx[action.robot_id]]
        combo = 0.55 * h.skill + 0.45 * r.speed_factor
        duration = task.t_hrc / max(0.5, combo)
        fatigue = duration * h.fatigue_rate * self.params["fatigue_discount_hrc"]
        exposure = self.params["risk_discount_hrc"]
        return duration, fatigue, exposure

    def _dynamic_hrc_exposure(self, task: Task, action: JointDecodedAction, base_exposure: float) -> float:
        if action.mode != "HRC":
            return base_exposure
        collab_gain = float(np.mean(task.collaboration_dims)) if task.collaboration_dims else 0.0
        bonus = self.params.get("hrc_exposure_collab_bonus", 0.25)
        min_exposure = self.params.get("min_hrc_exposure", 0.35)
        adjusted = base_exposure * (1.0 - bonus * collab_gain)
        return max(min_exposure, min(1.0, adjusted))

    def _human_risk_intensity(self, task: Task) -> float:
        hazard_norm = max(0.0, min(1.0, float(task.hazard) / 5.0))
        ahd_now = float(self.dynamic_ahd_scores.get(task.id, self.p.ahd_scores.get(task.id, 0.0)))
        ahd_norm = max(0.0, min(1.0, ahd_now / 625.0))
        w_hazard = float(self.params.get("human_risk_weight_hazard", 0.30))
        w_ahd = float(self.params.get("human_risk_weight_ahd", 0.70))
        w_sum = w_hazard + w_ahd
        if w_sum <= 1e-8:
            w_hazard, w_ahd, w_sum = 0.30, 0.70, 1.0
        return (w_hazard * hazard_norm + w_ahd * ahd_norm) / w_sum

    def _human_risk_delta(self, task: Task, action: JointDecodedAction, duration: float, base_exposure: float) -> float:
        if action.mode == "R":
            return 0.0
        exposure = self._dynamic_hrc_exposure(task, action, base_exposure)
        intensity = self._human_risk_intensity(task)
        fatigue_before = self.human_fatigue.get(action.human_id, 0.0) if action.human_id else 0.0
        fatigue_amp = 1.0 + float(self.params.get("fatigue_risk_amplifier", 0.40)) * fatigue_before
        risk_scale = float(self.params.get("human_risk_scale", 5.0))
        return risk_scale * duration * exposure * intensity * fatigue_amp

    def projection_context(self) -> Dict[str, np.ndarray]:
        """Return the exact feasible-set data used by environment and learner.

        Keeping this description in replay prevents the target actor and the
        online actor update from silently using a different action domain from
        the environment decoder.
        """
        task_mask = self.legal_task_mask().astype(np.float32)
        beta_by_task = np.zeros((self.n_tasks, self.mode_dim), dtype=np.float32)
        mode_mask_by_task = np.zeros((self.n_tasks, self.mode_dim), dtype=np.float32)
        for tid in self.p.topo_order:
            pos = self.p.tid_to_pos[tid]
            if (
                int(self.params.get("use_dbn_mode_bias", 1)) != 0
                and int(self.params.get("use_posterior_mapping", 1)) != 0
            ):
                beta_by_task[pos] = self.beta_map.get(
                    tid,
                    np.array([1.0 / 3.0] * self.mode_dim, dtype=np.float32),
                )
            else:
                beta_by_task[pos] = np.zeros(self.mode_dim, dtype=np.float32)
            for mode in self.feasible_modes(tid):
                mode_mask_by_task[pos, MODE_INDEX[mode]] = 1.0

        binding_mask_by_mode = np.zeros((self.mode_dim, self.binding_dim), dtype=np.float32)
        binding_bonus_by_mode = np.zeros((self.mode_dim, self.binding_dim), dtype=np.float32)
        reference_tid = self.p.topo_order[0]
        for mode in MODES:
            mode_idx = MODE_INDEX[mode]
            for candidate in self.candidate_bindings(reference_tid, mode):
                bind_idx = candidate.binding_index
                binding_mask_by_mode[mode_idx, bind_idx] = 1.0
                binding_bonus_by_mode[mode_idx, bind_idx] = self._candidate_binding_availability_bonus(candidate)

        return {
            "task_mask": task_mask,
            "beta_by_task": beta_by_task,
            "mode_mask_by_task": mode_mask_by_task,
            "binding_mask_by_mode": binding_mask_by_mode,
            "binding_bonus_by_mode": binding_bonus_by_mode,
        }

    def decode_action(
        self,
        action_vector: np.ndarray,
        context: Optional[Dict[str, np.ndarray]] = None,
    ) -> Tuple[JointDecodedAction, np.ndarray]:
        n_tasks = self.n_tasks
        n_modes = len(MODES)
        action_vector = np.asarray(action_vector, dtype=np.float32).reshape(-1)
        expected_dim = n_tasks + n_modes + self.binding_dim
        if action_vector.size != expected_dim:
            raise ValueError(f"动作维度应为 {expected_dim}，实际为 {action_vector.size}")
        task_pref = action_vector[:n_tasks]
        mode_pref = action_vector[n_tasks:n_tasks + n_modes]
        bind_pref = action_vector[n_tasks + n_modes:]
        context = self.projection_context() if context is None else context
        task_mask = np.asarray(context["task_mask"], dtype=np.float32)
        if not np.any(task_mask > 0.5):
            raise RuntimeError("当前状态不存在可执行前沿任务，不能继续解码动作。")
        masked_task = task_pref.copy()
        masked_task[task_mask < 0.5] = -1e9
        task_pos = int(np.argmax(masked_task))
        tid = self.p.topo_order[task_pos]
        beta = np.asarray(context["beta_by_task"], dtype=np.float32)[task_pos]
        mode_mask = np.asarray(context["mode_mask_by_task"], dtype=np.float32)[task_pos]
        masked_mode = mode_pref + float(self.params.get("dbn_guidance_strength", 0.35)) * beta
        masked_mode = masked_mode.copy()
        masked_mode[mode_mask < 0.5] = -1e9
        mode_idx = int(np.argmax(masked_mode))
        mode = MODES[mode_idx]
        candidates = self.candidate_bindings(tid, mode)
        binding_mask = np.asarray(context["binding_mask_by_mode"], dtype=np.float32)[mode_idx]
        binding_bonus = np.asarray(context["binding_bonus_by_mode"], dtype=np.float32)[mode_idx]
        masked_binding = bind_pref + binding_bonus
        masked_binding = masked_binding.copy()
        masked_binding[binding_mask < 0.5] = -1e9
        binding_idx = int(np.argmax(masked_binding))
        best = next((candidate for candidate in candidates if candidate.binding_index == binding_idx), None)
        if best is None:
            raise RuntimeError(f"模式 {mode} 的资源绑定 {binding_idx} 不在当前可行域内。")
        exec_vec = np.zeros(n_tasks + n_modes + self.binding_dim, dtype=np.float32)
        exec_vec[task_pos] = 1.0
        exec_vec[n_tasks + mode_idx] = 1.0
        exec_vec[n_tasks + n_modes + best.binding_index] = 1.0
        return best, exec_vec

    def _candidate_binding_availability_bonus(self, action: JointDecodedAction) -> float:
        if action.mode == "H":
            return max(0.0, 1.0 - self.human_available[action.human_id] / max(50.0, self.makespan + 20.0))
        if action.mode == "R":
            return max(0.0, 1.0 - self.robot_available[action.robot_id] / max(50.0, self.makespan + 20.0))
        value = max(self.human_available[action.human_id], self.robot_available[action.robot_id])
        return max(0.0, 1.0 - value / max(50.0, self.makespan + 20.0))

    def step(
        self,
        action_vector: np.ndarray,
        projection_context: Optional[Dict[str, np.ndarray]] = None,
    ) -> Tuple[np.ndarray, float, bool, dict]:
        action, executed_vec = self.decode_action(action_vector, context=projection_context)
        task = self.p.tasks[action.task_id]
        prev_makespan = self.makespan
        pred_finish = max([self.task_end[p] for p in task.preds], default=0.0)
        switch_t = 0.0
        switch_e = 0.0
        if action.mode == "H":
            start = max(pred_finish, self.human_available[action.human_id])
            st, se = self._switch_penalty_human(action.human_id, task)
            switch_t += st
            switch_e += se
        elif action.mode == "R":
            start = max(pred_finish, self.robot_available[action.robot_id])
            st, se = self._switch_penalty_robot(action.robot_id, task)
            switch_t += st
            switch_e += se
        else:
            start = max(pred_finish, self.human_available[action.human_id], self.robot_available[action.robot_id])
            st_h, se_h = self._switch_penalty_human(action.human_id, task)
            st_r, se_r = self._switch_penalty_robot(action.robot_id, task)
            switch_t += st_h + st_r
            switch_e += se_h + se_r
        duration, fatigue_delta, exposure_factor = self._effective_duration(task, action)
        prep_time = switch_t
        end = start + prep_time + duration
        delta_time = max(0.0, end - prev_makespan)
        mode_energy_factor = {"H": 0.8, "R": 1.0, "HRC": 1.15}[action.mode]
        delta_energy = task.base_energy * mode_energy_factor + switch_e
        delta_risk = self._human_risk_delta(task, action, duration, exposure_factor)
        # Final V16 protocol: stationary critic components are normalized by the
        # same frozen paper budgets/scale used for evaluation.  DBN affects the
        # augmented state and feasible-domain projection, not a pseudo-reward.
        time_scale = max(float(self.params.get("reward_time_scale", 430.0)), 1.0)
        normalized_deltas = np.asarray([
            delta_time / time_scale,
            delta_energy / max(float(self.params.get("budget_energy", 13.0)), 1e-8),
            delta_risk / max(float(self.params.get("budget_risk", 85.0)), 1e-8),
            fatigue_delta / max(float(self.params.get("budget_fatigue", 6.0)), 1e-8),
        ], dtype=np.float32)
        lambda_risk = float(self.params["lambda_risk"]) if int(self.params.get("use_ahd_reward", 1)) != 0 else 0.0
        reward = -(
            float(normalized_deltas[0])
            + float(self.params["lambda_energy"]) * float(normalized_deltas[1])
            + lambda_risk * float(normalized_deltas[2])
            + float(self.params["lambda_fatigue"]) * float(normalized_deltas[3])
        )
        if action.mode == "H":
            self.human_available[action.human_id] = end
            self.human_fatigue[action.human_id] += fatigue_delta
            self.human_last_tool[action.human_id] = task.tool
            self.human_last_dir[action.human_id] = task.direction
        elif action.mode == "R":
            self.robot_available[action.robot_id] = end
            self.robot_last_tool[action.robot_id] = task.tool
            self.robot_last_dir[action.robot_id] = task.direction
        else:
            self.human_available[action.human_id] = end
            self.robot_available[action.robot_id] = end
            self.human_fatigue[action.human_id] += fatigue_delta
            self.human_last_tool[action.human_id] = task.tool
            self.human_last_dir[action.human_id] = task.direction
            self.robot_last_tool[action.robot_id] = task.tool
            self.robot_last_dir[action.robot_id] = task.direction
        self.task_end[task.id] = end
        self.completed[self.p.tid_to_pos[task.id]] = 1.0
        self.makespan = max(self.makespan, end)
        self.total_energy += delta_energy
        self.total_risk += delta_risk
        self.total_fatigue += fatigue_delta
        self.total_prep += prep_time
        self.schedule.append(ScheduledItem(
            task_id=task.id,
            task_name=task.name,
            task_type=self.current_task_types.get(task.id, self.p.initial_task_types[task.id]),
            mode=action.mode,
            binding=action.binding_str(),
            start=start,
            end=end,
            delta_time=delta_time,
            delta_energy=delta_energy,
            delta_risk=delta_risk,
            delta_fatigue=fatigue_delta,
        ))
        # Event boundary: refresh evidence -> retype unlocked I/III/IV tasks ->
        # update DBN beliefs only for tasks currently classified as Type III.
        self._refresh_dynamic_ahd()
        self._refresh_task_types()
        self._refresh_beliefs()
        done = bool(np.all(self.completed > 0.5))
        info = self.metrics()
        info["executed_action_vector"] = executed_vec
        info["transition_deltas"] = normalized_deltas.copy()
        return self.get_state(), float(reward), done, info

    def metrics(self) -> dict:
        return {
            "makespan": round(self.makespan, 4),
            "energy": round(self.total_energy, 4),
            "risk": round(self.total_risk, 4),
            "fatigue": round(self.total_fatigue, 4),
            "prep_time": round(self.total_prep, 4),
        }


def _solve_common_descent_dual_qp(gram_matrix, eps_vec):
    """Solve the dual of  min ||d||^2  s.t.  G d >= eps  (rows of G are g_i).

    Dual:  min 0.5 a^T H a - eps^T a   s.t.  a >= 0,  where H = G G^T (k x k).

    Solved exactly by active-set subset enumeration (k <= 3, so at most 7
    non-empty subsets).  Returns the dual vector alpha (k,) or None when the
    primal is infeasible (no common-descent direction exists for eps > 0).
    """
    k = int(gram_matrix.shape[0])
    if k == 0:
        return None
    dtype = gram_matrix.dtype
    device = gram_matrix.device
    best_alpha: Optional[torch.Tensor] = None
    best_obj = float("inf")
    for mask in range(1, 1 << k):
        s_idx = [i for i in range(k) if mask & (1 << i)]
        s_t = torch.tensor(s_idx, dtype=torch.long, device=device)
        h_ss = gram_matrix[s_t][:, s_t] + 1e-10 * torch.eye(len(s_idx), dtype=dtype, device=device)
        eps_s = eps_vec[s_t]
        try:
            alpha_s = torch.linalg.solve(h_ss, eps_s)
        except Exception:
            continue
        if bool((alpha_s <= 1e-12).any().item()):
            continue
        alpha_full = torch.zeros(k, dtype=dtype, device=device)
        alpha_full[s_t] = alpha_s
        h_alpha = gram_matrix @ alpha_full
        not_s = [i for i in range(k) if i not in s_idx]
        if not_s:
            not_s_t = torch.tensor(not_s, dtype=torch.long, device=device)
            if bool((h_alpha[not_s_t] < eps_vec[not_s_t] - 1e-9).any().item()):
                continue
        obj = float((0.5 * alpha_full @ h_alpha - eps_vec @ alpha_full).item())
        if obj < best_obj:
            best_obj = obj
            best_alpha = alpha_full
    return best_alpha


def _flatten_grad_list(grads, params):
    pieces = []
    for grad, param in zip(grads, params):
        if grad is None:
            pieces.append(torch.zeros_like(param).reshape(-1))
        else:
            pieces.append(grad.reshape(-1))
    return torch.cat(pieces) if pieces else torch.zeros(0)


def _assign_flat_grad(params, flat_grad):
    offset = 0
    for param in params:
        count = param.numel()
        param.grad = flat_grad[offset:offset + count].view_as(param).clone()
        offset += count
    if offset != flat_grad.numel():
        raise RuntimeError('Flat actor-gradient size mismatch')


def _parameter_space_common_descent(
    component_param_grads,
    active_constraints,
    violations,
    perf_grads,
    *,
    severity_power=1.5,
    min_relative_strength=0.10,
    performance_secondary_ratio=0.20,
    severe_violation_threshold=0.25,
):
    """Violation-aware common descent in the *actor parameter space*.

    ``component_param_grads[name]`` is the flattened gradient of the raw
    stationary cost J_name with respect to the actual actor parameters theta.
    The optimizer receives the returned vector directly as ``parameter.grad``.
    Therefore, for an active cost J_i, a positive inner product

        <grad_theta J_i, d_theta> > 0

    means the parameter update ``theta <- theta - lr*d_theta`` is a first-order
    descent step for that cost.

    To avoid allowing a tiny-gradient constraint to be ignored solely because
    of scale, the common-descent cone is built from *unit-normalized* parameter
    gradients.  The required projection strength is allocated from the current
    normalized violation severity.  The largest violation receives strength 1;
    every other active constraint keeps a small positive guard strength.

    Performance is strictly secondary.  When the largest normalized violation
    is severe (>= ``severe_violation_threshold``), the update is pure
    feasibility restoration.  Near the feasible boundary, only the component
    of the performance gradient lying in the null space of all active
    constraint gradients is added.
    """
    names = sorted(name for name in ('energy', 'risk', 'fatigue') if name in active_constraints)
    g_perf = perf_grads.detach()
    perf_norm = torch.linalg.vector_norm(g_perf)

    if not names:
        return g_perf.clone(), {
            'vcd_num_active_constraints': 0.0,
            'vcd_common_descent_feasible': 1.0,
            'vcd_fallback_used': 0.0,
            'vcd_parameter_space': 1.0,
            'vcd_final_param_grad_norm': float(perf_norm.item()),
            'vcd_performance_null_norm': float(perf_norm.item()),
            'vcd_max_positive_violation': 0.0,
        }

    raw_grads = [component_param_grads[name].detach() for name in names]
    norms = torch.stack([torch.linalg.vector_norm(g) for g in raw_grads])
    nonzero = norms > 1e-12
    raw_v = torch.tensor(
        [max(float(violations.get(name, 0.0)), 0.0) for name in names],
        dtype=g_perf.dtype, device=g_perf.device,
    )
    v_max = float(raw_v.max().item()) if raw_v.numel() else 0.0

    if not bool(nonzero.any().item()):
        return g_perf.clone(), {
            'vcd_num_active_constraints': float(len(names)),
            'vcd_common_descent_feasible': 0.0,
            'vcd_fallback_used': 1.0,
            'vcd_parameter_space': 1.0,
            'vcd_final_param_grad_norm': float(perf_norm.item()),
            'vcd_performance_null_norm': float(perf_norm.item()),
            'vcd_max_positive_violation': v_max,
        }

    # Unit-normalized parameter gradients.  This removes critic-gradient scale
    # as a hidden priority mechanism; violation severity determines priority.
    unit_grads = []
    for g, n in zip(raw_grads, norms):
        if float(n.item()) <= 1e-12:
            unit_grads.append(torch.zeros_like(g))
        else:
            unit_grads.append(g / n)
    u_stack = torch.stack(unit_grads, dim=0)  # k x P

    if v_max <= 1e-12:
        severity = torch.ones_like(raw_v)
    else:
        severity = torch.clamp(raw_v / v_max, min=0.0, max=1.0)
    urgency = float(min_relative_strength) + (1.0 - float(min_relative_strength)) * torch.pow(
        severity, float(severity_power)
    )

    # Solve min ||d||^2 s.t. <u_i,d> >= urgency_i.  Since u_i are unit
    # gradients, urgency directly controls how much update-direction projection
    # each active budget receives.  k<=3 so the exact active-set dual is tiny.
    gram = u_stack @ u_stack.t()
    alpha = _solve_common_descent_dual_qp(gram, urgency)
    feasible = alpha is not None
    fallback_used = 0.0
    most_violated_idx = int(torch.argmax(raw_v).item())
    if feasible:
        d_unit = u_stack.t() @ alpha
    else:
        d_unit = unit_grads[most_violated_idx].clone()
        fallback_used = 1.0

    # Return to a natural actor-gradient magnitude.  The weighted mean of the
    # original active-gradient norms preserves optimizer scale while the unit
    # QP above controls direction/priority.  A tiny numerical floor prevents a
    # saturated actor from producing an exactly zero restoration step.
    denom = torch.clamp(urgency.sum(), min=1e-12)
    reference_norm = (urgency * norms).sum() / denom
    reference_norm = torch.maximum(reference_norm, torch.tensor(1e-6, dtype=reference_norm.dtype, device=reference_norm.device))
    d_norm = torch.linalg.vector_norm(d_unit)
    if float(d_norm.item()) > 1e-12:
        d_constraint = d_unit * (reference_norm / d_norm)
    else:
        d_constraint = d_unit

    # Performance is lexicographically secondary.  With a severe violation the
    # actor performs pure restoration.  Otherwise add only a null-space
    # performance component, scaled below the restoration magnitude.
    d_perf_null = torch.zeros_like(d_constraint)
    if v_max < float(severe_violation_threshold) and float(perf_norm.item()) > 1e-12:
        rhs = u_stack @ g_perf
        try:
            coeffs = torch.linalg.solve(
                gram + 1e-8 * torch.eye(len(names), dtype=gram.dtype, device=gram.device), rhs
            )
            perf_null = g_perf - u_stack.t() @ coeffs
        except Exception:
            perf_null = g_perf
        pn = torch.linalg.vector_norm(perf_null)
        if float(pn.item()) > 1e-12:
            target = float(performance_secondary_ratio) * torch.linalg.vector_norm(d_constraint)
            d_perf_null = perf_null * (target / pn)

    d_final = d_constraint + d_perf_null

    diagnostics = {
        'vcd_num_active_constraints': float(len(names)),
        'vcd_common_descent_feasible': float(feasible),
        'vcd_fallback_used': float(fallback_used),
        'vcd_parameter_space': 1.0,
        'vcd_constraint_param_grad_norm': float(torch.linalg.vector_norm(d_constraint).item()),
        'vcd_performance_null_norm': float(torch.linalg.vector_norm(d_perf_null).item()),
        'vcd_final_param_grad_norm': float(torch.linalg.vector_norm(d_final).item()),
        'vcd_reference_param_grad_norm': float(reference_norm.item()),
        'vcd_max_positive_violation': float(v_max),
        'vcd_severity_power': float(severity_power),
        'vcd_min_relative_strength': float(min_relative_strength),
    }
    for idx, name in enumerate(names):
        raw_ip = float(torch.dot(raw_grads[idx], d_final).item())
        unit_ip = float(torch.dot(unit_grads[idx], d_final).item())
        diagnostics[f'vcd_param_descent_ip_{name}'] = raw_ip
        diagnostics[f'vcd_unit_descent_ip_{name}'] = unit_ip
        diagnostics[f'vcd_param_grad_norm_{name}'] = float(norms[idx].item())
        diagnostics[f'vcd_violation_weight_{name}'] = float(severity[idx].item())
        diagnostics[f'vcd_restoration_strength_{name}'] = float(urgency[idx].item())
    if 'energy' in names and 'risk' in names:
        ei, ri = names.index('energy'), names.index('risk')
        diagnostics['vcd_energy_risk_cosine_original'] = float(torch.dot(unit_grads[ei], unit_grads[ri]).item())
    return d_final, diagnostics

class DDPGAgent:
    """V16-style DBN-CDDPG adapted to the hierarchical task/mode/binding decoder.

    Key protocol points:
      * four stationary critics: performance, energy, risk, fatigue;
      * undiscounted finite-horizon targets (gamma=1 by default);
      * replay stores the *executed hard projected action* and frozen projection context;
      * target actor is hard-projected before target-Q evaluation;
      * online actor uses hard-forward / smooth-backward straight-through projection;
      * active constraint gradients are coordinated in actor parameter space using
        violation-severity-aware common descent (V16 protocol).
    """

    CRITIC_KEYS: Tuple[str, ...] = ("performance", "energy", "risk", "fatigue")

    def __init__(self, state_dim: int, action_dim: int, planner: DBNCDDPGPlanner, device: str = "cpu") -> None:
        self.device = torch.device(device)
        self.planner = planner
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.n_tasks = len(planner.topo_order)
        self.n_modes = len(MODES)
        self.binding_dim = planner.binding_dim
        self.gamma = float(planner.params.get("gamma", 1.0))
        self.tau = float(planner.params.get("target_tau", 0.01))
        self.batch_size = int(planner.params.get("batch_size", 64))
        self.warmup_steps = int(planner.params.get("warmup_steps", 128))
        self.update_every = max(1, int(planner.params.get("update_every", 4)))
        self.projection_temperature = max(1e-4, float(planner.params.get("projection_temperature", 0.25)))
        self.actor_backward_temperature = max(1e-4, float(planner.params.get("actor_backward_temperature", 1.0)))
        self.guidance_strength = float(planner.params.get("dbn_guidance_strength", 0.35))
        self.actor_output_bound = float(planner.params.get("actor_output_bound", 1.0))
        self.noise_start = float(planner.params.get("noise_start", 0.30))
        self.noise_end = float(planner.params.get("noise_end", 0.05))
        total_steps = max(1, int(planner.params.get("_total_training_steps", 20000)))
        self.noise_decay_steps = max(
            1,
            int(float(planner.params.get("noise_decay_fraction", 0.80)) * total_steps),
        )

        hidden = int(planner.params.get("hidden_dim", 128))
        self.actor = HierarchicalActor(
            state_dim, self.n_tasks, self.binding_dim, hidden=hidden,
            output_bound=self.actor_output_bound,
        ).to(self.device)
        self.actor_target = HierarchicalActor(
            state_dim, self.n_tasks, self.binding_dim, hidden=hidden,
            output_bound=self.actor_output_bound,
        ).to(self.device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=float(planner.params.get("actor_lr", 1e-4)))

        critic_lr = float(planner.params.get("critic_lr", 3e-4))
        self.critics: Dict[str, Critic] = {
            key: Critic(state_dim, action_dim, hidden=hidden).to(self.device)
            for key in self.CRITIC_KEYS
        }
        self.critic_targets: Dict[str, Critic] = {
            key: Critic(state_dim, action_dim, hidden=hidden).to(self.device)
            for key in self.CRITIC_KEYS
        }
        self.critic_opts: Dict[str, optim.Optimizer] = {}
        for key in self.CRITIC_KEYS:
            self.critic_targets[key].load_state_dict(self.critics[key].state_dict())
            self.critic_opts[key] = optim.Adam(self.critics[key].parameters(), lr=critic_lr)

        self.replay = ReplayBuffer(int(planner.params.get("buffer_size", 50000)))
        self.update_calls = 0
        self.learn_steps = 0
        self.vcd_severity_power = float(planner.params.get("vcd_severity_power", 1.5))
        self.vcd_min_relative_strength = float(planner.params.get("vcd_min_relative_strength", 0.10))
        self.vcd_performance_secondary_ratio = float(planner.params.get("vcd_performance_secondary_ratio", 0.20))
        self.vcd_severe_violation_threshold = float(planner.params.get("vcd_severe_violation_threshold", 0.25))

    def _noise(self) -> float:
        fraction = min(1.0, self.update_calls / max(1, self.noise_decay_steps))
        return float(self.noise_start + fraction * (self.noise_end - self.noise_start))

    @torch.no_grad()
    def act(self, state: np.ndarray, explore: bool = True) -> np.ndarray:
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        action = self.actor(s).squeeze(0).cpu().numpy()
        if explore:
            action = action + np.random.normal(0.0, self._noise(), size=action.shape).astype(np.float32)
        return np.clip(action, -self.actor_output_bound, self.actor_output_bound).astype(np.float32)

    def _context_to_tensors(self, context: Dict[str, np.ndarray]) -> Dict[str, torch.Tensor]:
        tensors = {
            key: torch.as_tensor(context[key], dtype=torch.float32, device=self.device)
            for key in PROJECTION_CONTEXT_KEYS
        }
        if tensors["task_mask"].ndim == 1:
            tensors = {key: value.unsqueeze(0) for key, value in tensors.items()}
        return tensors

    @staticmethod
    def _masked_one_hot(
        logits: torch.Tensor,
        mask: torch.Tensor,
        *,
        forward_temperature: float,
        straight_through: bool,
        surrogate_temperature: Optional[float] = None,
    ) -> torch.Tensor:
        valid = mask > 0.5
        has_valid = valid.any(dim=-1, keepdim=True)
        masked_logits = logits.masked_fill(~valid, -1e9)
        hard_index = masked_logits.argmax(dim=-1)
        hard = nn.functional.one_hot(hard_index, num_classes=logits.shape[-1]).to(logits.dtype)
        hard = hard * has_valid.to(logits.dtype)
        if not straight_through:
            return hard
        temperature = max(1e-4, float(surrogate_temperature if surrogate_temperature is not None else forward_temperature))
        relaxed = torch.softmax(masked_logits / temperature, dim=-1)
        relaxed = relaxed * has_valid.to(logits.dtype)
        return hard + relaxed - relaxed.detach()

    def project_action(
        self,
        raw_action: torch.Tensor,
        context: Dict[str, np.ndarray],
        straight_through: bool,
    ) -> torch.Tensor:
        """Project onto the exact frozen hierarchical feasible domain.

        Forward values are the same one-hot task/mode/binding action executed by
        ``DBNCDDPGEnv.decode_action``.  During actor optimisation only, the
        backward path uses the smoother V16 surrogate temperature.
        """
        squeeze_output = raw_action.ndim == 1
        if squeeze_output:
            raw_action = raw_action.unsqueeze(0)
        if raw_action.shape[-1] != self.action_dim:
            raise ValueError(f"动作维度应为 {self.action_dim}，实际为 {raw_action.shape[-1]}")
        tensors = self._context_to_tensors(context)
        if tensors["task_mask"].shape[0] != raw_action.shape[0]:
            raise ValueError("动作批量大小与投影上下文批量大小不一致。")

        task_logits = raw_action[:, :self.n_tasks]
        mode_logits = raw_action[:, self.n_tasks:self.n_tasks + self.n_modes]
        binding_logits = raw_action[:, self.n_tasks + self.n_modes:]

        task_action = self._masked_one_hot(
            task_logits, tensors["task_mask"],
            forward_temperature=self.projection_temperature,
            straight_through=straight_through,
            surrogate_temperature=self.actor_backward_temperature if straight_through else None,
        )
        task_selector = task_action.detach()
        selected_beta = torch.bmm(task_selector.unsqueeze(1), tensors["beta_by_task"]).squeeze(1)
        selected_mode_mask = torch.bmm(task_selector.unsqueeze(1), tensors["mode_mask_by_task"]).squeeze(1)
        mode_action = self._masked_one_hot(
            mode_logits + self.guidance_strength * selected_beta,
            selected_mode_mask,
            forward_temperature=self.projection_temperature,
            straight_through=straight_through,
            surrogate_temperature=self.actor_backward_temperature if straight_through else None,
        )

        mode_selector = mode_action.detach()
        selected_binding_mask = torch.bmm(mode_selector.unsqueeze(1), tensors["binding_mask_by_mode"]).squeeze(1)
        selected_binding_bonus = torch.bmm(mode_selector.unsqueeze(1), tensors["binding_bonus_by_mode"]).squeeze(1)
        binding_action = self._masked_one_hot(
            binding_logits + selected_binding_bonus,
            selected_binding_mask,
            forward_temperature=self.projection_temperature,
            straight_through=straight_through,
            surrogate_temperature=self.actor_backward_temperature if straight_through else None,
        )
        projected = torch.cat([task_action, mode_action, binding_action], dim=-1)
        return projected.squeeze(0) if squeeze_output else projected

    def _active_constraints(self) -> Tuple[Set[str], Dict[str, float]]:
        violations = dict(getattr(self.planner, "last_constraint_violations", {}))
        active: Set[str] = set()
        for name in ("energy", "risk", "fatigue"):
            if name == "risk" and int(self.planner.params.get("use_ahd_reward", 1)) == 0:
                continue
            if float(violations.get(name, 0.0)) > 0.0:
                active.add(name)
        return active, {name: max(float(violations.get(name, 0.0)), 0.0) for name in active}

    def update(self) -> Dict[str, float]:
        self.update_calls += 1
        if self.update_calls % self.update_every != 0:
            return {"critic_loss": 0.0, "actor_loss": 0.0, "noise": self._noise()}
        if len(self.replay) < max(self.batch_size, self.warmup_steps):
            return {"critic_loss": 0.0, "actor_loss": 0.0, "noise": self._noise()}

        state, action, reward, deltas, next_state, done, context, next_context = self.replay.sample(self.batch_size)
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        a = torch.as_tensor(action, dtype=torch.float32, device=self.device)
        delta_t = torch.as_tensor(deltas, dtype=torch.float32, device=self.device)
        ns = torch.as_tensor(next_state, dtype=torch.float32, device=self.device)
        d = torch.as_tensor(done, dtype=torch.float32, device=self.device)

        immediate = {
            "performance": -delta_t[:, 0:1],
            "energy": delta_t[:, 1:2],
            "risk": delta_t[:, 2:3],
            "fatigue": delta_t[:, 3:4],
        }
        with torch.no_grad():
            next_logits = self.actor_target(ns)
            next_action = self.project_action(next_logits, next_context, straight_through=False)
            targets = {
                key: immediate[key] + (1.0 - d) * self.gamma * self.critic_targets[key](ns, next_action)
                for key in self.CRITIC_KEYS
            }

        losses: Dict[str, torch.Tensor] = {}
        for key in self.CRITIC_KEYS:
            q = self.critics[key](s, a)
            loss = nn.functional.mse_loss(q, targets[key])
            opt = self.critic_opts[key]
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.critics[key].parameters(), 5.0)
            opt.step()
            losses[key] = loss

        for critic in self.critics.values():
            for parameter in critic.parameters():
                parameter.requires_grad_(False)

        actor_raw = self.actor.raw_logits(s)
        actor_logits = self.actor.bound_logits(actor_raw)
        projected_action = self.project_action(actor_logits, context, straight_through=True)
        q_performance = self.critics["performance"](s, projected_action)
        q_energy = self.critics["energy"](s, projected_action)
        q_risk = self.critics["risk"](s, projected_action)
        q_fatigue = self.critics["fatigue"](s, projected_action)

        lambda_energy = float(self.planner.params.get("lambda_energy", 0.0))
        lambda_risk = float(self.planner.params.get("lambda_risk", 0.0)) if int(self.planner.params.get("use_ahd_reward", 1)) != 0 else 0.0
        lambda_fatigue = float(self.planner.params.get("lambda_fatigue", 0.0))
        actor_utility = q_performance - lambda_energy * q_energy - lambda_risk * q_risk - lambda_fatigue * q_fatigue
        actor_loss = -actor_utility.mean()

        actor_params = tuple(param for param in self.actor.parameters() if param.requires_grad)
        component_losses = {
            "performance": -q_performance.mean(),
            "energy": q_energy.mean(),
            "risk": q_risk.mean(),
            "fatigue": q_fatigue.mean(),
        }
        component_param_grads: Dict[str, torch.Tensor] = {}
        for name in self.CRITIC_KEYS:
            grads = torch.autograd.grad(
                component_losses[name], actor_params,
                retain_graph=True, create_graph=False, allow_unused=True,
            )
            component_param_grads[name] = _flatten_grad_list(grads, actor_params).detach()

        if int(self.planner.params.get("adaptive_lagrange", 1)) == 0:
            # Fixed-penalty ablation: optimize the frozen scalarized objective
            # directly.  This intentionally differs from V16's feasibility-first
            # common-descent coordination used by the Full model.
            final_param_grad = (
                component_param_grads["performance"]
                + lambda_energy * component_param_grads["energy"]
                + lambda_risk * component_param_grads["risk"]
                + lambda_fatigue * component_param_grads["fatigue"]
            )
            vcd_diag = {
                "vcd_num_active_constraints": 0.0,
                "vcd_common_descent_feasible": 1.0,
                "vcd_fallback_used": 0.0,
                "vcd_parameter_space": 0.0,
                "feasibility_restoration_active": 0.0,
                "fixed_penalty_gradient": 1.0,
            }
        else:
            active_constraints, violations = self._active_constraints()
            constraint_param_grads = {name: component_param_grads[name] for name in active_constraints}
            final_param_grad, vcd_diag = _parameter_space_common_descent(
                constraint_param_grads,
                active_constraints,
                violations,
                component_param_grads["performance"],
                severity_power=self.vcd_severity_power,
                min_relative_strength=self.vcd_min_relative_strength,
                performance_secondary_ratio=self.vcd_performance_secondary_ratio,
                severe_violation_threshold=self.vcd_severe_violation_threshold,
            )
            vcd_diag["feasibility_restoration_active"] = float(bool(active_constraints))
            vcd_diag["fixed_penalty_gradient"] = 0.0

        self.actor_opt.zero_grad(set_to_none=True)
        _assign_flat_grad(actor_params, final_param_grad)
        nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)
        self.actor_opt.step()

        for critic in self.critics.values():
            for parameter in critic.parameters():
                parameter.requires_grad_(True)

        self._soft_update(self.actor, self.actor_target)
        for key in self.CRITIC_KEYS:
            self._soft_update(self.critics[key], self.critic_targets[key])
        self.learn_steps += 1

        mean_critic_loss = torch.stack([losses[key] for key in self.CRITIC_KEYS]).mean()
        return {
            "critic_loss": float(mean_critic_loss.item()),
            "critic_performance_loss": float(losses["performance"].item()),
            "critic_energy_loss": float(losses["energy"].item()),
            "critic_risk_loss": float(losses["risk"].item()),
            "critic_fatigue_loss": float(losses["fatigue"].item()),
            "actor_loss": float(actor_loss.item()),
            "actor_q_performance": float(q_performance.detach().mean().item()),
            "actor_q_energy": float(q_energy.detach().mean().item()),
            "actor_q_risk": float(q_risk.detach().mean().item()),
            "actor_q_fatigue": float(q_fatigue.detach().mean().item()),
            "projection_temperature": float(self.projection_temperature),
            "actor_backward_temperature": float(self.actor_backward_temperature),
            "noise": float(self._noise()),
            **vcd_diag,
        }

    def _soft_update(self, src: nn.Module, dst: nn.Module) -> None:
        for p, tp in zip(src.parameters(), dst.parameters()):
            tp.data.copy_(self.tau * p.data + (1.0 - self.tau) * tp.data)


@torch.no_grad()
def evaluate_policy(planner: DBNCDDPGPlanner, agent: DDPGAgent) -> Tuple[dict, List[ScheduledItem], List[Dict[str, object]]]:
    env = planner.make_env()
    state = env.reset()
    done = False
    while not done:
        action = agent.act(state, explore=False)
        state, _, done, _ = env.step(action)
    planner.last_eval_task_type_trace = list(env.task_type_trace)
    planner.last_eval_dynamic_ahd_trace = list(env.dynamic_ahd_trace)
    planner.last_eval_final_task_types = dict(env.current_task_types)
    return env.metrics(), env.schedule, env.dbn_trace


def train_dbn_cddpg(planner: DBNCDDPGPlanner, episodes: int, seed: int, device: str) -> Tuple[dict, List[ScheduledItem], List[Dict[str, object]], List[Dict[str, float]]]:
    seed_everything(seed)
    env = planner.make_env()
    state_dim = env.state_dim
    action_dim = len(planner.topo_order) + len(MODES) + planner.binding_dim
    agent = DDPGAgent(state_dim, action_dim, planner, device=device)
    history: List[Dict[str, float]] = []
    best_score = float("inf")
    best_metrics: Optional[dict] = None
    best_schedule: Optional[List[ScheduledItem]] = None
    best_dbn_trace: Optional[List[Dict[str, object]]] = None
    for ep in range(1, episodes + 1):
        env = planner.make_env()
        state = env.reset()
        done = False
        last_losses = {"critic_loss": 0.0, "actor_loss": 0.0}
        while not done:
            projection_context = env.projection_context()
            action_vec = agent.act(state, explore=True)
            next_state, reward, done, info = env.step(
                action_vec,
                projection_context=projection_context,
            )
            executed = info["executed_action_vector"]
            next_projection_context = env.projection_context()
            agent.replay.push(
                state,
                executed,
                reward,
                next_state,
                done,
                projection_context,
                next_projection_context,
                transition_deltas=info["transition_deltas"],
            )
            last_losses = agent.update()
            state = next_state
        metrics = env.metrics()
        planner.update_constraint_lambdas(metrics)
        score = metrics["makespan"] + planner.params["lambda_energy"] * metrics["energy"] + planner.params["lambda_risk"] * metrics["risk"] + planner.params["lambda_fatigue"] * metrics["fatigue"] + planner.params["lambda_prep"] * metrics["prep_time"]
        history.append({
            "episode": float(ep),
            "makespan": float(metrics["makespan"]),
            "energy": float(metrics["energy"]),
            "risk": float(metrics["risk"]),
            "fatigue": float(metrics["fatigue"]),
            "prep_time": float(metrics["prep_time"]),
            "lambda_energy": float(planner.params["lambda_energy"]),
            "lambda_risk": float(planner.params["lambda_risk"]),
            "lambda_fatigue": float(planner.params["lambda_fatigue"]),
            "lambda_prep": float(planner.params["lambda_prep"]),
            "critic_loss": float(last_losses["critic_loss"]),
            "actor_loss": float(last_losses["actor_loss"]),
            "episode_score": float(score),
        })
        if ep % 10 == 0 or ep == episodes:
            eval_metrics, eval_schedule, eval_dbn_trace = evaluate_policy(planner, agent)
            eval_score = eval_metrics["makespan"] + planner.params["lambda_energy"] * eval_metrics["energy"] + planner.params["lambda_risk"] * eval_metrics["risk"] + planner.params["lambda_fatigue"] * eval_metrics["fatigue"] + planner.params["lambda_prep"] * eval_metrics["prep_time"]
            if eval_score < best_score:
                best_score = eval_score
                best_metrics = eval_metrics
                best_schedule = eval_schedule
                best_dbn_trace = eval_dbn_trace
                planner.best_task_type_trace = list(getattr(planner, "last_eval_task_type_trace", []))
                planner.best_dynamic_ahd_trace = list(getattr(planner, "last_eval_dynamic_ahd_trace", []))
                planner.best_final_task_types = dict(getattr(planner, "last_eval_final_task_types", {}))
    assert best_metrics is not None and best_schedule is not None and best_dbn_trace is not None
    return best_metrics, best_schedule, best_dbn_trace, history


def save_outputs(output_dir: Path, planner: DBNCDDPGPlanner, metrics: dict, schedule: List[ScheduledItem], dbn_trace: List[Dict[str, object]], train_history: List[Dict[str, float]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "task_diagnostics.json").write_text(json.dumps(planner.task_diagnostics(), ensure_ascii=False, indent=2), encoding="utf-8")
    if schedule:
        rows = [
            {
                "task_id": s.task_id,
                "task_name": s.task_name,
                "task_type": s.task_type,
                "mode": s.mode,
                "binding": s.binding,
                "start": round(s.start, 4),
                "end": round(s.end, 4),
                "delta_time": round(s.delta_time, 4),
                "delta_energy": round(s.delta_energy, 4),
                "delta_risk": round(s.delta_risk, 4),
                "delta_fatigue": round(s.delta_fatigue, 4),
            }
            for s in schedule
        ]
        with (output_dir / "schedule.csv").open("w", encoding="utf-8") as f:
            headers = list(rows[0].keys())
            f.write(",".join(headers) + "\n")
            for row in rows:
                f.write(",".join(_safe_csv(row[h]) for h in headers) + "\n")
    if dbn_trace:
        headers = list(dbn_trace[0].keys())
        with (output_dir / "dbn_trace.csv").open("w", encoding="utf-8") as f:
            f.write(",".join(headers) + "\n")
            for row in dbn_trace:
                f.write(",".join(_safe_csv(row[h]) for h in headers) + "\n")
        # Compact dynamic-AHD trace for direct backtesting / Fig. 5 diagnostics.
        ahd_headers = [h for h in ("step", "task_id", "base_ahd", "dynamic_ahd", "legal_modes") if h in headers]
        if ahd_headers:
            with (output_dir / "dynamic_ahd_trace.csv").open("w", encoding="utf-8") as f:
                f.write(",".join(ahd_headers) + "\n")
                for row in dbn_trace:
                    f.write(",".join(_safe_csv(row.get(h, "")) for h in ahd_headers) + "\n")
    type_trace = list(getattr(planner, "best_task_type_trace", []))
    if type_trace:
        headers = list(type_trace[0].keys())
        with (output_dir / "task_type_transition_trace.csv").open("w", encoding="utf-8") as f:
            f.write(",".join(headers) + "\n")
            for row in type_trace:
                f.write(",".join(_safe_csv(row.get(h, "")) for h in headers) + "\n")
    ahd_trace = list(getattr(planner, "best_dynamic_ahd_trace", []))
    if ahd_trace:
        headers = list(ahd_trace[0].keys())
        with (output_dir / "dynamic_ahd_event_trace.csv").open("w", encoding="utf-8") as f:
            f.write(",".join(headers) + "\n")
            for row in ahd_trace:
                f.write(",".join(_safe_csv(row.get(h, "")) for h in headers) + "\n")
    final_types = dict(getattr(planner, "best_final_task_types", {}))
    if final_types:
        (output_dir / "final_task_types.json").write_text(
            json.dumps({str(k): v for k, v in final_types.items()}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if train_history:
        headers = list(train_history[0].keys())
        with (output_dir / "train_history.csv").open("w", encoding="utf-8") as f:
            f.write(",".join(headers) + "\n")
            for row in train_history:
                f.write(",".join(_safe_csv(row[h]) for h in headers) + "\n")


def _safe_csv(v: object) -> str:
    s = "" if v is None else str(v)
    if any(ch in s for ch in [",", "\n", '"']):
        s = '"' + s.replace('"', '""') + '"'
    return s


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="DBN-CDDPG 主代码（动态AHD + 事件级I/III/IV重分类 + 硬投影）")
    p.add_argument("--input", required=True, help="输入 Excel/JSON 文件")
    p.add_argument("--scenario_id", default=None, help="可选场景 ID")
    p.add_argument("--episodes", type=int, default=120, help="训练轮数")
    p.add_argument("--seed", type=int, default=42, help="随机种子")
    p.add_argument("--device", default="cpu", help="cpu 或 cuda")
    p.add_argument("--output_dir", default="outputs_dbn_cddpg", help="输出目录")
    return p


def main() -> None:
    args = build_parser().parse_args()
    input_path = Path(args.input)
    data = load_input_payload(input_path, scenario_id=args.scenario_id)
    planner = DBNCDDPGPlanner(data)
    metrics, schedule, dbn_trace, train_history = train_dbn_cddpg(planner, episodes=args.episodes, seed=args.seed, device=args.device)
    save_outputs(Path(args.output_dir), planner, metrics, schedule, dbn_trace, train_history)
    print("\n=== DBN-CDDPG 训练完成 ===")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print(f"输出目录: {Path(args.output_dir).resolve()}")


if __name__ == "__main__":
    main()
