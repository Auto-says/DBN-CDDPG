from __future__ import annotations

import copy
import csv
import hashlib
import importlib.util
import json
import math
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
except Exception as exc:  # pragma: no cover
    raise RuntimeError("This experiment package requires PyTorch.") from exc


FORMAL_SEEDS = [42, 52, 62, 72, 82, 92, 102, 112, 122, 132]
FORMAL_BUDGETS = {"energy": 15.7, "risk": 85.0, "fatigue": 6.0}


def load_solver(path: Path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    name = f"dynamic_ahd_solver_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import solver: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    required = [
        "DBNCDDPGPlanner", "DBNCDDPGEnv", "DDPGAgent", "ReplayBuffer",
        "HierarchicalActor", "Critic", "JointDecodedAction", "MODES", "MODE_INDEX",
        "load_input_payload", "seed_everything",
    ]
    missing = [x for x in required if not hasattr(module, x)]
    if missing:
        raise RuntimeError(f"Solver API missing: {missing}")
    return module


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_seeds(text: str) -> List[int]:
    seeds = [int(x.strip()) for x in str(text).split(",") if x.strip()]
    if not seeds:
        raise ValueError("At least one seed is required")
    if len(set(seeds)) != len(seeds):
        raise ValueError("Seeds must be unique")
    return seeds


def deep_payload_with_params(base_data: Mapping[str, Any], overrides: Mapping[str, Any]) -> Dict[str, Any]:
    data = copy.deepcopy(dict(base_data))
    params = data.setdefault("params", {})
    params.update(overrides)
    return data


def force_formal_budgets(data: Dict[str, Any], budgets: Mapping[str, float] = FORMAL_BUDGETS) -> Dict[str, Any]:
    data = copy.deepcopy(data)
    p = data.setdefault("params", {})
    p["budget_energy"] = float(budgets["energy"])
    p["budget_risk"] = float(budgets["risk"])
    p["budget_fatigue"] = float(budgets["fatigue"])
    p.setdefault("reward_time_scale", 430.0)
    p["gamma"] = 1.0
    return data


def budget_diagnostics(metrics: Mapping[str, Any], budgets: Mapping[str, float] = FORMAL_BUDGETS) -> Dict[str, float]:
    e = float(metrics.get("energy", math.inf))
    r = float(metrics.get("risk", math.inf))
    f = float(metrics.get("fatigue", math.inf))
    ve = max((e - float(budgets["energy"])) / max(float(budgets["energy"]), 1e-12), 0.0)
    vr = max((r - float(budgets["risk"])) / max(float(budgets["risk"]), 1e-12), 0.0)
    vf = max((f - float(budgets["fatigue"])) / max(float(budgets["fatigue"]), 1e-12), 0.0)
    return {
        "energy_violation": ve,
        "risk_violation": vr,
        "fatigue_violation": vf,
        "nvs": ve + vr + vf,
        "budget_feasible": float(ve <= 1e-12 and vr <= 1e-12 and vf <= 1e-12),
    }


def checkpoint_key(metrics: Mapping[str, Any], budgets: Mapping[str, float] = FORMAL_BUDGETS, *, complete: bool = True):
    d = budget_diagnostics(metrics, budgets)
    makespan = float(metrics.get("makespan", math.inf))
    if not complete:
        return (2, math.inf, makespan)
    if d["budget_feasible"] > 0.5:
        return (0, makespan, d["nvs"])
    return (1, d["nvs"], makespan)


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for k in row.keys():
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def json_dump(path: Path, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def mean_sd(values: Iterable[float]) -> Tuple[float, float, int]:
    vals = np.asarray([float(v) for v in values if v is not None and np.isfinite(float(v))], dtype=float)
    if vals.size == 0:
        return math.nan, math.nan, 0
    return float(vals.mean()), float(vals.std(ddof=1)) if vals.size > 1 else 0.0, int(vals.size)


def set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.set_flush_denormal(True)
    except Exception:
        pass


@dataclass(frozen=True)
class JointActionSpec:
    task_id: int
    mode: str
    binding_index: int
    human_id: Optional[str] = None
    robot_id: Optional[str] = None


def enumerate_joint_actions(planner) -> List[JointActionSpec]:
    actions: List[JointActionSpec] = []
    # candidate_bindings itself is state-independent w.r.t. the identities/counts.
    env = planner.make_env()
    for tid in planner.topo_order:
        for mode in planner.MODES if hasattr(planner, "MODES") else ("H", "R", "HRC"):
            try:
                candidates = env.candidate_bindings(tid, mode)
            except Exception:
                continue
            for c in candidates:
                actions.append(JointActionSpec(
                    task_id=int(tid), mode=str(mode), binding_index=int(c.binding_index),
                    human_id=getattr(c, "human_id", None), robot_id=getattr(c, "robot_id", None),
                ))
    return actions


def build_joint_actions(planner, modes=("H", "R", "HRC")) -> List[JointActionSpec]:
    env = planner.make_env()
    out: List[JointActionSpec] = []
    for tid in planner.topo_order:
        for mode in modes:
            for c in env.candidate_bindings(tid, mode):
                out.append(JointActionSpec(
                    task_id=int(tid), mode=str(mode), binding_index=int(c.binding_index),
                    human_id=getattr(c, "human_id", None), robot_id=getattr(c, "robot_id", None),
                ))
    return out


def action_vector_from_spec(env, spec: JointActionSpec) -> np.ndarray:
    n_tasks = env.n_tasks
    n_modes = len(env.p.dbn.transition) if False else 3
    vec = np.zeros(n_tasks + n_modes + env.binding_dim, dtype=np.float32)
    pos = env.p.tid_to_pos[spec.task_id]
    vec[pos] = 1.0
    vec[n_tasks + env.p.MODE_INDEX[spec.mode] if hasattr(env.p, "MODE_INDEX") else n_tasks + {"H":0,"R":1,"HRC":2}[spec.mode]] = 1.0
    vec[n_tasks + n_modes + int(spec.binding_index)] = 1.0
    return vec


def encode_action_vector(env, spec: JointActionSpec) -> np.ndarray:
    n_tasks = env.n_tasks
    n_modes = 3
    vec = np.zeros(n_tasks + n_modes + env.binding_dim, dtype=np.float32)
    vec[env.p.tid_to_pos[spec.task_id]] = 1.0
    vec[n_tasks + {"H": 0, "R": 1, "HRC": 2}[spec.mode]] = 1.0
    vec[n_tasks + n_modes + int(spec.binding_index)] = 1.0
    return vec


def valid_joint_mask(env, actions: Sequence[JointActionSpec], *, structural_only: bool = False) -> np.ndarray:
    ready = set(env.ready_tasks())
    mask = np.zeros(len(actions), dtype=np.float32)
    for i, a in enumerate(actions):
        if a.task_id not in ready:
            continue
        if structural_only:
            current_type = env.current_task_types.get(a.task_id, env.p.initial_task_types[a.task_id])
            modes = env.p._legal_modes_for_task(env.p.tasks[a.task_id], task_type=current_type)
        else:
            modes = env.feasible_modes(a.task_id)
        if a.mode not in modes:
            continue
        if a.mode == "H" and not (0 <= a.binding_index < len(env.p.humans)):
            continue
        if a.mode == "R" and not (0 <= a.binding_index < len(env.p.robots)):
            continue
        if a.mode == "HRC" and not (0 <= a.binding_index < len(env.p.humans) * len(env.p.robots)):
            continue
        mask[i] = 1.0
    return mask


def spec_from_hierarchical_preferences(env, prefs: np.ndarray, *, structural_only: bool = False) -> JointActionSpec:
    arr = np.asarray(prefs, dtype=np.float32).reshape(-1)
    n_tasks = env.n_tasks
    n_modes = 3
    ready = set(env.ready_tasks())
    task_scores = arr[:n_tasks].copy()
    for pos, tid in enumerate(env.p.topo_order):
        if tid not in ready:
            task_scores[pos] = -1e9
    task_pos = int(np.argmax(task_scores))
    tid = env.p.topo_order[task_pos]
    current_type = env.current_task_types.get(tid, env.p.initial_task_types[tid])
    modes = env.p._legal_modes_for_task(env.p.tasks[tid], task_type=current_type) if structural_only else env.feasible_modes(tid)
    mode_scores = arr[n_tasks:n_tasks+n_modes].copy()
    beta = env.beta_map.get(tid, np.zeros(3, dtype=np.float32))
    if int(env.params.get("use_dbn_mode_bias", 1)) != 0 and int(env.params.get("use_posterior_mapping", 1)) != 0:
        mode_scores = mode_scores + float(env.params.get("dbn_guidance_strength", 0.35)) * beta
    legal_set = set(modes)
    for mi, mode in enumerate(("H","R","HRC")):
        if mode not in legal_set:
            mode_scores[mi] = -1e9
    mode_idx = int(np.argmax(mode_scores))
    mode = ("H","R","HRC")[mode_idx]
    bind_scores = arr[n_tasks+n_modes:].copy()
    candidates = env.candidate_bindings(tid, mode)
    valid_bind = {int(c.binding_index): c for c in candidates}
    for bi in range(env.binding_dim):
        if bi not in valid_bind:
            bind_scores[bi] = -1e9
        else:
            # mirror the environment availability bonus
            bind_scores[bi] += float(env._candidate_binding_availability_bonus(valid_bind[bi]))
    bi = int(np.argmax(bind_scores))
    c = valid_bind[bi]
    return JointActionSpec(tid, mode, bi, getattr(c, "human_id", None), getattr(c, "robot_id", None))


def same_spec(a: JointActionSpec, b: JointActionSpec) -> bool:
    return (a.task_id, a.mode, a.binding_index) == (b.task_id, b.mode, b.binding_index)


class ScalarReplay:
    def __init__(self, capacity: int = 50000):
        from collections import deque
        self.buf = deque(maxlen=int(capacity))

    def push(self, s, a, r, ns, d, next_mask):
        self.buf.append((np.asarray(s, np.float32), int(a), float(r), np.asarray(ns, np.float32), float(d), np.asarray(next_mask, np.float32)))

    def sample(self, batch: int):
        idx = np.random.choice(len(self.buf), int(batch), replace=False)
        vals = [self.buf[i] for i in idx]
        s,a,r,ns,d,nm = zip(*vals)
        return np.stack(s), np.asarray(a), np.asarray(r,np.float32)[:,None], np.stack(ns), np.asarray(d,np.float32)[:,None], np.stack(nm)

    def __len__(self):
        return len(self.buf)


class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, action_dim),
        )

    def forward(self, x):
        return self.net(x)


class DDQNPolicy:
    def __init__(self, state_dim: int, actions: Sequence[JointActionSpec], *, device: str, lr=3e-4,
                 gamma=1.0, batch_size=64, replay_size=50000, warmup=128,
                 epsilon_start=0.95, epsilon_end=0.05, epsilon_decay_steps=30000,
                 target_update=250, dbn_guidance_strength=0.0):
        self.device = torch.device(device)
        self.actions = list(actions)
        self.q = QNet(state_dim, len(actions)).to(self.device)
        self.target = QNet(state_dim, len(actions)).to(self.device)
        self.target.load_state_dict(self.q.state_dict())
        self.opt = optim.Adam(self.q.parameters(), lr=float(lr))
        self.gamma=float(gamma); self.batch_size=int(batch_size); self.warmup=int(warmup)
        self.replay=ScalarReplay(replay_size)
        self.eps0=float(epsilon_start); self.eps1=float(epsilon_end); self.eps_steps=max(1,int(epsilon_decay_steps))
        self.target_update=max(1,int(target_update)); self.steps=0; self.dbn_guidance_strength=float(dbn_guidance_strength)

    def epsilon(self):
        f=min(1.0,self.steps/self.eps_steps); return self.eps0+f*(self.eps1-self.eps0)

    def _guidance(self, env) -> np.ndarray:
        if self.dbn_guidance_strength == 0.0:
            return np.zeros(len(self.actions), dtype=np.float32)
        g=np.zeros(len(self.actions), dtype=np.float32)
        for i,a in enumerate(self.actions):
            beta=env.beta_map.get(a.task_id)
            if beta is not None:
                g[i]=self.dbn_guidance_strength*float(beta[{"H":0,"R":1,"HRC":2}[a.mode]])
        return g

    @torch.no_grad()
    def scores(self, state: np.ndarray, env=None) -> np.ndarray:
        s=torch.as_tensor(state,dtype=torch.float32,device=self.device).unsqueeze(0)
        q=self.q(s).squeeze(0).cpu().numpy()
        if env is not None: q=q+self._guidance(env)
        return q.astype(np.float32)

    def choose(self, state, mask, env, explore=True):
        self.steps += int(bool(explore))
        valid=np.flatnonzero(mask>0.5)
        if valid.size==0: raise RuntimeError("DDQN received an empty action mask")
        if explore and np.random.rand()<self.epsilon():
            return int(np.random.choice(valid))
        sc=self.scores(state,env)
        return int(valid[np.argmax(sc[valid])])

    def observe(self,s,a,r,ns,d,next_mask):
        self.replay.push(s,a,r,ns,d,next_mask)
        if len(self.replay)<max(self.batch_size,self.warmup): return 0.0
        s,a,r,ns,d,nm=self.replay.sample(self.batch_size)
        st=torch.as_tensor(s,dtype=torch.float32,device=self.device)
        at=torch.as_tensor(a,dtype=torch.long,device=self.device)[:,None]
        rt=torch.as_tensor(r,dtype=torch.float32,device=self.device)
        nst=torch.as_tensor(ns,dtype=torch.float32,device=self.device)
        dt=torch.as_tensor(d,dtype=torch.float32,device=self.device)
        nmt=torch.as_tensor(nm,dtype=torch.float32,device=self.device)
        q=self.q(st).gather(1,at)
        with torch.no_grad():
            online=self.q(nst).masked_fill(nmt<0.5,-1e9)
            best=online.argmax(1,keepdim=True)
            target_q=self.target(nst).gather(1,best)
            has=(nmt>0.5).any(1,keepdim=True).float()
            y=rt+(1.0-dt)*self.gamma*target_q*has
        loss=nn.functional.smooth_l1_loss(q,y)
        self.opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(self.q.parameters(),5.0); self.opt.step()
        if self.steps%self.target_update==0: self.target.load_state_dict(self.q.state_dict())
        return float(loss.item())

    def snapshot(self): return {k:v.detach().cpu().clone() for k,v in self.q.state_dict().items()}
    def restore(self,snap): self.q.load_state_dict(snap); self.target.load_state_dict(snap)


class PPOPolicy(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=128):
        super().__init__()
        self.body=nn.Sequential(nn.Linear(state_dim,hidden),nn.ReLU(),nn.Linear(hidden,hidden),nn.ReLU())
        self.pi=nn.Linear(hidden,action_dim); self.v=nn.Linear(hidden,1)
    def forward(self,s):
        h=self.body(s); return self.pi(h),self.v(h)


class PPOLagrangianPolicy:
    def __init__(self,state_dim,actions,*,device,lr=3e-4,gamma=1.0,gae_lambda=0.95,clip_ratio=0.2,
                 entropy_coef=0.01,value_coef=0.5,ppo_epochs=6):
        self.device=torch.device(device); self.actions=list(actions); self.gamma=float(gamma); self.gae=float(gae_lambda)
        self.clip=float(clip_ratio); self.entropy=float(entropy_coef); self.value_coef=float(value_coef); self.epochs=int(ppo_epochs)
        self.net=PPOPolicy(state_dim,len(actions)).to(self.device); self.opt=optim.Adam(self.net.parameters(),lr=float(lr))
        self.roll=[]

    def _dist_value(self,state,mask):
        s=torch.as_tensor(state,dtype=torch.float32,device=self.device).unsqueeze(0)
        logits,v=self.net(s); m=torch.as_tensor(mask,dtype=torch.bool,device=self.device).unsqueeze(0)
        logits=logits.masked_fill(~m,-1e9); dist=torch.distributions.Categorical(logits=logits)
        return dist,v.squeeze(0).squeeze(-1)

    @torch.no_grad()
    def scores(self,state,env=None):
        s=torch.as_tensor(state,dtype=torch.float32,device=self.device).unsqueeze(0); logits,_=self.net(s)
        return logits.squeeze(0).cpu().numpy().astype(np.float32)

    def choose(self,state,mask,env,explore=True):
        dist,v=self._dist_value(state,mask)
        if explore: a=dist.sample().squeeze(0)
        else: a=torch.argmax(dist.logits,dim=-1).squeeze(0)
        lp=dist.log_prob(a.unsqueeze(0)).squeeze(0)
        return int(a.item()),float(lp.item()),float(v.item())

    def observe(self,state,mask,action,reward,done,logp,value):
        self.roll.append((np.asarray(state,np.float32),np.asarray(mask,np.float32),int(action),float(reward),float(done),float(logp),float(value)))

    def finish_episode(self):
        if not self.roll: return 0.0
        rewards=np.asarray([x[3] for x in self.roll],float); dones=np.asarray([x[4] for x in self.roll],float); values=np.asarray([x[6] for x in self.roll],float)
        adv=np.zeros_like(rewards); last=0.0
        for t in range(len(rewards)-1,-1,-1):
            nv=0.0 if t==len(rewards)-1 else values[t+1]
            delta=rewards[t]+self.gamma*nv*(1.0-dones[t])-values[t]
            last=delta+self.gamma*self.gae*(1.0-dones[t])*last; adv[t]=last
        ret=adv+values
        if len(adv)>1: adv=(adv-adv.mean())/(adv.std()+1e-8)
        states=torch.as_tensor(np.stack([x[0] for x in self.roll]),dtype=torch.float32,device=self.device)
        masks=torch.as_tensor(np.stack([x[1] for x in self.roll]),dtype=torch.bool,device=self.device)
        acts=torch.as_tensor([x[2] for x in self.roll],dtype=torch.long,device=self.device)
        oldlp=torch.as_tensor([x[5] for x in self.roll],dtype=torch.float32,device=self.device)
        advt=torch.as_tensor(adv,dtype=torch.float32,device=self.device); rett=torch.as_tensor(ret,dtype=torch.float32,device=self.device)
        last_loss=0.0
        for _ in range(self.epochs):
            logits,v=self.net(states); logits=logits.masked_fill(~masks,-1e9); dist=torch.distributions.Categorical(logits=logits)
            lp=dist.log_prob(acts); ratio=torch.exp(lp-oldlp); s1=ratio*advt; s2=torch.clamp(ratio,1-self.clip,1+self.clip)*advt
            pi_loss=-torch.min(s1,s2).mean(); v_loss=nn.functional.mse_loss(v.squeeze(-1),rett); ent=dist.entropy().mean()
            loss=pi_loss+self.value_coef*v_loss-self.entropy*ent
            self.opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(self.net.parameters(),5.0); self.opt.step(); last_loss=float(loss.item())
        self.roll.clear(); return last_loss

    def snapshot(self): return {k:v.detach().cpu().clone() for k,v in self.net.state_dict().items()}
    def restore(self,snap): self.net.load_state_dict(snap)


class StressEnvMixin:
    """Adds persistent event shocks on top of the uploaded dynamic-AHD environment."""
    stress_events: Sequence[Mapping[str, float]] = ()

    def reset(self):
        self._external_ahd_multiplier = 1.0
        self._external_risk_multiplier = 1.0
        self._stress_applied = set()
        self._first_stress_schedule_index = None
        return super().reset()

    def _refresh_dynamic_ahd(self):
        super()._refresh_dynamic_ahd()
        if int(self.params.get("use_dynamic_ahd", 1)) == 0:
            return
        mult=float(getattr(self,"_external_ahd_multiplier",1.0))
        if abs(mult-1.0)<1e-12: return
        cap=float(self.params.get("dynamic_stress_ahd_cap",625.0))
        for tid in self.p.topo_order:
            if self.completed[self.p.tid_to_pos[tid]]>0.5 or tid in self.p.type2_task_ids: continue
            self.dynamic_ahd_scores[tid]=float(min(cap,max(0.0,self.dynamic_ahd_scores.get(tid,0.0)*mult)))

    def _human_risk_delta(self, task, action, duration, base_exposure):
        val=super()._human_risk_delta(task,action,duration,base_exposure)
        return float(val)*float(getattr(self,"_external_risk_multiplier",1.0))

    def _apply_due_stress(self):
        completed=len(self.schedule)
        changed=False
        for idx,event in enumerate(self.stress_events):
            trigger=int(event.get("completed_tasks",-1))
            if idx in self._stress_applied or completed<trigger: continue
            self._stress_applied.add(idx); changed=True
            if self._first_stress_schedule_index is None: self._first_stress_schedule_index=completed
            self._external_ahd_multiplier *= float(event.get("ahd_multiplier",1.0))
            self._external_risk_multiplier *= float(event.get("risk_multiplier",1.0))
            shock=float(event.get("fatigue_shock",0.0))
            if shock:
                for hid in self.human_fatigue: self.human_fatigue[hid]+=shock
            delay=float(event.get("robot_delay",0.0))
            if delay:
                for rid in self.robot_available: self.robot_available[rid]+=delay
        if changed:
            self._refresh_dynamic_ahd(); self._refresh_task_types(); self._refresh_beliefs()

    def step(self,*args,**kwargs):
        out=super().step(*args,**kwargs)
        self._apply_due_stress()
        # State returned by the base step was generated before the external shock;
        # replace it by the post-shock state to keep the Markov observation aligned.
        state,reward,done,info=out
        return self.get_state(),reward,done,info


def make_stress_env_class(solver, events: Sequence[Mapping[str,float]]):
    class StressEnv(StressEnvMixin, solver.DBNCDDPGEnv):
        stress_events=tuple(dict(e) for e in events)
    return StressEnv


def make_planner_class(solver, env_cls, *, allow_dual_update: bool = True):
    class Planner(solver.DBNCDDPGPlanner):
        def make_env(self): return env_cls(self)
        def update_constraint_lambdas(self, metrics: dict) -> None:
            if not allow_dual_update: return
            return super().update_constraint_lambdas(metrics)
    return Planner
