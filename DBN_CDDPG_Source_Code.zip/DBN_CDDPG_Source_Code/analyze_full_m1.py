#!/usr/bin/env python3
"""Recompute Appendix Table C6 and the explicit-guidance diagnostic from matched Full/M1 evaluation outputs."""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, t

METRICS = [
    ("Cmax / s", "makespan"),
    ("Full-run AHD", "ahd_total"),
    ("Fatigue", "fatigue"),
    ("Energy", "energy"),
]
SCENARIOS = ("HE-1", "HE-4")


def exact_signed_rank_p(values: np.ndarray):
    # Manuscript convention: round exported engineering outcomes to 4 decimals before ranking.
    d = np.round(np.asarray(values, dtype=float), 4)
    d = d[d != 0.0]
    n = len(d)
    if n == 0:
        return 1.0, 0
    ranks = rankdata(np.abs(d), method="average")
    w_plus = float(ranks[d > 0].sum())
    total = float(ranks.sum())
    observed = min(w_plus, total - w_plus)
    extreme = 0
    for mask in range(1 << n):
        w = sum(float(ranks[i]) for i in range(n) if (mask >> i) & 1)
        if min(w, total - w) <= observed + 1e-12:
            extreme += 1
    return extreme / float(1 << n), n


def holm_adjust(pvals):
    p = np.asarray(pvals, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adjusted = np.empty(m, dtype=float)
    running = 0.0
    for k, idx in enumerate(order):
        candidate = (m - k) * p[idx]
        running = max(running, candidate)
        adjusted[idx] = min(1.0, running)
    return adjusted


def ci_mean(d):
    d = np.asarray(d, dtype=float)
    n = len(d)
    mean = float(d.mean())
    if n < 2:
        return mean, float('nan'), float('nan')
    sd = float(d.std(ddof=1))
    half = float(t.ppf(0.975, n - 1) * sd / math.sqrt(n))
    return mean, mean - half, mean + half


def read_runs(eval_dir: Path):
    p = eval_dir / 'evaluation_runs.csv'
    if not p.is_file():
        raise FileNotFoundError(p)
    df = pd.read_csv(p)
    required = {'variant','seed','scenario','makespan','ahd_total','fatigue','energy'}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f'Missing columns in evaluation_runs.csv: {sorted(missing)}')
    return df


def build_table_c6(df):
    long_rows, pvals = [], []
    for label, col in METRICS:
        for scenario in SCENARIOS:
            a = df[(df.variant == 'full') & (df.scenario == scenario)].sort_values('seed')
            b = df[(df.variant == 'm1_no_dbn') & (df.scenario == scenario)].sort_values('seed')
            if list(a.seed) != list(b.seed) or len(a) != 10:
                raise ValueError(f'Expected ten matched Full/M1 seeds for {scenario}/{label}')
            diff = a[col].to_numpy(float) - b[col].to_numpy(float)
            mean, lo, hi = ci_mean(diff)
            raw_p, nonzero = exact_signed_rank_p(diff)
            row = dict(metric=label, scenario=scenario, delta_mean=mean, ci95_low=lo, ci95_high=hi,
                       nonzero_pairs=nonzero, total_pairs=len(diff), raw_p=raw_p)
            long_rows.append(row); pvals.append(raw_p)
    adjusted = holm_adjust(pvals)
    for row, padj in zip(long_rows, adjusted): row['p_holm'] = float(padj)
    long = pd.DataFrame(long_rows)
    # Manuscript-style wide table.
    wide_rows=[]
    for label,_ in METRICS:
        a=long[(long.metric==label)&(long.scenario=='HE-1')].iloc[0]
        b=long[(long.metric==label)&(long.scenario=='HE-4')].iloc[0]
        wide_rows.append({
            'Metric':label,
            'Delta Mean HE-1':round(a.delta_mean,3), 'Delta Mean HE-4':round(b.delta_mean,3),
            '95% CI HE-1':f'[{a.ci95_low:.3f}, {a.ci95_high:.3f}]',
            '95% CI HE-4':f'[{b.ci95_low:.3f}, {b.ci95_high:.3f}]',
            'Nonzero pairs HE-1':f'{int(a.nonzero_pairs)}/{int(a.total_pairs)}',
            'Nonzero pairs HE-4':f'{int(b.nonzero_pairs)}/{int(b.total_pairs)}',
            'Raw p HE-1':f'{a.raw_p:.4f}', 'Raw p HE-4':f'{b.raw_p:.4f}',
            'pHolm HE-1':f'{a.p_holm:.4f}', 'pHolm HE-4':f'{b.p_holm:.4f}',
        })
    return long, pd.DataFrame(wide_rows)


def collect_events(eval_dir: Path):
    files = sorted(eval_dir.glob('run_details/*/seed_*/*/event_decisions.csv'))
    if not files:
        raise FileNotFoundError('No run_details/*/seed_*/*/event_decisions.csv files found')
    frames=[]
    for p in files:
        df=pd.read_csv(p)
        if len(df): frames.append(df)
    return pd.concat(frames, ignore_index=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--eval-dir', type=Path, default=Path('outputs_full_m1_HE1_HE4'))
    p.add_argument('--output-dir', type=Path, default=None)
    args=p.parse_args()
    eval_dir=args.eval_dir.resolve()
    out=(args.output_dir or (eval_dir/'analysis')).resolve(); out.mkdir(parents=True, exist_ok=True)
    runs=read_runs(eval_dir)
    long, wide=build_table_c6(runs)
    long.to_csv(out/'table_c6_long.csv', index=False)
    wide.to_csv(out/'table_c6_manuscript_wide.csv', index=False, encoding='utf-8-sig')
    events=collect_events(eval_dir)
    full=events[events.variant=='full'].copy()
    opp=(full.groupby('scenario', as_index=False)[['multiple_legal_TypeIII_opportunity','explicit_guidance_changes_action']].sum())
    opp.to_csv(out/'explicit_guidance_opportunity_summary.csv', index=False)
    changes=full[full.explicit_guidance_changes_action==1].copy()
    changes.to_csv(out/'table17_explicit_guidance_changes.csv', index=False, encoding='utf-8-sig')
    disturbed=opp[opp.scenario.isin(['HE-1','HE-4'])]
    d_opp=int(disturbed.multiple_legal_TypeIII_opportunity.sum()); d_flip=int(disturbed.explicit_guidance_changes_action.sum())
    manifest={
        'paired_tests':8,
        'holm_family':'2 disturbances x 4 engineering outcomes',
        'min_p_holm':float(long.p_holm.min()),
        'all_p_holm_ge_0_75':bool((long.p_holm>=0.75-1e-12).all()),
        'disturbed_full_multimode_typeIII_opportunities':d_opp,
        'disturbed_explicit_guidance_action_changes':d_flip,
        'disturbed_explicit_guidance_change_rate_pct':100*d_flip/d_opp if d_opp else None,
        'scope':'Same-state explicit-guidance decoding is local; no downstream counterfactual trajectory is estimated.'
    }
    (out/'analysis_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps(manifest, indent=2))

if __name__=='__main__': main()
