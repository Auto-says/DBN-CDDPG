"""Verify the bundled source/input hashes and run a tiny device forward/backward test."""
from pathlib import Path
import argparse
import json
from full_m1_support import ROOT, common, torch, configure_runtime

p = argparse.ArgumentParser()
p.add_argument('--device', default='cuda')
args = p.parse_args()
expected = json.loads((ROOT / 'UPSTREAM_SHA256.json').read_text())
for name, digest in expected.items():
    if common.sha256(ROOT / name) != digest:
        raise RuntimeError('Source/input hash mismatch: ' + name)
runtime = configure_runtime(args.device, 1, False)
a = torch.randn(16, 16, device=args.device, requires_grad=True)
loss = (a @ a.T).square().mean()
loss.backward()
if not torch.isfinite(loss).item() or not torch.isfinite(a.grad).all().item():
    raise RuntimeError('Device forward/backward test failed')
print(json.dumps({'passed': True, 'upstream_hashes_match': True, 'runtime': runtime}, ensure_ascii=False, indent=2))
