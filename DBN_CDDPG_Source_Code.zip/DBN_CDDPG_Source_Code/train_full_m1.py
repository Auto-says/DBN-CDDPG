#!/usr/bin/env python3
"""Train only Full/M1 using the uploaded Table-8 algorithm; save actual model weights.

The nominal episode loop, agent, reward/costs, feasibility checks, and checkpoint
selection are retained from upstream/run_table8_formal.py. Added code handles
provenance, model persistence, episode-boundary resume, and reload verification.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

from full_m1_support import (
    ROOT, SOLVER_PATH, DEFAULT_WORKBOOK, VERSION, VARIANTS, ENGINEERING_KEYS,
    ablation, common, np, torch, atomic_json, atomic_torch, digest, plain,
    source_hashes, configure_runtime, load_checkpoint, make_actor_checkpoint,
    pack_training_state, restore_training_state, restore_actor, parse_variants, save_traces,
)


def arguments():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--workbook", type=Path, default=DEFAULT_WORKBOOK)
    p.add_argument("--output-dir", "--output_dir", type=Path, default=Path("outputs_full_m1_10000"))
    p.add_argument("--variants", default="full,m1_no_dbn")
    p.add_argument("--seeds", default=",".join(map(str, common.FORMAL_SEEDS)))
    p.add_argument("--episodes", type=int, default=10000)
    p.add_argument("--eval-interval", "--eval_interval", type=int, default=50)
    p.add_argument("--save-every", type=int, default=500, help="Save full training state every N completed episodes")
    p.add_argument("--device", default="cuda")
    p.add_argument("--threads", type=int, default=1, help="PyTorch intra-op threads; 0 keeps the runtime default")
    p.add_argument("--deterministic", type=int, choices=(0, 1), default=0,
                   help="0: original seeded/non-strict protocol; 1: strict deterministic algorithms, a separately recorded protocol")
    p.add_argument("--resume", action="store_true", help="Resume a saved episode boundary; skip verified completed jobs")
    p.add_argument("--keep-resume-state", action="store_true", help="Keep large replay/optimizer checkpoint after a job finishes")
    p.add_argument("--recover-lock", action="store_true", help="Remove a stale suite lock ONLY after confirming no other writer is running")
    p.add_argument("--stop-after", type=int, default=None,
                   help="Testing only: stop at this absolute episode while retaining --episodes as the planned horizon")
    p.add_argument("--dry-run", action="store_true")
    return p.parse_args()


@contextmanager
def suite_lock(out: Path, recover: bool):
    lock = out / ".training.lock"
    if recover and lock.exists():
        print("[warning] Removing lock by explicit --recover-lock request; ensure no other writer is running.", flush=True)
        lock.unlink()
    try:
        fd = os.open(str(lock), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        raise RuntimeError(f"{lock} exists. Do not train two writers into one output directory. "
                           "After a crashed process, verify it is stopped, then add --recover-lock.") from exc
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "started": time.time(), "command": sys.argv}, f)
        yield
    finally:
        lock.unlink(missing_ok=True)


def refresh_summary(out: Path, protocol_id: str):
    rows = []
    for path in sorted((out / "runs").glob("*/seed_*/completed.json")):
        row = json.loads(path.read_text(encoding="utf-8"))
        if row["protocol_id"] != protocol_id:
            raise ValueError(f"Mixed protocols in {path}")
        rows.append(row)
    common.write_csv(out / "training_runs.csv", rows)
    if rows:
        frame = ablation.pd.DataFrame(rows)
        ablation.summarize(frame, VARIANTS).to_csv(out / "nominal_summary.csv", index=False, encoding="utf-8-sig")


def train_one(solver, base, variant, seed, args, protocol):
    directory = args.output_dir / "runs" / variant / f"seed_{seed}"
    directory.mkdir(parents=True, exist_ok=True)
    actor_path = directory / "best_actor.pt"
    resume_path = directory / "resume_state.pt"
    completed_path = directory / "completed.json"
    if completed_path.exists():
        if not args.resume:
            raise FileExistsError(f"Completed job exists: {completed_path}; use --resume or a new output directory")
        row = json.loads(completed_path.read_text(encoding="utf-8"))
        if row["protocol_id"] != protocol["protocol_id"] or not actor_path.exists():
            raise ValueError("Completed marker is not accompanied by a matching model checkpoint")
        saved = load_checkpoint(actor_path)
        if saved["protocol_id"] != row["protocol_id"] or common.sha256(actor_path) != row["actor_sha256"]:
            raise ValueError(f"Model provenance/hash mismatch: {actor_path}")
        print(f"[skip verified] {variant} seed={seed} selected_ep={row['best_checkpoint_episode']}", flush=True)
        return True

    common.set_all_seeds(seed)
    planner = ablation.make_planner(solver, base, variant)
    planner.params["_total_training_steps"] = int(args.episodes * len(planner.topo_order))
    probe = planner.make_env()
    agent = solver.DDPGAgent(probe.state_dim, len(planner.topo_order) + 3 + planner.binding_dim,
                             planner, device=args.device)
    atomic_json(directory / "configuration.json", {
        "protocol_id": protocol["protocol_id"], "variant": variant, "seed": seed,
        "resolved_initial_params": planner.params, "state_dim": probe.state_dim,
        "action_dim": agent.action_dim, "topo_order": planner.topo_order,
    })
    start_ep, prior_runtime = 0, 0.0
    best = None
    best_key = (9, math.inf, math.inf)
    history = []
    if args.resume and resume_path.exists():
        state = load_checkpoint(resume_path)
        if state["protocol_id"] != protocol["protocol_id"] or state["variant"] != variant or state["seed"] != seed:
            raise ValueError(f"Resume identity mismatch: {resume_path}")
        restore_training_state(agent, planner, state["training"])
        start_ep = int(state["episode"])
        history = state["history"]
        best = state["best_actor"]
        best_key = tuple(best["selection_key"]) if best is not None else best_key
        prior_runtime = float(state["runtime_s"])
        # A crash can leave a newer best_actor.pt than the last full resume boundary.
        # Revert to the best snapshot saved WITH that boundary, not a future one.
        if best is not None:
            atomic_torch(actor_path, best)
        else:
            actor_path.unlink(missing_ok=True)
        del state
        print(f"[resume] {variant} seed={seed} from completed episode {start_ep}", flush=True)
    elif args.resume and actor_path.exists():
        print(f"[restart from seed] {variant} seed={seed}: no full resume state; best actor alone is not enough for continuation.", flush=True)

    t0 = time.perf_counter()
    finish_ep = args.episodes if args.stop_after is None else min(args.episodes, args.stop_after)
    if finish_ep < start_ep:
        raise ValueError("--stop-after cannot precede the saved episode")

    def save_boundary(ep):
        print(f"[save resume] {variant} seed={seed} episode={ep} replay={len(agent.replay)}", flush=True)
        atomic_torch(resume_path, {
            "format_version": VERSION, "kind": "episode_boundary_training_resume",
            "protocol_id": protocol["protocol_id"], "variant": variant, "seed": seed,
            "episode": ep, "history": history, "best_actor": best,
            "runtime_s": prior_runtime + time.perf_counter() - t0,
            "training": pack_training_state(agent, planner),
        })
        atomic_json(directory / "progress.json", {
            "protocol_id": protocol["protocol_id"], "completed_training_episodes": ep,
            "planned_training_episodes": args.episodes,
            "selected_episode_so_far": best["selected_episode"] if best else None,
            "training_finished": False,
        })

    for ep in range(start_ep + 1, finish_ep + 1):
        # Intentionally preserves the upstream train_variant episode/update order.
        env = planner.make_env()
        state = env.reset()
        done = False
        last = {"critic_loss": 0.0, "actor_loss": 0.0}
        while not done:
            ctx = env.projection_context()
            action = agent.act(state, explore=True)
            ns, reward, done, info = env.step(action, projection_context=ctx)
            nctx = env.projection_context()
            agent.replay.push(state, info["executed_action_vector"], reward, ns, done, ctx, nctx,
                              transition_deltas=info.get("transition_deltas", np.zeros(4, np.float32)))
            last = agent.update()
            state = ns
        tm = env.metrics()
        if int(tm.get("is_complete", 0)) == 1:
            planner.update_constraint_lambdas(tm)
        if ep % args.eval_interval == 0 or ep == args.episodes:
            em, _ = ablation.eval_agent(planner, agent)
            key = ablation.selection_key(em)
            record = {"episode": ep, **{k: em[k] for k in (
                "is_complete", "completed_tasks", "makespan", "risk", "energy", "fatigue",
                "nvs", "budget_feasible", "invalid_proposal_rate", "projection_intervention_rate")},
                **{k: float(planner.params.get(k, 0)) for k in ("lambda_energy", "lambda_risk", "lambda_fatigue")},
                "critic_loss": float(last.get("critic_loss", 0)), "actor_loss": float(last.get("actor_loss", 0))}
            history.append(record)
            if key < best_key:
                best_key = key
                best = make_actor_checkpoint(agent, planner, protocol, variant, seed, ep, em)
                atomic_torch(actor_path, best)
                atomic_json(directory / "best_actor_metadata.json", {k: v for k, v in best.items() if k != "actor_state_dict"})
            common.write_csv(directory / "training_history.csv", history)
            print(f"[{variant} seed={seed}] ep={ep}/{args.episodes} Cmax={em['makespan']:.4f} "
                  f"AHD={em['risk']:.4f} F={em['fatigue']:.4f} E={em['energy']:.4f} "
                  f"NVS={em['nvs']:.5f} best_ep={best['selected_episode']}", flush=True)
        if ep % args.save_every == 0 or ep == finish_ep:
            save_boundary(ep)

    if finish_ep < args.episodes:
        print(f"[stopped for test] {variant} seed={seed} episode={finish_ep}; no completed marker", flush=True)
        return False
    if best is None:
        raise RuntimeError("No selected checkpoint was produced")
    runtime_s = prior_runtime + time.perf_counter() - t0
    # Actual DISK reload into a fresh policy/planner, not an in-memory-only check.
    saved = load_checkpoint(actor_path)
    restored_planner, policy = restore_actor(solver, base, saved, args.device)
    metrics, evaluated_env = ablation.eval_agent(restored_planner, policy)
    for key in ENGINEERING_KEYS:
        if metrics[key] != saved["selection_metrics"][key]:
            raise RuntimeError(f"Reload verification failed for {key}: {metrics[key]} != {saved['selection_metrics'][key]}")
    save_traces(directory / "nominal", evaluated_env)
    row = ablation.row_from_metrics(variant, seed, args.episodes, saved["selected_episode"], runtime_s, metrics)
    row.update({"runner_version": VERSION, "protocol_id": protocol["protocol_id"],
                "training_finished": True, "actor_sha256": common.sha256(actor_path),
                "actor_file": str(actor_path.relative_to(args.output_dir)).replace("\\", "/"),
                "reload_verified": True})
    atomic_json(directory / "reload_check.json", {
        "passed": True, "comparison": "same-device fresh policy/planner disk reload",
        "selected_episode": saved["selected_episode"], "keys": list(ENGINEERING_KEYS),
        "recorded": {k: saved["selection_metrics"][k] for k in ENGINEERING_KEYS},
        "reloaded": {k: metrics[k] for k in ENGINEERING_KEYS},
    })
    atomic_json(completed_path, row)
    atomic_json(directory / "progress.json", {"training_finished": True, "completed_training_episodes": args.episodes,
                                            "selected_episode": saved["selected_episode"]})
    if not args.keep_resume_state:
        resume_path.unlink(missing_ok=True)
    print(f"[complete + reload verified] {variant} seed={seed} -> {actor_path}", flush=True)
    return True


def main():
    args = arguments()
    if min(args.episodes, args.eval_interval, args.save_every) <= 0 or args.threads < 0:
        raise ValueError("Episodes/intervals must be positive and threads nonnegative")
    if args.stop_after is not None and args.stop_after <= 0:
        raise ValueError("--stop-after must be positive")
    variants = parse_variants(args.variants)
    seeds = common.parse_seeds(args.seeds)
    args.output_dir = args.output_dir.resolve()
    args.workbook = args.workbook.resolve()
    if not args.workbook.is_file():
        raise FileNotFoundError(args.workbook)
    runtime = configure_runtime(args.device, args.threads, bool(args.deterministic))
    solver = common.load_solver(SOLVER_PATH)
    base = common.force_formal_budgets(solver.load_input_payload(args.workbook, scenario_id=None))
    protocol = {
        "runner_version": VERSION, "episodes": args.episodes, "eval_interval": args.eval_interval,
        "source_hashes": source_hashes(), "workbook_sha256": common.sha256(args.workbook),
        "base_payload_sha256": digest(base), "budgets": common.FORMAL_BUDGETS,
        "training_environment": "nominal only; no HE-1/HE-4 during training or checkpoint selection",
        "checkpoint_selection": "upstream selection_key, strict <, earliest ties retained",
        "runtime": runtime,
    }
    protocol["protocol_id"] = digest(protocol)
    print(f"Plan: {len(variants)} configurations x {len(seeds)} seeds = {len(variants)*len(seeds)} trainings; "
          f"{args.episodes} episodes each. Device={args.device}. Output={args.output_dir}", flush=True)
    if args.dry_run:
        print(json.dumps({**protocol, "requested_variants": variants, "requested_seeds": seeds}, ensure_ascii=False, indent=2))
        return
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with suite_lock(args.output_dir, args.recover_lock):
        manifest = args.output_dir / "manifest.json"
        if manifest.exists():
            previous = json.loads(manifest.read_text(encoding="utf-8"))
            if previous["protocol_id"] != protocol["protocol_id"]:
                raise ValueError("Output directory contains a different protocol/runtime/source/input. "
                                 "Use a NEW output directory; do not mix protocols.")
            if not args.resume:
                raise FileExistsError("Output directory already initialized. Use --resume or a new directory.")
        else:
            atomic_json(manifest, protocol)
            atomic_json(args.output_dir / "resolved_input.json", base)
            try:
                freeze = subprocess.run([sys.executable, "-m", "pip", "freeze"], check=True,
                                        capture_output=True, text=True, timeout=30)
                (args.output_dir / "pip_freeze.txt").write_text(freeze.stdout, encoding="utf-8")
            except (subprocess.SubprocessError, OSError) as exc:
                (args.output_dir / "pip_freeze.txt").write_text(f"pip freeze unavailable: {exc}", encoding="utf-8")
        log = args.output_dir / "invocations.jsonl"
        with log.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"time": time.time(), "argv": sys.argv, "variants": variants,
                                "seeds": seeds, "save_every": args.save_every,
                                "stop_after": args.stop_after}, ensure_ascii=False) + "\n")
        finished = []
        for variant in variants:
            for seed in seeds:
                finished.append(train_one(solver, base, variant, seed, args, protocol))
                refresh_summary(args.output_dir, protocol["protocol_id"])
        print(f"Finished requested jobs: {sum(finished)}/{len(finished)}. "
              "Weights are in runs/<variant>/seed_<seed>/best_actor.pt", flush=True)


if __name__ == "__main__":
    main()
