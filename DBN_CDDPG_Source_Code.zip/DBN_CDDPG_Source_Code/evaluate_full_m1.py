#!/usr/bin/env python3
"""Reload selected Full/M1 actors and evaluate nominal, HE-1, HE-4 without learning.

Also logs explicit guidance-on/off decoding of the SAME actor output and hard
context. This is a local ranking diagnostic, NOT a separately trained M1 or a
counterfactual downstream-cost experiment.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
import time

from full_m1_support import (
    ROOT, SOLVER_PATH, VERSION, ENGINEERING_KEYS, ablation, common, np,
    atomic_json, configure_runtime, digest, load_checkpoint, plain,
    parse_variants, restore_actor, save_traces,
)
from run_table7_formal import SCENARIOS

SCENARIO_MAP = {"nominal": [], "HE-1": SCENARIOS["HE-1_AHD"], "HE-4": SCENARIOS["HE-4_combined"]}


def action_record(action):
    return {"task_id": int(action.task_id), "mode": action.mode,
            "binding_index": int(action.binding_index), "human_id": action.human_id, "robot_id": action.robot_id}


def check_legal(env, action):
    if action.task_id not in env.ready_tasks() or action.mode not in env.feasible_modes(action.task_id):
        raise RuntimeError("Decoded action is outside the current hard legal domain")
    candidates = env.candidate_bindings(action.task_id, action.mode)
    if action.binding_index not in {c.binding_index for c in candidates}:
        raise RuntimeError("Decoded executor binding is illegal")


def evaluate_one(solver, base, saved, device, scenario, directory):
    planner, policy = restore_actor(solver, base, saved, device)
    original_env = planner.make_env()
    Env = type("MatchedEvaluationEnv", (common.StressEnvMixin, type(original_env)),
               {"stress_events": copy.deepcopy(SCENARIO_MAP[scenario])})
    env = Env(planner)
    state = env.reset()
    rows, decisions = [], 0
    done = False
    while not done:
        context = env.projection_context()
        raw = policy.act(state, explore=False)
        on, _ = env.decode_action(raw, context=context)
        off_context = {k: v.copy() for k, v in context.items()}
        off_context["beta_by_task"][:] = 0.0
        off, _ = env.decode_action(raw, context=off_context)
        check_legal(env, on)
        check_legal(env, off)
        task_pos = planner.tid_to_pos[on.task_id]
        beta = context["beta_by_task"][task_pos]
        raw_modes = raw[env.n_tasks:env.n_tasks + 3]
        guide_enabled = (int(planner.params.get("use_dbn_mode_bias", 1)) != 0
                         and int(planner.params.get("use_posterior_mapping", 1)) != 0)
        strength = float(planner.params["dbn_guidance_strength"]) if guide_enabled else 0.0
        mode_set = env.feasible_modes(on.task_id)
        task_type = env.current_task_types[on.task_id]
        opportunity = task_type == "III" and len(mode_set) >= 2
        changed = action_record(on) != action_record(off)
        physical = {"completed": env.completed, "types": env.current_task_types,
                    "task_end": env.task_end, "human_available": env.human_available,
                    "robot_available": env.robot_available, "human_fatigue": env.human_fatigue,
                    "dynamic_ahd": env.dynamic_ahd_scores}
        before_risk = env.total_risk
        before_fatigue = env.total_fatigue
        before_energy = env.total_energy
        before_time = env.makespan
        record = {
            "seed": saved["seed"], "variant": saved["variant"], "scenario": scenario,
            "event_index": decisions, "completed_before": len(env.schedule),
            "state_hash": digest(state), "physical_state_hash": digest(physical),
            "external_ahd_multiplier": env._external_ahd_multiplier,
            "external_risk_multiplier": env._external_risk_multiplier,
            "task_type": task_type, "task_id": on.task_id,
            "task_ahd": env.dynamic_ahd_scores[on.task_id],
            "mean_human_fatigue": float(np.mean(list(env.human_fatigue.values()))),
            "legal_modes": "/".join(mode_set),
            "posterior_H": float(beta[0]), "posterior_R": float(beta[1]), "posterior_HRC": float(beta[2]),
            "mode_scores_raw": json.dumps(plain(raw_modes)),
            "mode_scores_guided": json.dumps(plain(raw_modes + strength * beta)),
            "action_guidance_on": json.dumps(action_record(on)),
            "action_guidance_off": json.dumps(action_record(off)),
            "multiple_legal_TypeIII_opportunity": int(opportunity),
            "explicit_guidance_changes_action": int(changed),
            "state_vector": json.dumps(plain(state)), "raw_actor_vector": json.dumps(plain(raw)),
            "projection_context": json.dumps(plain(context)),
        }
        state, _, done, _ = env.step(raw, projection_context=context)
        item = env.schedule[-1]
        if (item.task_id, item.mode, item.binding) != (on.task_id, on.mode, on.binding_str()):
            raise RuntimeError("Logged decoder action differs from actually executed action")
        record.update({"executed_mode": item.mode, "executed_binding": item.binding,
                       "delta_makespan": env.makespan - before_time,
                       "delta_ahd": env.total_risk - before_risk,
                       "delta_fatigue": env.total_fatigue - before_fatigue,
                       "delta_energy": env.total_energy - before_energy})
        rows.append(record)
        decisions += 1
        if decisions > 4 * env.n_tasks:
            raise RuntimeError("Unexpected nonterminating evaluation")
    metrics = env.metrics()
    metrics.update(common.budget_diagnostics(metrics))
    if scenario == "nominal":
        for key in ENGINEERING_KEYS:
            if metrics[key] != saved["selection_metrics"][key]:
                raise RuntimeError(f"Nominal checkpoint replay differs for {key}: {metrics[key]} vs "
                                   f"{saved['selection_metrics'][key]}. Use the training device/runtime and investigate.")
    complete = int(metrics["is_complete"]) == 1
    first = env._first_stress_schedule_index
    post_ahd = float(sum(x.delta_risk for x in env.schedule[first:])) if first is not None else None
    opportunities = sum(r["multiple_legal_TypeIII_opportunity"] for r in rows)
    flips = sum(r["explicit_guidance_changes_action"] for r in rows)
    result = {
        "variant": saved["variant"], "seed": saved["seed"], "scenario": scenario,
        "selected_episode": saved["selected_episode"], "planned_training_episodes": saved["planned_episodes"],
        "is_complete": int(complete), "completed_tasks": metrics["completed_tasks"],
        "makespan": metrics["makespan"] if complete else None,
        "ahd_total": metrics["risk"] if complete else None,
        "ahd_post_first_event": post_ahd if complete else None,
        "energy": metrics["energy"] if complete else None,
        "fatigue": metrics["fatigue"] if complete else None,
        "nvs": metrics["nvs"] if complete else None,
        "budget_feasible": int(complete and metrics["budget_feasible"] > 0.5),
        "first_stress_after_completed_tasks": first,
        "TypeIII_multiple_mode_opportunities": opportunities,
        "explicit_guidance_action_flips": flips,
        "explicit_guidance_flip_rate_pct": 100.0 * flips / opportunities if opportunities else None,
        "use_dbn_state": planner.params["use_dbn_state"],
        "use_dynamic_ahd": planner.params["use_dynamic_ahd"],
        "use_event_retyping": planner.params["use_event_retyping"],
        "dbn_guidance_strength": planner.params["dbn_guidance_strength"],
    }
    save_traces(directory, env)
    common.write_csv(directory / "event_decisions.csv", rows)
    atomic_json(directory / "result.json", result)
    atomic_json(directory / "metrics_raw.json", metrics)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--train-dir", type=Path, default=Path("outputs_full_m1_10000"))
    p.add_argument("--output-dir", type=Path, default=Path("outputs_full_m1_HE1_HE4"))
    p.add_argument("--variants", default="full,m1_no_dbn")
    p.add_argument("--seeds", default=",".join(map(str, common.FORMAL_SEEDS)))
    p.add_argument("--scenarios", default="nominal,HE-1,HE-4")
    p.add_argument("--device", default="cuda")
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--deterministic", type=int, choices=(0, 1), default=0)
    args = p.parse_args()
    variants = parse_variants(args.variants)
    seeds = common.parse_seeds(args.seeds)
    scenarios = [x.strip() for x in args.scenarios.split(",") if x.strip()]
    if not scenarios or len(set(scenarios)) != len(scenarios) or any(s not in SCENARIO_MAP for s in scenarios):
        raise ValueError("Supported scenarios: nominal,HE-1,HE-4")
    train = args.train_dir.resolve()
    out = args.output_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("Evaluation directory is not empty. Use a new output directory to avoid overwriting results.")
    manifest = json.loads((train / "manifest.json").read_text(encoding="utf-8"))
    base = json.loads((train / "resolved_input.json").read_text(encoding="utf-8"))
    runtime = configure_runtime(args.device, args.threads, bool(args.deterministic))
    solver = common.load_solver(SOLVER_PATH)
    jobs = []
    for variant in variants:
        for seed in seeds:
            d = train / "runs" / variant / f"seed_{seed}"
            complete = json.loads((d / "completed.json").read_text(encoding="utf-8"))
            path = d / "best_actor.pt"
            if common.sha256(path) != complete["actor_sha256"]:
                raise ValueError(f"Actor hash mismatch: {path}")
            saved = load_checkpoint(path)
            if (saved["protocol_id"] != manifest["protocol_id"] or saved["variant"] != variant
                    or saved["seed"] != seed or not complete["training_finished"]):
                raise ValueError(f"Incomplete or mismatched training job: {d}")
            jobs.append((variant, seed, saved))
    out.mkdir(parents=True, exist_ok=True)
    atomic_json(out / "evaluation_manifest.json", {
        "format_version": VERSION, "training_protocol_id": manifest["protocol_id"],
        "runtime": runtime, "scenarios": {s: SCENARIO_MAP[s] for s in scenarios},
        "variants": variants, "seeds": seeds, "training": False, "checkpoint_reselection": False,
        "evaluator_sha256": common.sha256(Path(__file__)),
        "scope": "Trajectory comparison + same-state explicit-guidance decoding diagnostic; no downstream branch causal effect is estimated",
    })
    results = []
    for variant, seed, saved in jobs:
        for scenario in scenarios:
            common.set_all_seeds(seed)
            row = evaluate_one(solver, base, saved, args.device, scenario,
                               out / "run_details" / variant / f"seed_{seed}" / scenario)
            results.append(row)
            common.write_csv(out / "evaluation_runs.csv", results)
            print(f"[eval] {variant} seed={seed} {scenario}: Cmax={row['makespan']} "
                  f"AHD={row['ahd_total']} ABFR={row['budget_feasible']}", flush=True)
    summary = []
    for variant in variants:
        for scenario in scenarios:
            rows = [r for r in results if r["variant"] == variant and r["scenario"] == scenario]
            entry = {"variant": variant, "scenario": scenario, "n_seeds": len(rows),
                     "completion_pct": 100 * sum(r["is_complete"] for r in rows) / len(rows),
                     "ABFR_pct": 100 * sum(r["budget_feasible"] for r in rows) / len(rows)}
            for metric in ("makespan", "ahd_total", "ahd_post_first_event", "fatigue", "energy", "nvs"):
                mean, sd, count = common.mean_sd(r[metric] for r in rows)
                entry.update({metric + "_mean": mean, metric + "_sd": sd, metric + "_n": count})
            summary.append(entry)
    common.write_csv(out / "evaluation_summary.csv", summary)
    print(f"Evaluation completed: {len(results)} trajectories. Outputs: {out}", flush=True)


if __name__ == "__main__":
    main()
