from __future__ import annotations

import argparse
import copy
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import numpy as np
import pandas as pd
import torch

import run_table7_formal as base
from experiment_common import StressEnvMixin

RUNNER_VERSION = "acceptance-static-vs-event-he1-he4-v1.0"
SEEDS = [42, 52, 62, 72, 82, 92, 102, 112, 122, 132]

SCENARIOS = {
    "HE-1_AHD": [
        {"completed_tasks": 7, "ahd_multiplier": 1.35, "risk_multiplier": 1.10},
    ],
    "HE-4_combined": [
        {"completed_tasks": 7, "ahd_multiplier": 1.45, "risk_multiplier": 1.25,
         "fatigue_shock": 0.80, "robot_delay": 20.0},
        {"completed_tasks": 14, "ahd_multiplier": 1.20, "risk_multiplier": 1.20,
         "fatigue_shock": 0.60, "robot_delay": 10.0},
    ],
}


class _EventCounterMixin:
    """Count post-reset update calls without changing solver behavior."""
    def reset(self):
        self._count_updates = False
        self.physical_ahd_update_epochs = 0
        self.event_evidence_update_count = 0
        self.dbn_update_epoch_count = 0
        self.online_retyping_count = 0
        out = super().reset()
        self.initial_retyping_count = int(sum(
            1 for x in getattr(self, "task_type_trace", [])
            if int(x.get("step", -1)) == 0 and x.get("old_type") != x.get("new_type")
        ))
        self._count_updates = True
        return out

    def _refresh_dynamic_ahd(self):
        if getattr(self, "_count_updates", False):
            self.physical_ahd_update_epochs += 1
        return super()._refresh_dynamic_ahd()

    def _refresh_task_types(self):
        before = len(getattr(self, "task_type_trace", []))
        if getattr(self, "_count_updates", False):
            self.event_evidence_update_count += 1
        out = super()._refresh_task_types()
        if getattr(self, "_count_updates", False):
            after = getattr(self, "task_type_trace", [])[before:]
            self.online_retyping_count += int(sum(
                1 for x in after
                if int(x.get("step", 0)) > 0 and x.get("old_type") != x.get("new_type")
            ))
        return out

    def _refresh_beliefs(self):
        if getattr(self, "_count_updates", False):
            self.dbn_update_epoch_count += 1
        return super()._refresh_beliefs()


class _StaticEvidenceFreezeMixin:
    """Static control used for the disturbance comparison.

    Initial t0 consistency correction and initial DBN posterior are computed once.
    Afterwards, physical dynamic-AHD evolution and hard feasibility remain active,
    but event-wise task retyping and DBN posterior refresh are frozen.

    This is deliberately a *guidance-layer* static control, not an unsafe control:
    both Static and Event-driven keep the same hard feasible-domain projection.
    """
    def reset(self):
        self._freeze_event_guidance = False
        out = super().reset()
        self._freeze_event_guidance = True
        # Counters after t0 must be zero for the static guidance condition.
        self.event_evidence_update_count = 0
        self.dbn_update_epoch_count = 0
        self.online_retyping_count = 0
        return out

    def _refresh_task_types(self):
        if getattr(self, "_freeze_event_guidance", False):
            return None
        return super()._refresh_task_types()

    def _refresh_beliefs(self):
        if getattr(self, "_freeze_event_guidance", False):
            return None
        return super()._refresh_beliefs()


def make_event_env_class(solver, events: Sequence[Mapping[str, float]] | None = None):
    if events is None:
        class EventEnv(_EventCounterMixin, solver.DBNCDDPGEnv):
            pass
    else:
        class EventEnv(_EventCounterMixin, StressEnvMixin, solver.DBNCDDPGEnv):
            stress_events = tuple(dict(e) for e in events)
    return EventEnv


def make_static_env_class(solver, events: Sequence[Mapping[str, float]] | None = None):
    if events is None:
        class StaticEnv(_StaticEvidenceFreezeMixin, _EventCounterMixin, solver.DBNCDDPGEnv):
            pass
    else:
        class StaticEnv(_StaticEvidenceFreezeMixin, _EventCounterMixin, StressEnvMixin, solver.DBNCDDPGEnv):
            stress_events = tuple(dict(e) for e in events)
    return StaticEnv


def make_variant_planner(solver, base_data, variant: str, *, stress_events=None):
    if variant not in {"Static", "Event-driven"}:
        raise ValueError(variant)
    overrides = dict(base.BASE_PARAMS)
    overrides.update(base.METHOD_PARAMS["dbn_cddpg"])
    payload = base.force_formal_budgets(base.deep_payload_with_params(base_data, overrides))
    env_cls = (make_static_env_class if variant == "Static" else make_event_env_class)(solver, stress_events)
    Planner = base.make_planner_class(solver, env_cls, allow_dual_update=True)
    return Planner(payload)


def _clone_ddpg(solver, planner, policy):
    probe = planner.make_env()
    clone = solver.DDPGAgent(
        probe.state_dim,
        len(planner.topo_order) + 3 + planner.binding_dim,
        planner,
        device=str(policy.device),
    )
    base._ddpg_restore(clone, base._ddpg_snapshot(policy))
    return clone


def _counter_row(env):
    return {
        "Physical_AHD_update_epochs": int(getattr(env, "physical_ahd_update_epochs", 0)),
        "Initial_retyping_count": int(getattr(env, "initial_retyping_count", 0)),
        "Event_evidence_update_count": int(getattr(env, "event_evidence_update_count", 0)),
        "Online_retyping_count": int(getattr(env, "online_retyping_count", 0)),
        "DBN_update_epoch_count": int(getattr(env, "dbn_update_epoch_count", 0)),
    }


def evaluate_disturbances(solver, base_data, variant, policy, actions, seed, nominal_makespan):
    rows = []
    for scenario, events in SCENARIOS.items():
        planner = make_variant_planner(solver, base_data, variant, stress_events=events)
        clone = _clone_ddpg(solver, planner, policy)
        metrics, safety, env = base.evaluate_policy(
            solver, planner, "dbn_cddpg", clone, actions, stress=True
        )
        rows.append({
            "Runner": RUNNER_VERSION,
            "Mode": variant,
            "Seed": int(seed),
            "Scenario": scenario,
            "Completion": float(safety["completion_rate"]),
            "UAPR_unsafe": int(safety["uapr_unsafe"]),
            "UAPR_total": int(safety["uapr_total"]),
            "SMSR_success": int(safety["smsr_success"]),
            "SMSR_total": int(safety["smsr_total"]),
            "SCMR_success": int(safety["scmr_success"]),
            "SCMR_total": int(safety["scmr_total"]),
            "Post_event_AHD": float(safety["post_event_risk"]),
            "Cmax": float(metrics["makespan"]),
            "Energy": float(metrics["energy"]),
            "AHD": float(metrics["risk"]),
            "Fatigue": float(metrics["fatigue"]),
            "NVS": float(metrics["nvs"]),
            "Feasible": float(metrics["budget_feasible"]),
            "Delta_Cmax_pct": 100.0 * (float(metrics["makespan"]) - float(nominal_makespan)) / max(float(nominal_makespan), 1e-12),
            **_counter_row(env),
        })
    return rows


def add_rates(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for label, num, den in [
        ("UAPR_pct", "UAPR_unsafe", "UAPR_total"),
        ("SMSR_pct", "SMSR_success", "SMSR_total"),
        ("SCMR_pct", "SCMR_success", "SCMR_total"),
    ]:
        n = pd.to_numeric(df[num], errors="coerce").to_numpy(dtype=float)
        d = pd.to_numeric(df[den], errors="coerce").to_numpy(dtype=float)
        df[label] = np.where(d > 0, 100.0 * n / d, np.nan)
    df["Dynamic_ABFR_pct"] = 100.0 * pd.to_numeric(df["Feasible"], errors="coerce")
    df["Completion_pct"] = 100.0 * pd.to_numeric(df["Completion"], errors="coerce")
    return df


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    df = add_rates(df)
    metrics = [
        "Completion_pct", "UAPR_pct", "SMSR_pct", "SCMR_pct",
        "Post_event_AHD", "Delta_Cmax_pct", "Dynamic_ABFR_pct", "NVS",
        "Cmax", "AHD", "Energy", "Fatigue",
        "Physical_AHD_update_epochs", "Event_evidence_update_count",
        "DBN_update_epoch_count", "Online_retyping_count",
    ]
    rows = []
    for (mode, scenario), g in df.groupby(["Mode", "Scenario"]):
        row = {"Mode": mode, "Scenario": scenario, "n_seeds": int(g.Seed.nunique())}
        for m in metrics:
            x = pd.to_numeric(g[m], errors="coerce").dropna().to_numpy(dtype=float)
            row[f"{m}_mean"] = float(x.mean()) if len(x) else math.nan
            row[f"{m}_sd"] = float(x.std(ddof=1)) if len(x) > 1 else (0.0 if len(x) == 1 else math.nan)
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["Scenario", "Mode"])


def paired_deltas(df: pd.DataFrame) -> pd.DataFrame:
    df = add_rates(df)
    metrics = [
        "Post_event_AHD", "Delta_Cmax_pct", "Dynamic_ABFR_pct", "NVS",
        "Cmax", "AHD", "Energy", "Fatigue", "UAPR_pct", "SMSR_pct", "SCMR_pct",
    ]
    rows = []
    for scenario, g in df.groupby("Scenario"):
        s = g[g.Mode == "Static"].set_index("Seed")
        e = g[g.Mode == "Event-driven"].set_index("Seed")
        common = sorted(set(s.index).intersection(e.index))
        for seed in common:
            row = {"Scenario": scenario, "Seed": int(seed)}
            for m in metrics:
                sv, ev = float(s.loc[seed, m]), float(e.loc[seed, m])
                row[f"Static_{m}"] = sv
                row[f"Event_{m}"] = ev
                row[f"Event_minus_Static_{m}"] = ev - sv if np.isfinite(sv) and np.isfinite(ev) else math.nan
            rows.append(row)
    return pd.DataFrame(rows)


def parse_seed_list(text: str):
    vals = [int(x.strip()) for x in text.split(",") if x.strip()]
    if not vals:
        raise ValueError("No seeds supplied")
    return vals


def main():
    ap = argparse.ArgumentParser(description="Static vs event-driven DBN-CDDPG under HE-1/HE-4.")
    ap.add_argument("--workbook", default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    ap.add_argument("--solver_module", default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    ap.add_argument("--episodes", type=int, default=10000)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--eval_interval", type=int, default=50)
    ap.add_argument("--output_dir", default="outputs_acceptance_static_vs_event_HE1_HE4")
    ap.add_argument("--save_run_details", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    workbook = (root / args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    solver_path = (root / args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module)
    out = (root / args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    seeds = parse_seed_list(args.seeds)
    episodes = int(args.episodes)
    eval_interval = int(args.eval_interval)
    if args.smoke:
        seeds = [seeds[0]]
        episodes = 2
        eval_interval = 1

    manifest = {
        "runner_version": RUNNER_VERSION,
        "workbook": str(workbook),
        "solver_module": str(solver_path),
        "seeds": seeds,
        "episodes": episodes,
        "eval_interval": eval_interval,
        "device": args.device,
        "scenarios": SCENARIOS,
        "variants": {
            "Event-driven": "Full DBN-CDDPG; physical AHD, event task retyping and DBN posterior refresh remain active after every event.",
            "Static": "Same DBN-CDDPG/hard projection; t0 consistency correction and initial posterior are retained, but event-wise task retyping and DBN posterior refresh are frozen after reset. Physical dynamic AHD and the hard feasible domain remain active.",
        },
        "critical_fairness_rule": "The static control freezes guidance-layer event updates; it does NOT disable hard feasibility/safety projection.",
    }

    if args.dry_run:
        if not workbook.exists():
            raise FileNotFoundError(workbook)
        if not solver_path.exists():
            raise FileNotFoundError(solver_path)
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return

    solver = base.load_solver(solver_path)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Use --device cpu for smoke test.")
    base_data = base.force_formal_budgets(solver.load_input_payload(workbook, scenario_id=None))

    out.mkdir(parents=True, exist_ok=True)
    base.json_dump(out / "experiment_manifest.json", manifest)
    ckdir = out / "completed_seed_checkpoints"
    ckdir.mkdir(exist_ok=True)

    rows = []
    nominal_rows = []
    original_make_planner = base.make_planner
    try:
        for variant in ["Static", "Event-driven"]:
            # train_one() and all its checkpoint evaluations will use exactly this variant planner.
            base.make_planner = lambda solver_, data_, method_, stress_events=None, _v=variant: make_variant_planner(
                solver_, data_, _v, stress_events=stress_events
            )
            for seed in seeds:
                ck = ckdir / f"{variant.replace('-', '_')}_seed{seed}_ep{episodes}.json"
                if args.resume and ck.exists():
                    obj = json.loads(ck.read_text(encoding="utf-8"))
                    nominal_rows.append(obj["nominal"])
                    rows.extend(obj["dynamic"])
                    print(f"[resume] {variant} seed={seed}", flush=True)
                    continue

                print(f"[Static/Event] {variant} seed={seed} episodes={episodes}", flush=True)
                t0 = time.perf_counter()
                planner, policy, actions, metrics, safety, best_ep = base.train_one(
                    solver, base_data, "dbn_cddpg", int(seed), episodes, args.device,
                    eval_interval, args.save_run_details, out / "run_details" / variant
                )
                runtime = time.perf_counter() - t0

                # One fresh nominal evaluation for update counters.
                nmetrics, nsafety, nenv = base.evaluate_policy(
                    solver, planner, "dbn_cddpg", policy, actions, stress=False
                )
                nominal = {
                    "Runner": RUNNER_VERSION, "Mode": variant, "Seed": int(seed),
                    "Episodes": episodes, "Best_episode": int(best_ep), "Runtime_s": runtime,
                    "Cmax": float(nmetrics["makespan"]), "Energy": float(nmetrics["energy"]),
                    "AHD": float(nmetrics["risk"]), "Fatigue": float(nmetrics["fatigue"]),
                    "NVS": float(nmetrics["nvs"]), "Feasible": float(nmetrics["budget_feasible"]),
                    **_counter_row(nenv),
                }
                dyn = evaluate_disturbances(
                    solver, base_data, variant, policy, actions, int(seed), float(nmetrics["makespan"])
                )
                nominal_rows.append(nominal)
                rows.extend(dyn)
                base.json_dump(ck, {"nominal": nominal, "dynamic": dyn})
    finally:
        base.make_planner = original_make_planner

    nom_df = pd.DataFrame(nominal_rows)
    dyn_df = pd.DataFrame(rows)
    nom_df.to_csv(out / "static_vs_event_nominal_reference.csv", index=False, encoding="utf-8-sig")
    dyn_df.to_csv(out / "static_vs_event_disturbance_runs.csv", index=False, encoding="utf-8-sig")
    summarize(dyn_df).to_csv(out / "static_vs_event_disturbance_summary.csv", index=False, encoding="utf-8-sig")
    paired_deltas(dyn_df).to_csv(out / "static_vs_event_paired_seed_deltas.csv", index=False, encoding="utf-8-sig")

    readout = [
        "# Static vs Event-driven under HE-1 / HE-4",
        "",
        "Static is a guidance-layer control: it keeps the same hard feasible-domain projection and physical dynamic-AHD evolution, but freezes online task retyping and DBN posterior refresh after t0.",
        "",
        "Primary paper-facing file: static_vs_event_disturbance_summary.csv",
        "Matched-seed file: static_vs_event_paired_seed_deltas.csv",
        "Raw file: static_vs_event_disturbance_runs.csv",
        "",
        "Desired scientific pattern (do not force): nominal results may be similar, while disturbance results reveal whether event-conditioned guidance changes post-event AHD / ABFR / NVS / Cmax trade-offs.",
    ]
    (out / "ACCEPTANCE_READOUT.md").write_text("\n".join(readout), encoding="utf-8")
    print(f"[OK] outputs written to: {out}")


if __name__ == "__main__":
    main()
