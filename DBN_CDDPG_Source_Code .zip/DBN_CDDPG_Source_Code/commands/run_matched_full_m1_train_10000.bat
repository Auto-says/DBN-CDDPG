@echo off
setlocal
cd /d "%~dp0\.."
python train_full_m1.py --variants full,m1_no_dbn --seeds 42,52,62,72,82,92,102,112,122,132 --episodes 10000 --eval_interval 50 --device cuda --output_dir outputs_full_m1_training
if errorlevel 1 exit /b %errorlevel%
endlocal
