#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python analyze_full_m1.py --input_dir outputs_full_m1_HE1_HE4
