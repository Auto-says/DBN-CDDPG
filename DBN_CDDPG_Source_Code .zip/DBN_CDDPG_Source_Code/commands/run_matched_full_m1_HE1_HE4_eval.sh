#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python evaluate_full_m1.py \
  --actors_dir outputs_full_m1_training/actors \
  --variants full,m1_no_dbn \
  --seeds 42,52,62,72,82,92,102,112,122,132 \
  --scenarios nominal,HE-1,HE-4 \
  --device cuda \
  --output_dir outputs_full_m1_HE1_HE4
