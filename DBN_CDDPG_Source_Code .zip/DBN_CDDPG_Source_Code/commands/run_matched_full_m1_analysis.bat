@echo off
setlocal
cd /d "%~dp0\.."
python analyze_full_m1.py --input_dir outputs_full_m1_HE1_HE4
if errorlevel 1 exit /b %errorlevel%
endlocal
