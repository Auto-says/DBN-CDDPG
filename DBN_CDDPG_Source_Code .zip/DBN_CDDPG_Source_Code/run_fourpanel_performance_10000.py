from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd
import torch

from experiment_common import (
    FORMAL_BUDGETS,
    FORMAL_SEEDS,
    json_dump,
    load_solver,
    mean_sd,
    parse_seeds,
    sha256,
    write_csv,
)
from run_table7_formal import (
    DISPLAY,
    METHODS,
    train_one,
)

try:
    from scipy.stats import wilcoxon
except Exception:  # pragma: no cover
    wilcoxon = None

RUNNER_VERSION = "fourpanel-nominal-10000-v1.0"

PANEL_METRICS = [
    ("makespan", "Cmax", "s"),
    ("risk", "AHD", ""),
    ("fatigue", "Fatigue", ""),
    ("energy", "Energy", ""),
]




def _df_to_markdown(frame: pd.DataFrame) -> str:
    """Render a DataFrame as a Markdown table without the optional tabulate package."""
    if frame is None or frame.empty:
        return "_No rows._"

    def _cell(value: Any) -> str:
        try:
            if pd.isna(value):
                return ""
        except Exception:
            pass
        if isinstance(value, (float, np.floating)):
            text = f"{float(value):.6g}"
        else:
            text = str(value)
        return text.replace("|", "\\|").replace("\n", " ")

    columns = [str(c) for c in frame.columns]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(_cell(v) for v in row) + " |")
    return "\n".join(lines)

def _holm_adjust(p_values: List[float]) -> np.ndarray:
    arr = np.asarray(p_values, dtype=float)
    out = np.full(arr.shape, np.nan, dtype=float)
    valid = np.flatnonzero(np.isfinite(arr))
    if len(valid) == 0:
        return out
    order = valid[np.argsort(arr[valid])]
    m = len(order)
    running = 0.0
    for rank, idx in enumerate(order):
        adj = min(1.0, (m - rank) * float(arr[idx]))
        running = max(running, adj)
        out[idx] = running
    return out



def _hedges_g_av(baseline: np.ndarray, dbn: np.ndarray) -> float:
    """Hedges' g_av effect size used in the manuscript statistical table.

    Positive values indicate that the baseline has a larger value than DBN-CDDPG.
    """
    x = np.asarray(baseline, dtype=float)
    y = np.asarray(dbn, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if len(x) < 2:
        return math.nan
    sx = np.std(x, ddof=1)
    sy = np.std(y, ddof=1)
    sav = math.sqrt((sx * sx + sy * sy) / 2.0)
    if sav <= 0:
        return 0.0
    dz = (float(np.mean(x)) - float(np.mean(y))) / sav
    correction = 1.0 - 3.0 / max(1.0, 4.0 * len(x) - 5.0)
    return float(correction * dz)

def _paper_summary(runs: pd.DataFrame, methods: List[str]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for method in methods:
        g = runs[runs["algorithm"] == method]
        if g.empty:
            continue
        row: Dict[str, Any] = {
            "algorithm": method,
            "Algorithm": DISPLAY[method],
            "n": int(len(g)),
            "ABFR_pct": 100.0 * float(g["budget_feasible"].mean()),
            "NVS_mean": float(pd.to_numeric(g["nvs"], errors="coerce").mean()),
            "best_checkpoint_episode_mean": float(pd.to_numeric(g["best_checkpoint_episode"], errors="coerce").mean()),
        }
        for col, label, _unit in PANEL_METRICS:
            mean, sd, n = mean_sd(g[col])
            row[f"{label}_mean"] = mean
            row[f"{label}_sd"] = sd
            row[f"{label}_n"] = n
        rows.append(row)
    return pd.DataFrame(rows)


def _write_origin_panel_sources(out: Path, summary: pd.DataFrame) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for _col, label, unit in PANEL_METRICS:
        cols = ["Algorithm", f"{label}_mean", f"{label}_sd", f"{label}_n"]
        panel = summary[cols].copy()
        panel.columns = [
            "Algorithm",
            f"Mean_{label}" + (f"_{unit}" if unit else ""),
            f"SD_{label}" + (f"_{unit}" if unit else ""),
            "n",
        ]
        panel.to_csv(out / f"panel_{label}.csv", index=False, encoding="utf-8-sig")

    # One wide sheet is convenient for Origin when building a 2x2 multi-panel graph.
    wide_cols = ["Algorithm"]
    for _col, label, _unit in PANEL_METRICS:
        wide_cols.extend([f"{label}_mean", f"{label}_sd"])
    summary[wide_cols].to_csv(out / "fourpanel_origin_wide.csv", index=False, encoding="utf-8-sig")


def _paired_tests_vs_full(runs: pd.DataFrame, methods: List[str]) -> pd.DataFrame:
    full = runs[runs["algorithm"] == "dbn_cddpg"].set_index("seed")
    rows: List[Dict[str, Any]] = []
    for method in methods:
        if method == "dbn_cddpg":
            continue
        other = runs[runs["algorithm"] == method].set_index("seed")
        common = full.index.intersection(other.index)
        for col, label, _unit in PANEL_METRICS:
            x = pd.to_numeric(other.loc[common, col], errors="coerce")
            y = pd.to_numeric(full.loc[common, col], errors="coerce")
            valid = x.notna() & y.notna()
            xv = x[valid].to_numpy(dtype=float)
            yv = y[valid].to_numpy(dtype=float)
            stat = math.nan
            p = math.nan
            if wilcoxon is not None and len(xv) >= 2 and not np.allclose(xv, yv):
                try:
                    stat, p = wilcoxon(xv, yv, alternative="two-sided")
                except Exception:
                    pass
            rows.append({
                "algorithm": method,
                "Algorithm": DISPLAY[method],
                "metric": label,
                "n_pairs": int(len(xv)),
                "baseline_mean": float(np.mean(xv)) if len(xv) else math.nan,
                "dbn_cddpg_mean": float(np.mean(yv)) if len(yv) else math.nan,
                "wilcoxon_stat": stat,
                "p_value": p,
                "hedges_g_av": _hedges_g_av(xv, yv),
            })
    frame = pd.DataFrame(rows)
    if not frame.empty:
        frame["p_holm"] = np.nan
        # Four panel metrics form one family for each baseline-vs-Full comparison.
        for method, idx in frame.groupby("algorithm").groups.items():
            idx = list(idx)
            frame.loc[idx, "p_holm"] = _holm_adjust(frame.loc[idx, "p_value"].tolist())
        frame["significant_holm_0_05"] = (frame["p_holm"] < 0.05).fillna(False).astype(int)
    return frame


def analyze(out: Path, methods: List[str]) -> None:
    runs = pd.read_csv(out / "fourpanel_runs.csv")
    summary = _paper_summary(runs, methods)
    summary.to_csv(out / "fourpanel_summary.csv", index=False, encoding="utf-8-sig")
    _write_origin_panel_sources(out, summary)
    tests = _paired_tests_vs_full(runs, methods)
    tests.to_csv(out / "fourpanel_paired_tests_vs_full.csv", index=False, encoding="utf-8-sig")

    md = [
        "# Four-panel nominal performance comparison",
        "",
        "Panels: (a) Cmax, (b) AHD, (c) Fatigue, (d) Energy.",
        "Values are matched-seed deterministic evaluations of the feasibility-first selected checkpoint.",
        "All trainable algorithms use the same maximum training budget, task data, dynamic-AHD/event-retyping environment, hard engineering feasible domain, and formal cumulative budgets.",
        "",
        _df_to_markdown(summary),
    ]
    (out / "fourpanel_ready_to_copy.md").write_text("\n".join(md), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Nominal six-algorithm experiment for the 2x2 Cmax/AHD/Fatigue/Energy comparison figure"
    )
    ap.add_argument("--workbook", default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    ap.add_argument("--solver_module", default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--methods", default="all")
    ap.add_argument("--seeds", default=",".join(map(str, FORMAL_SEEDS)))
    ap.add_argument("--episodes", type=int, default=10000)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--eval_interval", type=int, default=50)
    ap.add_argument("--output_dir", default="outputs_fourpanel_performance_10000")
    ap.add_argument("--save_run_details", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    workbook = (root / args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    solver_path = (root / args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module)
    out = (root / args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)

    methods = METHODS if args.methods.strip().lower() == "all" else [x.strip() for x in args.methods.split(",") if x.strip()]
    bad = [x for x in methods if x not in METHODS]
    if bad:
        raise ValueError(f"Unknown methods: {bad}")
    seeds = parse_seeds(args.seeds)
    episodes = int(args.episodes)
    if args.smoke:
        seeds = [seeds[0]]
        episodes = 2
        args.eval_interval = 1

    manifest = {
        "runner_version": RUNNER_VERSION,
        "purpose": "Source data for one 2x2 nominal performance comparison figure: Cmax, AHD, Fatigue, Energy.",
        "solver_module": str(solver_path),
        "solver_sha256": sha256(solver_path) if solver_path.exists() else None,
        "workbook": str(workbook),
        "methods": methods,
        "seeds": seeds,
        "episodes": episodes,
        "device": args.device,
        "eval_interval": int(args.eval_interval),
        "budgets": FORMAL_BUDGETS,
        "checkpoint_rule": "Same feasibility-first lexicographic checkpoint selection as formal Table 7 runner.",
        "protocol": "Nominal only; no HE-1--HE-4 stress evaluation. Every trainable method receives the same maximum episode budget and matched seeds.",
    }

    if args.dry_run:
        if not workbook.exists():
            raise FileNotFoundError(workbook)
        if not solver_path.exists():
            raise FileNotFoundError(solver_path)
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return

    solver = load_solver(solver_path)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Use --device cpu only for validation/smoke tests.")

    base = solver.load_input_payload(workbook, scenario_id=None)
    out.mkdir(parents=True, exist_ok=True)
    json_dump(out / "fourpanel_manifest.json", manifest)
    ckpt_dir = out / "completed_seed_checkpoints"
    ckpt_dir.mkdir(exist_ok=True)

    rows: List[Dict[str, Any]] = []
    for method in methods:
        for seed in seeds:
            cp = ckpt_dir / f"{method}_seed{seed}_ep{episodes}.json"
            if args.resume and cp.exists():
                row = json.loads(cp.read_text(encoding="utf-8"))
                rows.append(row)
                print(f"[resume] {method} seed={seed}", flush=True)
                continue

            print(f"[FourPanel] {method} seed={seed} episodes={episodes}", flush=True)
            t0 = time.perf_counter()
            planner, policy, actions, metrics, safety, best_ep = train_one(
                solver,
                base,
                method,
                seed,
                episodes,
                args.device,
                args.eval_interval,
                args.save_run_details,
                out / "run_details",
            )
            runtime = time.perf_counter() - t0
            row = {
                "runner_version": RUNNER_VERSION,
                "algorithm": method,
                "display_name": DISPLAY[method],
                "seed": int(seed),
                "episodes": int(episodes),
                "best_checkpoint_episode": int(best_ep),
                "makespan": float(metrics["makespan"]),
                "risk": float(metrics["risk"]),
                "fatigue": float(metrics["fatigue"]),
                "energy": float(metrics["energy"]),
                "prep_time": float(metrics.get("prep_time", math.nan)),
                "budget_feasible": float(metrics["budget_feasible"]),
                "nvs": float(metrics["nvs"]),
                "decision_time_ms": float(safety["decision_time_ms"]),
                "runtime_s": float(runtime),
            }
            rows.append(row)
            json_dump(cp, row)
            write_csv(out / "fourpanel_runs.csv", rows)
            analyze(out, methods)

    write_csv(out / "fourpanel_runs.csv", rows)
    analyze(out, methods)
    print(f"\nFour-panel experiment completed. Outputs: {out}")


if __name__ == "__main__":
    main()
