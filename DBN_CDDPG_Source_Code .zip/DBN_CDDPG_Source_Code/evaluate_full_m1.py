from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
import torch

from experiment_common import budget_diagnostics, force_formal_budgets, load_solver
from full_m1_support import (
    FORMAT_VERSION,
    SCENARIOS,
    SEEDS,
    VARIANTS,
    load_actor_checkpoint,
    make_agent,
    make_planner,
    parse_csv_ints,
    parse_csv_names,
    runtime_manifest,
    sha256_file,
    stable_json_hash,
)

RUNNER_VERSION = "matched-full-m1-evaluate-v1.0"


def _jsonable(value: Any):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _hash_jsonable(value: Any) -> str:
    raw = json.dumps(_jsonable(value), sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _action_dict(action) -> Dict[str, Any]:
    return {
        "task_id": int(action.task_id),
        "mode": str(action.mode),
        "binding_index": int(action.binding_index),
        "human_id": getattr(action, "human_id", None),
        "robot_id": getattr(action, "robot_id", None),
    }


def _decode_strength(env, raw_actor: np.ndarray, context: Dict[str, np.ndarray], strength: float):
    original = float(env.params.get("dbn_guidance_strength", 0.35))
    env.params["dbn_guidance_strength"] = float(strength)
    try:
        action, _ = env.decode_action(raw_actor, context=context)
    finally:
        env.params["dbn_guidance_strength"] = original
    return action


def _physical_state_payload(env) -> Dict[str, Any]:
    return {
        "completed": np.asarray(env.completed, dtype=float).round(8).tolist(),
        "human_available": {str(k): float(v) for k, v in env.human_available.items()},
        "robot_available": {str(k): float(v) for k, v in env.robot_available.items()},
        "human_fatigue": {str(k): float(v) for k, v in env.human_fatigue.items()},
        "dynamic_ahd_scores": {str(k): float(v) for k, v in env.dynamic_ahd_scores.items()},
        "current_task_types": {str(k): str(v) for k, v in env.current_task_types.items()},
        "external_ahd_multiplier": float(getattr(env, "_external_ahd_multiplier", 1.0)),
        "external_risk_multiplier": float(getattr(env, "_external_risk_multiplier", 1.0)),
    }


def evaluate_actor(solver, planner, agent, *, variant: str, seed: int, scenario: str):
    env = planner.make_env()
    state = env.reset()
    done = False
    event_rows = []
    opportunities = 0
    flips = 0

    while not done:
        completed_before = len(env.schedule)
        context = env.projection_context()
        raw_actor = agent.act(state, explore=False)
        action_on = _decode_strength(env, raw_actor, context, float(env.params.get("dbn_guidance_strength", 0.0)))
        action_off = _decode_strength(env, raw_actor, context, 0.0)
        tid = int(action_on.task_id)
        task = env.p.tasks[tid]
        task_type = str(env.current_task_types.get(tid, env.p.initial_task_types[tid]))
        legal_modes = list(env.feasible_modes(tid))
        beta = np.asarray(env.beta_map.get(tid, np.zeros(3, np.float32)), dtype=float)
        raw_modes = np.asarray(raw_actor[env.n_tasks:env.n_tasks + 3], dtype=float)
        guided_modes = raw_modes + float(env.params.get("dbn_guidance_strength", 0.0)) * beta
        opportunity = int(task_type == "III" and len(legal_modes) > 1)
        changed = int(opportunity and _action_dict(action_on) != _action_dict(action_off))
        opportunities += opportunity
        flips += changed

        row = {
            "seed": int(seed),
            "variant": variant,
            "scenario": scenario,
            "event_index": int(completed_before),
            "completed_before": int(completed_before),
            "state_hash": _hash_jsonable(np.asarray(state, dtype=float).round(10).tolist()),
            "physical_state_hash": _hash_jsonable(_physical_state_payload(env)),
            "external_ahd_multiplier": float(getattr(env, "_external_ahd_multiplier", 1.0)),
            "external_risk_multiplier": float(getattr(env, "_external_risk_multiplier", 1.0)),
            "task_type": task_type,
            "task_id": tid,
            "task_name": str(task.name),
            "task_ahd": float(env.dynamic_ahd_scores.get(tid, env.p.ahd_scores.get(tid, 0.0))),
            "cumulative_ahd_before": float(getattr(env, "total_risk", 0.0)),
            "mean_human_fatigue": float(np.mean(list(env.human_fatigue.values()))) if env.human_fatigue else 0.0,
            "legal_modes": ", ".join(legal_modes),
            "posterior_H": float(beta[0]),
            "posterior_R": float(beta[1]),
            "posterior_HRC": float(beta[2]),
            "mode_scores_raw": json.dumps(raw_modes.tolist()),
            "mode_scores_guided": json.dumps(guided_modes.tolist()),
            "action_guidance_on": json.dumps(_action_dict(action_on), ensure_ascii=False),
            "action_guidance_off": json.dumps(_action_dict(action_off), ensure_ascii=False),
            "multiple_legal_TypeIII_opportunity": opportunity,
            "explicit_guidance_changes_action": changed,
            "state_vector": json.dumps(np.asarray(state, dtype=float).tolist()),
            "raw_actor_vector": json.dumps(np.asarray(raw_actor, dtype=float).tolist()),
            "projection_context": json.dumps(_jsonable(context), ensure_ascii=False),
        }

        state, _, done, info = env.step(raw_actor, projection_context=context)
        scheduled = env.schedule[-1]
        row.update(
            {
                "executed_mode": str(scheduled.mode),
                "executed_binding": str(scheduled.binding),
                "delta_makespan": float(scheduled.delta_time),
                "delta_ahd": float(scheduled.delta_risk),
                "delta_fatigue": float(scheduled.delta_fatigue),
                "delta_energy": float(scheduled.delta_energy),
            }
        )
        event_rows.append(row)

    metrics = dict(env.metrics())
    metrics.update(budget_diagnostics(metrics))
    first = getattr(env, "_first_stress_schedule_index", None)
    post = math.nan
    if first is not None:
        post = float(sum(float(x.delta_risk) for x in env.schedule[int(first):]))
    result = {
        "variant": variant,
        "seed": int(seed),
        "scenario": scenario,
        "is_complete": int(len(env.schedule) == env.n_tasks),
        "completed_tasks": int(len(env.schedule)),
        "makespan": float(metrics["makespan"]),
        "ahd_total": float(metrics["risk"]),
        "ahd_post_first_event": post,
        "energy": float(metrics["energy"]),
        "fatigue": float(metrics["fatigue"]),
        "nvs": float(metrics["nvs"]),
        "budget_feasible": int(metrics["budget_feasible"] > 0.5),
        "first_stress_after_completed_tasks": None if first is None else int(first),
        "TypeIII_multiple_mode_opportunities": int(opportunities),
        "explicit_guidance_action_flips": int(flips),
        "explicit_guidance_flip_rate_pct": 100.0 * flips / opportunities if opportunities else 0.0,
        "use_dbn_state": int(env.params.get("use_dbn_state", 1)),
        "use_dynamic_ahd": int(env.params.get("use_dynamic_ahd", 1)),
        "use_event_retyping": int(env.params.get("use_event_retyping", 1)),
        "dbn_guidance_strength": float(env.params.get("dbn_guidance_strength", 0.0)),
    }
    return result, metrics, env, event_rows


def _write_run_details(root: Path, result, metrics, env, event_rows):
    root.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([vars(x) for x in env.schedule]).to_csv(root / "schedule.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(getattr(env, "dbn_trace", [])).to_csv(root / "dbn_trace.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(getattr(env, "dynamic_ahd_trace", [])).to_csv(root / "dynamic_ahd_trace.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(getattr(env, "task_type_trace", [])).to_csv(root / "task_type_trace.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(event_rows).to_csv(root / "event_decisions.csv", index=False, encoding="utf-8-sig")
    (root / "result.json").write_text(json.dumps(_jsonable(result), ensure_ascii=False, indent=2), encoding="utf-8")
    (root / "metrics_raw.json").write_text(json.dumps(_jsonable(metrics), ensure_ascii=False, indent=2), encoding="utf-8")


def _summary(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (variant, scenario), g in runs.groupby(["variant", "scenario"], sort=False):
        rec = {
            "variant": variant,
            "scenario": scenario,
            "n_seeds": int(g.seed.nunique()),
            "completion_pct": 100.0 * float(g.is_complete.mean()),
            "ABFR_pct": 100.0 * float(g.budget_feasible.mean()),
        }
        for col in ["makespan", "ahd_total", "ahd_post_first_event", "fatigue", "energy", "nvs"]:
            x = pd.to_numeric(g[col], errors="coerce").dropna().to_numpy(dtype=float)
            rec[f"{col}_mean"] = float(x.mean()) if len(x) else math.nan
            rec[f"{col}_sd"] = float(x.std(ddof=1)) if len(x) > 1 else (0.0 if len(x) == 1 else math.nan)
            rec[f"{col}_n"] = int(len(x))
        rows.append(rec)
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate saved Full/M1 actors under nominal, HE-1 and HE-4 without learning or checkpoint reselection.")
    ap.add_argument("--workbook", default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    ap.add_argument("--solver_module", default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--actors_dir", default="outputs_full_m1_training/actors")
    ap.add_argument("--variants", default="all")
    ap.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    ap.add_argument("--scenarios", default="nominal,HE-1,HE-4")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--output_dir", default="outputs_full_m1_HE1_HE4")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    workbook = (root / args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    solver_path = (root / args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module)
    actors = (root / args.actors_dir).resolve() if not Path(args.actors_dir).is_absolute() else Path(args.actors_dir)
    out = (root / args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    variants = parse_csv_names(args.variants, VARIANTS)
    seeds = parse_csv_ints(args.seeds)
    scenarios = parse_csv_names(args.scenarios, SCENARIOS.keys())

    if not workbook.exists():
        raise FileNotFoundError(workbook)
    if not solver_path.exists():
        raise FileNotFoundError(solver_path)
    if args.device.startswith("cuda") and not torch.cuda.is_available() and not args.dry_run:
        raise RuntimeError("CUDA requested but unavailable; use --device cpu for a protocol test.")

    manifest = {
        "format_version": FORMAT_VERSION,
        "runner_version": RUNNER_VERSION,
        "runtime": runtime_manifest(),
        "scenarios": {k: list(SCENARIOS[k]) for k in scenarios},
        "variants": variants,
        "seeds": seeds,
        "training": False,
        "checkpoint_reselection": False,
        "solver_sha256": sha256_file(solver_path),
        "workbook_sha256": sha256_file(workbook),
        "evaluator_sha256": sha256_file(Path(__file__).resolve()),
        "scope": "Trajectory comparison + same-state explicit-guidance decoding diagnostic; no downstream branch causal effect is estimated",
    }
    manifest["evaluation_protocol_id"] = stable_json_hash({k: v for k, v in manifest.items() if k != "runtime"})
    if args.dry_run:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return

    solver = load_solver(solver_path)
    base_data = force_formal_budgets(solver.load_input_payload(workbook, scenario_id=None))
    out.mkdir(parents=True, exist_ok=True)
    rows = []

    for variant in variants:
        for seed in seeds:
            checkpoint_path = actors / variant / f"seed_{seed}.pt"
            if not checkpoint_path.exists():
                raise FileNotFoundError(f"Missing saved actor: {checkpoint_path}")
            checkpoint = load_actor_checkpoint(checkpoint_path, map_location="cpu")
            if checkpoint["variant"] != variant or int(checkpoint["seed"]) != int(seed):
                raise ValueError(f"Actor metadata mismatch: {checkpoint_path}")
            for scenario in scenarios:
                print(f"[evaluate] {variant} seed={seed} scenario={scenario}", flush=True)
                events = SCENARIOS[scenario]
                planner = make_planner(solver, base_data, variant, stress_events=events)
                agent, state_dim, action_dim = make_agent(solver, planner, args.device)
                if int(checkpoint["state_dim"]) != state_dim or int(checkpoint["action_dim"]) != action_dim:
                    raise ValueError(f"Actor dimensions do not match current environment: {checkpoint_path}")
                agent.actor.load_state_dict(checkpoint["actor_state_dict"])
                agent.actor_target.load_state_dict(checkpoint["actor_state_dict"])
                result, metrics, env, event_rows = evaluate_actor(
                    solver, planner, agent, variant=variant, seed=seed, scenario=scenario
                )
                result["selected_episode"] = int(checkpoint["selected_episode"])
                result["planned_training_episodes"] = int(checkpoint["planned_training_episodes"])
                rows.append(result)
                detail = out / "run_details" / variant / f"seed_{seed}" / scenario
                _write_run_details(detail, result, metrics, env, event_rows)
                pd.DataFrame(rows).to_csv(out / "evaluation_runs.csv", index=False, encoding="utf-8-sig")

    runs = pd.DataFrame(rows).sort_values(["variant", "seed", "scenario"])
    runs.to_csv(out / "evaluation_runs.csv", index=False, encoding="utf-8-sig")
    _summary(runs).to_csv(out / "evaluation_summary.csv", index=False, encoding="utf-8-sig")
    (out / "evaluation_manifest.json").write_text(json.dumps(_jsonable(manifest), ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Completed saved-actor Full/M1 evaluation. Outputs: {out}")


if __name__ == "__main__":
    main()
