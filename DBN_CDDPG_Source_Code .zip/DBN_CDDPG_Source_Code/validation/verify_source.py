from __future__ import annotations

import hashlib
import json
import py_compile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROV = json.loads((ROOT / "SOURCE_PROVENANCE.json").read_text(encoding="utf-8"))

failed = False
print("Source integrity check")
for name, rec in PROV["source_files"].items():
    path = ROOT / name
    if not path.exists():
        print(f"[MISSING] {name}")
        failed = True
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    ok = digest == rec["sha256"]
    print(f"[{'OK' if ok else 'HASH MISMATCH'}] {name}  {digest}")
    failed |= not ok

print("\nPython compilation check (all packaged .py files)")
py_files = sorted(
    p for p in ROOT.rglob("*.py")
    if "__pycache__" not in p.parts
)
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    for idx, path in enumerate(py_files):
        rel = path.relative_to(ROOT).as_posix()
        try:
            py_compile.compile(str(path), cfile=str(tmp / f"{idx}.pyc"), doraise=True)
            print(f"[OK] {rel}")
        except Exception as exc:
            print(f"[FAILED] {rel}: {exc}")
            failed = True

if failed:
    raise SystemExit(1)
print(f"\nAll {len(py_files)} packaged Python files passed compilation; provenance hashes also passed.")
