from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "CHECKSUMS.sha256"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def actual_files():
    out = set()
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if path == MANIFEST or "__pycache__" in rel.parts or path.suffix == ".pyc":
            continue
        out.add(rel.as_posix())
    return out


def main() -> None:
    if not MANIFEST.exists():
        raise SystemExit("[FAILED] CHECKSUMS.sha256 is missing")
    expected = {}
    for raw in MANIFEST.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            raise SystemExit(f"[FAILED] malformed checksum line: {raw!r}")
        hexdigest, name = parts
        name = name.strip()
        if name.startswith("./"):
            name = name[2:]
        expected[name] = hexdigest.lower()

    failed = False
    for name in sorted(expected):
        path = ROOT / name
        if not path.exists():
            print(f"[MISSING] {name}")
            failed = True
            continue
        actual = digest(path)
        if actual == expected[name]:
            print(f"[OK] {name}")
        else:
            print(f"[FAILED] {name}\n  expected: {expected[name]}\n  actual:   {actual}")
            failed = True

    actual = actual_files()
    listed = set(expected)
    for name in sorted(actual - listed):
        print(f"[UNTRACKED] {name}")
        failed = True
    for name in sorted(listed - actual):
        if (ROOT / name).exists():
            continue
        # Missing files were already reported above.

    print(f"\nChecked {len(expected)} manifest entries against {len(actual)} actual tracked files.")
    if failed:
        raise SystemExit(1)
    print("All checksums OK; manifest and archive file structure are consistent.")


if __name__ == "__main__":
    main()
