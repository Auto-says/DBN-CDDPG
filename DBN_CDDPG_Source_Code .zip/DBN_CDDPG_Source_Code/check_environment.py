from __future__ import annotations

import argparse
import json
from pathlib import Path

from full_m1_support import runtime_manifest

CORE = {
    "torch": "2.7.1+cu128",
    "numpy": "2.1.2",
    "pandas": "2.3.1",
    "scipy": "1.16.0",
    "openpyxl": "3.1.5",
}
MATCHED = {
    "torch": "2.8.0+cu129",
    "numpy": "2.1.3",
    "pandas": "2.2.3",
    "scipy": "1.15.3",
    "openpyxl": "3.1.5",
}


def main() -> None:
    ap = argparse.ArgumentParser(description="Record/check the software and deterministic-execution environment.")
    ap.add_argument("--expected", choices=["none", "core", "matched"], default="none")
    ap.add_argument("--output", default=None)
    ap.add_argument("--strict", action="store_true", help="Exit nonzero if package versions differ from the selected expected profile.")
    args = ap.parse_args()

    info = runtime_manifest()
    expected = None if args.expected == "none" else (CORE if args.expected == "core" else MATCHED)
    mismatches = []
    if expected:
        for name, value in expected.items():
            actual = info["versions"].get(name)
            if actual != value:
                mismatches.append({"package": name, "expected": value, "actual": actual})
    info["expected_profile"] = args.expected
    info["version_mismatches"] = mismatches
    print(json.dumps(info, ensure_ascii=False, indent=2))
    if args.output:
        Path(args.output).write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.strict and mismatches:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
