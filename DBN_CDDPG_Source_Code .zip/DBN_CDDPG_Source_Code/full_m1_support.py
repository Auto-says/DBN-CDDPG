from __future__ import annotations

import hashlib
import json
import math
import platform
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch

import run_table8_formal as ablation
from experiment_common import (
    budget_diagnostics,
    deep_payload_with_params,
    force_formal_budgets,
    make_planner_class,
    make_stress_env_class,
    set_all_seeds,
)

SEEDS = [42, 52, 62, 72, 82, 92, 102, 112, 122, 132]
VARIANTS = ("full", "m1_no_dbn")
SCENARIOS: Dict[str, Sequence[Mapping[str, float]]] = {
    "nominal": (),
    "HE-1": (
        {"completed_tasks": 7, "ahd_multiplier": 1.35, "risk_multiplier": 1.10},
    ),
    "HE-4": (
        {
            "completed_tasks": 7,
            "ahd_multiplier": 1.45,
            "risk_multiplier": 1.25,
            "fatigue_shock": 0.80,
            "robot_delay": 20.0,
        },
        {
            "completed_tasks": 14,
            "ahd_multiplier": 1.20,
            "risk_multiplier": 1.20,
            "fatigue_shock": 0.60,
            "robot_delay": 10.0,
        },
    ),
}

FORMAT_VERSION = "full-m1-reloadable-v1.0"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_json_hash(payload: Any) -> str:
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def parse_csv_ints(text: str) -> list[int]:
    out = [int(x.strip()) for x in str(text).split(",") if x.strip()]
    if not out:
        raise ValueError("No integer values supplied")
    return out


def parse_csv_names(text: str, allowed: Iterable[str]) -> list[str]:
    allowed = tuple(allowed)
    if str(text).strip().lower() == "all":
        return list(allowed)
    out = [x.strip() for x in str(text).split(",") if x.strip()]
    bad = [x for x in out if x not in allowed]
    if bad:
        raise ValueError(f"Unknown values: {bad}; allowed={allowed}")
    if not out:
        raise ValueError("No names supplied")
    return out


def variant_params(variant: str) -> Dict[str, Any]:
    if variant not in VARIANTS:
        raise ValueError(f"Unsupported matched variant: {variant}")
    params = dict(ablation.BASE_PARAMS)
    params.update(ablation.VARIANTS[variant].get("params", {}))
    params["table8_variant"] = variant
    return params


def make_planner(solver, base_data: Mapping[str, Any], variant: str, stress_events=None):
    """Build the Full/M1 planner from the same flags used by the mechanism suite."""
    params = variant_params(variant)
    payload = force_formal_budgets(deep_payload_with_params(base_data, params))
    if stress_events:
        env_cls = make_stress_env_class(solver, stress_events)
    else:
        env_cls = solver.DBNCDDPGEnv
    Planner = make_planner_class(solver, env_cls, allow_dual_update=True)
    return Planner(payload)


def make_agent(solver, planner, device: str):
    probe = planner.make_env()
    state_dim = int(probe.state_dim)
    action_dim = int(len(planner.topo_order) + len(solver.MODES) + planner.binding_dim)
    agent = solver.DDPGAgent(state_dim, action_dim, planner, device=device)
    return agent, state_dim, action_dim


def actor_snapshot(agent) -> Dict[str, torch.Tensor]:
    return {k: v.detach().cpu().clone() for k, v in agent.actor.state_dict().items()}


def restore_actor(agent, state_dict: Mapping[str, torch.Tensor]) -> None:
    agent.actor.load_state_dict(state_dict)
    agent.actor_target.load_state_dict(state_dict)


def selection_key(metrics: Mapping[str, Any]):
    return ablation.selection_key(metrics)


def evaluate_nominal(solver, planner, agent):
    env = planner.make_env()
    state = env.reset()
    done = False
    while not done:
        ctx = env.projection_context()
        action = agent.act(state, explore=False)
        state, _, done, _ = env.step(action, projection_context=ctx)
    metrics = dict(env.metrics())
    metrics.update(budget_diagnostics(metrics))
    return metrics, env


def train_selected_actor(
    solver,
    base_data: Mapping[str, Any],
    *,
    variant: str,
    seed: int,
    episodes: int,
    eval_interval: int,
    device: str,
):
    """Train Full/M1 and return the feasibility-first selected actor state.

    This mirrors the complete-schedule mechanism-suite training logic: actor
    snapshots are considered every ``eval_interval`` episodes and ranked by the
    same feasibility-first checkpoint key.  Only the selected actor is required
    for the later saved-actor evaluation.
    """
    set_all_seeds(int(seed))
    planner = make_planner(solver, base_data, variant)
    planner.params["_total_training_steps"] = int(episodes * len(planner.topo_order))
    agent, state_dim, action_dim = make_agent(solver, planner, device)

    best_state = None
    best_key = (9, math.inf, math.inf)
    best_episode = 0
    history = []

    for ep in range(1, int(episodes) + 1):
        env = planner.make_env()
        state = env.reset()
        done = False
        last = {"critic_loss": 0.0, "actor_loss": 0.0}
        while not done:
            ctx = env.projection_context()
            action = agent.act(state, explore=True)
            next_state, reward, done, info = env.step(action, projection_context=ctx)
            next_ctx = env.projection_context()
            agent.replay.push(
                state,
                info["executed_action_vector"],
                reward,
                next_state,
                done,
                ctx,
                next_ctx,
                transition_deltas=info.get("transition_deltas", np.zeros(4, np.float32)),
            )
            last = agent.update()
            state = next_state

        train_metrics = env.metrics()
        if int(train_metrics.get("is_complete", 0)) == 1:
            planner.update_constraint_lambdas(train_metrics)

        if ep % max(1, int(eval_interval)) == 0 or ep == int(episodes):
            eval_metrics, _ = evaluate_nominal(solver, planner, agent)
            key = selection_key(eval_metrics)
            history.append(
                {
                    "episode": int(ep),
                    "makespan": float(eval_metrics["makespan"]),
                    "ahd": float(eval_metrics["risk"]),
                    "energy": float(eval_metrics["energy"]),
                    "fatigue": float(eval_metrics["fatigue"]),
                    "nvs": float(eval_metrics["nvs"]),
                    "budget_feasible": int(eval_metrics["budget_feasible"] > 0.5),
                    "lambda_energy": float(planner.params.get("lambda_energy", 0.0)),
                    "lambda_risk": float(planner.params.get("lambda_risk", 0.0)),
                    "lambda_fatigue": float(planner.params.get("lambda_fatigue", 0.0)),
                    "critic_loss": float(last.get("critic_loss", 0.0)),
                    "actor_loss": float(last.get("actor_loss", 0.0)),
                }
            )
            if key < best_key:
                best_key = key
                best_episode = int(ep)
                best_state = actor_snapshot(agent)

    if best_state is None:
        raise RuntimeError(f"No checkpoint selected for {variant}, seed={seed}")
    restore_actor(agent, best_state)
    nominal_metrics, nominal_env = evaluate_nominal(solver, planner, agent)
    return {
        "planner": planner,
        "agent": agent,
        "actor_state_dict": best_state,
        "selected_episode": best_episode,
        "state_dim": state_dim,
        "action_dim": action_dim,
        "history": history,
        "nominal_metrics": nominal_metrics,
        "nominal_env": nominal_env,
    }


def save_actor_checkpoint(
    path: Path,
    *,
    variant: str,
    seed: int,
    selected_episode: int,
    planned_training_episodes: int,
    eval_interval: int,
    state_dim: int,
    action_dim: int,
    actor_state_dict: Mapping[str, torch.Tensor],
    solver_sha256: str,
    workbook_sha256: str,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format_version": FORMAT_VERSION,
        "variant": variant,
        "seed": int(seed),
        "selected_episode": int(selected_episode),
        "planned_training_episodes": int(planned_training_episodes),
        "eval_interval": int(eval_interval),
        "state_dim": int(state_dim),
        "action_dim": int(action_dim),
        "solver_sha256": solver_sha256,
        "workbook_sha256": workbook_sha256,
        "variant_params": variant_params(variant),
        "actor_state_dict": dict(actor_state_dict),
    }
    torch.save(payload, path)


def load_actor_checkpoint(path: Path, *, map_location: str | torch.device = "cpu") -> Dict[str, Any]:
    payload = torch.load(Path(path), map_location=map_location, weights_only=False)
    required = {
        "format_version",
        "variant",
        "seed",
        "selected_episode",
        "planned_training_episodes",
        "state_dim",
        "action_dim",
        "actor_state_dict",
    }
    missing = sorted(required.difference(payload))
    if missing:
        raise ValueError(f"Actor checkpoint {path} missing fields: {missing}")
    return payload


def runtime_manifest() -> Dict[str, Any]:
    try:
        import pandas as pd
    except Exception:
        pd = None
    try:
        import scipy
    except Exception:
        scipy = None
    try:
        import openpyxl
    except Exception:
        openpyxl = None

    device_name = None
    if torch.cuda.is_available():
        try:
            device_name = torch.cuda.get_device_name(0)
        except Exception:
            device_name = "cuda-available"
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "device_name": device_name,
        "versions": {
            "torch": torch.__version__,
            "numpy": np.__version__,
            "pandas": getattr(pd, "__version__", None),
            "scipy": getattr(scipy, "__version__", None),
            "openpyxl": getattr(openpyxl, "__version__", None),
        },
        "torch_cuda_build": torch.version.cuda,
        "threads": int(torch.get_num_threads()),
        "interop_threads": int(torch.get_num_interop_threads()),
        "deterministic_algorithms": bool(torch.are_deterministic_algorithms_enabled()),
        "cudnn_deterministic": bool(getattr(torch.backends.cudnn, "deterministic", False)),
        "cudnn_benchmark": bool(getattr(torch.backends.cudnn, "benchmark", False)),
        "cuda_matmul_allow_tf32": bool(getattr(torch.backends.cuda.matmul, "allow_tf32", False)),
        "cudnn_allow_tf32": bool(getattr(torch.backends.cudnn, "allow_tf32", False)),
    }


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
