from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from statistics import NormalDist

import numpy as np
import pandas as pd
from scipy.stats import rankdata, t

RUNNER_VERSION = "matched-full-m1-analysis-v1.0"
ENGINEERING = [
    ("makespan", "Cmax / s"),
    ("ahd_total", "Full-run AHD"),
    ("fatigue", "Fatigue"),
    ("energy", "Energy"),
]
SCENARIOS = ["HE-1", "HE-4"]


def exact_signed_rank_two_sided(differences: np.ndarray):
    d = np.asarray(differences, dtype=float)
    d = d[np.isfinite(d)]
    nz = d[np.abs(d) > 0.0]
    if len(nz) == 0:
        return math.nan, 1.0, 0
    ranks = rankdata(np.abs(nz), method="average")
    pos = float(ranks[nz > 0].sum())
    total = float(ranks.sum())
    observed = min(pos, total - pos)
    count = 0
    extreme = 0
    for signs in itertools.product((0, 1), repeat=len(nz)):
        plus = float(sum(r for r, s in zip(ranks, signs) if s))
        stat = min(plus, total - plus)
        count += 1
        extreme += int(stat <= observed + 1e-12)
    return observed, extreme / count, len(nz)


def holm_adjust(p_values):
    p = np.asarray(p_values, dtype=float)
    out = np.full_like(p, np.nan)
    valid = np.flatnonzero(np.isfinite(p))
    if not len(valid):
        return out
    order = valid[np.argsort(p[valid])]
    running = 0.0
    m = len(order)
    for rank, idx in enumerate(order):
        adj = min(1.0, (m - rank) * float(p[idx]))
        running = max(running, adj)
        out[idx] = running
    return out


def paired_ci(d: np.ndarray, confidence=0.95):
    d = np.asarray(d, dtype=float)
    d = d[np.isfinite(d)]
    n = len(d)
    mean = float(np.mean(d)) if n else math.nan
    if n < 2:
        return mean, math.nan, math.nan
    sd = float(np.std(d, ddof=1))
    crit = float(t.ppf((1 + confidence) / 2.0, n - 1))
    half = crit * sd / math.sqrt(n)
    return mean, mean - half, mean + half


def make_table_c6(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for scenario in SCENARIOS:
        full = runs[(runs.variant == "full") & (runs.scenario == scenario)].set_index("seed")
        m1 = runs[(runs.variant == "m1_no_dbn") & (runs.scenario == scenario)].set_index("seed")
        common = sorted(set(full.index).intersection(m1.index))
        for col, label in ENGINEERING:
            # The manuscript convention ranks exported engineering outcomes rounded to four decimals.
            f = pd.to_numeric(full.loc[common, col], errors="coerce").to_numpy(dtype=float)
            m = pd.to_numeric(m1.loc[common, col], errors="coerce").to_numpy(dtype=float)
            diffs = np.round(np.round(f, 4) - np.round(m, 4), 4)
            mean, lo, hi = paired_ci(diffs)
            stat, raw_p, nonzero = exact_signed_rank_two_sided(diffs)
            rows.append(
                {
                    "scenario": scenario,
                    "metric": label,
                    "n_pairs": len(diffs),
                    "nonzero_pairs": nonzero,
                    "delta_mean_Full_minus_M1": mean,
                    "ci95_low": lo,
                    "ci95_high": hi,
                    "wilcoxon_stat": stat,
                    "raw_p": raw_p,
                }
            )
    frame = pd.DataFrame(rows)
    frame["p_holm_8"] = holm_adjust(frame["raw_p"].to_numpy())
    frame["significant_holm_0_05"] = (frame["p_holm_8"] < 0.05).astype(int)
    return frame


def summarize_engineering(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for scenario in ["nominal", "HE-1", "HE-4"]:
        for variant in ["full", "m1_no_dbn"]:
            g = runs[(runs.variant == variant) & (runs.scenario == scenario)]
            if g.empty:
                continue
            row = {"scenario": scenario, "variant": variant, "n": int(len(g))}
            for col, _ in ENGINEERING:
                x = pd.to_numeric(g[col], errors="coerce").dropna().to_numpy(dtype=float)
                row[f"{col}_mean"] = float(x.mean()) if len(x) else math.nan
                row[f"{col}_sd"] = float(x.std(ddof=1)) if len(x) > 1 else (0.0 if len(x) == 1 else math.nan)
            rows.append(row)
    return pd.DataFrame(rows)


def summarize_feasibility(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for scenario in ["nominal", "HE-1", "HE-4"]:
        for variant in ["full", "m1_no_dbn"]:
            g = runs[(runs.variant == variant) & (runs.scenario == scenario)]
            if g.empty:
                continue
            nvs = pd.to_numeric(g.nvs, errors="coerce").dropna().to_numpy(dtype=float)
            rows.append(
                {
                    "scenario": scenario,
                    "variant": variant,
                    "n": int(len(g)),
                    "completion_pct": 100.0 * float(pd.to_numeric(g.is_complete, errors="coerce").mean()),
                    "ABFR_pct": 100.0 * float(pd.to_numeric(g.budget_feasible, errors="coerce").mean()),
                    "NVS_mean": float(nvs.mean()) if len(nvs) else math.nan,
                    "NVS_sd": float(nvs.std(ddof=1)) if len(nvs) > 1 else (0.0 if len(nvs) == 1 else math.nan),
                }
            )
    return pd.DataFrame(rows)


def collect_guidance_changes(input_dir: Path, task_names=None) -> pd.DataFrame:
    records = []
    task_names = task_names or {}
    for path in sorted((input_dir / "run_details" / "full").glob("seed_*/*/event_decisions.csv")):
        try:
            frame = pd.read_csv(path)
        except Exception:
            continue
        if "explicit_guidance_changes_action" not in frame.columns:
            continue
        if "cumulative_ahd_before" not in frame.columns and "delta_ahd" in frame.columns:
            delta = pd.to_numeric(frame["delta_ahd"], errors="coerce").fillna(0.0)
            frame["cumulative_ahd_before"] = delta.cumsum().shift(1, fill_value=0.0)
        x = frame[pd.to_numeric(frame.explicit_guidance_changes_action, errors="coerce").fillna(0).astype(int) == 1].copy()
        for _, r in x.iterrows():
            on = json.loads(r["action_guidance_on"]) if isinstance(r.get("action_guidance_on"), str) else {}
            off = json.loads(r["action_guidance_off"]) if isinstance(r.get("action_guidance_off"), str) else {}
            records.append(
                {
                    "scenario": r.get("scenario"),
                    "seed": int(r.get("seed")),
                    "decision_number_one_based": int(r.get("event_index", 0)) + 1,
                    "completed_tasks_before_decision": int(r.get("completed_before", 0)),
                    "task_id": int(r.get("task_id")),
                    "task_name": r.get("task_name", task_names.get(int(r.get("task_id")), "")),
                    "current_type": r.get("task_type"),
                    "legal_modes": r.get("legal_modes"),
                    "task_level_AHD": float(r.get("task_ahd")),
                    "posterior_H": float(r.get("posterior_H")),
                    "posterior_R": float(r.get("posterior_R")),
                    "posterior_HRC": float(r.get("posterior_HRC")),
                    "mode_without_guidance": off.get("mode"),
                    "mode_with_guidance": on.get("mode"),
                    "cumulative_AHD_before_decision": float(r.get("cumulative_ahd_before", math.nan)),
                }
            )
    return pd.DataFrame(records)


def main() -> None:
    ap = argparse.ArgumentParser(description="Analyze the matched Full/M1 nominal + HE-1/HE-4 saved-actor evaluation.")
    ap.add_argument("--input_dir", default="outputs_full_m1_HE1_HE4")
    ap.add_argument("--output_dir", default=None)
    ap.add_argument("--workbook", default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    inp = (root / args.input_dir).resolve() if not Path(args.input_dir).is_absolute() else Path(args.input_dir)
    out = inp if args.output_dir is None else ((root / args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir))
    workbook = (root / args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    task_names = {}
    if workbook.exists():
        try:
            tdf = pd.read_excel(workbook, sheet_name="tasks_master")
            task_names = {int(r.task_id): str(r.task_name) for r in tdf[["task_id", "task_name"]].itertuples(index=False)}
        except Exception:
            task_names = {}
    runs_path = inp / "evaluation_runs.csv"
    if not runs_path.exists():
        raise FileNotFoundError(runs_path)
    runs = pd.read_csv(runs_path)
    out.mkdir(parents=True, exist_ok=True)

    engineering = summarize_engineering(runs)
    feasibility = summarize_feasibility(runs)
    c6 = make_table_c6(runs)
    flips = collect_guidance_changes(inp, task_names=task_names)

    engineering.to_csv(out / "table15_engineering_outcomes.csv", index=False, encoding="utf-8-sig")
    feasibility.to_csv(out / "table16_feasibility_outcomes.csv", index=False, encoding="utf-8-sig")
    flips.to_csv(out / "table17_explicit_guidance_action_changes.csv", index=False, encoding="utf-8-sig")
    c6.to_csv(out / "tableC6_paired_full_m1.csv", index=False, encoding="utf-8-sig")

    lines = [
        "# Matched Full/M1 analysis",
        "",
        f"Runner: `{RUNNER_VERSION}`",
        "",
        "The eight engineering comparisons (2 disturbances × 4 engineering outcomes) form one Holm family.",
        "Non-significance is not interpreted as equivalence.",
        "",
        "## Engineering outcomes",
        engineering.to_string(index=False),
        "",
        "## Feasibility outcomes",
        feasibility.to_string(index=False),
        "",
        "## Paired inference",
        c6.to_string(index=False),
        "",
        "## Same-state explicit-guidance changes",
        flips.to_string(index=False) if not flips.empty else "No explicit-guidance action changes found.",
    ]
    (out / "analysis_summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Analysis complete. Outputs: {out}")


if __name__ == "__main__":
    main()
