from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import pandas as pd
import torch

from experiment_common import force_formal_budgets, load_solver
from full_m1_support import (
    SEEDS,
    VARIANTS,
    parse_csv_ints,
    parse_csv_names,
    save_actor_checkpoint,
    sha256_file,
    stable_json_hash,
    train_selected_actor,
)

RUNNER_VERSION = "matched-full-m1-train-v1.0"


def _schedule_rows(env):
    return [vars(x) for x in getattr(env, "schedule", [])]


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Train reloadable Full/M1 actors using the matched 10,000-episode mechanism-suite protocol."
    )
    ap.add_argument("--workbook", default="data/case2_22tasks_dynamicAHD_retyping.xlsx")
    ap.add_argument("--solver_module", default="dbn_cddpg_main_engineering_dynamicAHD_retyping_final.py")
    ap.add_argument("--variants", default="all")
    ap.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    ap.add_argument("--episodes", type=int, default=10000)
    ap.add_argument("--eval_interval", type=int, default=50)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--output_dir", default="outputs_full_m1_training")
    ap.add_argument("--save_training_details", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    workbook = (root / args.workbook).resolve() if not Path(args.workbook).is_absolute() else Path(args.workbook)
    solver_path = (root / args.solver_module).resolve() if not Path(args.solver_module).is_absolute() else Path(args.solver_module)
    out = (root / args.output_dir).resolve() if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    seeds = parse_csv_ints(args.seeds)
    variants = parse_csv_names(args.variants, VARIANTS)
    episodes = int(args.episodes)
    eval_interval = int(args.eval_interval)
    if args.smoke:
        seeds = [seeds[0]]
        variants = variants[:1]
        episodes = 2
        eval_interval = 1
        if args.device.startswith("cuda") and not torch.cuda.is_available():
            args.device = "cpu"

    if not workbook.exists():
        raise FileNotFoundError(workbook)
    if not solver_path.exists():
        raise FileNotFoundError(solver_path)

    protocol = {
        "runner_version": RUNNER_VERSION,
        "seeds": seeds,
        "variants": variants,
        "episodes": episodes,
        "eval_interval": eval_interval,
        "checkpoint_rule": "feasibility-first lexicographic; then makespan/NVS as implemented by the mechanism suite",
        "device": args.device,
        "workbook_sha256": sha256_file(workbook),
        "solver_sha256": sha256_file(solver_path),
    }
    protocol["training_protocol_id"] = stable_json_hash(protocol)
    if args.dry_run:
        print(json.dumps(protocol, ensure_ascii=False, indent=2))
        return

    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; use --device cpu for a smoke/protocol test.")

    solver = load_solver(solver_path)
    base_data = force_formal_budgets(solver.load_input_payload(workbook, scenario_id=None))
    out.mkdir(parents=True, exist_ok=True)
    (out / "training_manifest.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8")

    rows = []
    for variant in variants:
        for seed in seeds:
            actor_path = out / "actors" / variant / f"seed_{seed}.pt"
            meta_path = out / "actors" / variant / f"seed_{seed}.json"
            if args.resume and actor_path.exists() and meta_path.exists():
                rows.append(json.loads(meta_path.read_text(encoding="utf-8")))
                print(f"[resume] {variant} seed={seed}", flush=True)
                continue

            print(f"[train] variant={variant} seed={seed} episodes={episodes}", flush=True)
            t0 = time.perf_counter()
            trained = train_selected_actor(
                solver,
                base_data,
                variant=variant,
                seed=seed,
                episodes=episodes,
                eval_interval=eval_interval,
                device=args.device,
            )
            runtime_s = time.perf_counter() - t0
            save_actor_checkpoint(
                actor_path,
                variant=variant,
                seed=seed,
                selected_episode=trained["selected_episode"],
                planned_training_episodes=episodes,
                eval_interval=eval_interval,
                state_dim=trained["state_dim"],
                action_dim=trained["action_dim"],
                actor_state_dict=trained["actor_state_dict"],
                solver_sha256=protocol["solver_sha256"],
                workbook_sha256=protocol["workbook_sha256"],
            )
            m = trained["nominal_metrics"]
            row = {
                "runner_version": RUNNER_VERSION,
                "training_protocol_id": protocol["training_protocol_id"],
                "variant": variant,
                "seed": int(seed),
                "selected_episode": int(trained["selected_episode"]),
                "planned_training_episodes": int(episodes),
                "makespan": float(m["makespan"]),
                "ahd": float(m["risk"]),
                "fatigue": float(m["fatigue"]),
                "energy": float(m["energy"]),
                "nvs": float(m["nvs"]),
                "budget_feasible": int(m["budget_feasible"] > 0.5),
                "runtime_s": float(runtime_s),
                "actor_file": str(actor_path.relative_to(out).as_posix()),
                "actor_sha256": sha256_file(actor_path),
            }
            meta_path.parent.mkdir(parents=True, exist_ok=True)
            meta_path.write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
            rows.append(row)

            if args.save_training_details:
                detail = out / "run_details" / variant / f"seed_{seed}"
                detail.mkdir(parents=True, exist_ok=True)
                pd.DataFrame(trained["history"]).to_csv(detail / "training_history.csv", index=False, encoding="utf-8-sig")
                pd.DataFrame(_schedule_rows(trained["nominal_env"])).to_csv(detail / "nominal_schedule.csv", index=False, encoding="utf-8-sig")

            pd.DataFrame(rows).to_csv(out / "training_runs.csv", index=False, encoding="utf-8-sig")

    pd.DataFrame(rows).sort_values(["variant", "seed"]).to_csv(out / "training_runs.csv", index=False, encoding="utf-8-sig")
    print(f"Completed matched Full/M1 training. Outputs: {out}")


if __name__ == "__main__":
    main()
